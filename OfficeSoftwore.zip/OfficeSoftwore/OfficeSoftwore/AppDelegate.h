//
//  AppDelegate.h
//  OfficeSoftwore
//
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabBarViewController.h"
static NSString *appKey = @"4bf09fe7774eed539543558f";
static NSString *channel = @"Publish channel";
static BOOL isProduction = YES;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIWindow *window;
    UINavigationController *navigationController;
    BMKMapManager* _mapManager;
}

@property (strong, nonatomic) UIWindow *window;

@property (assign, nonatomic) NSInteger messageCount;
@property (strong, nonatomic) NSString *url;
@property (strong, nonatomic) NSString *typeString;
@property (strong, nonatomic) TabBarViewController *mainController;

- (void)notLogin;
- (void)loginout;
- (void)needUpdate;
- (void)reSetRootViewControll:(UIViewController *)rootViewController;
- (void)setEaseMobMainViewController;

@end

