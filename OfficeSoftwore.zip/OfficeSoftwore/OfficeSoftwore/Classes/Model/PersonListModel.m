//
//  PersonListModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/18.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "PersonListModel.h"

@implementation PersonListModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"UserName":@"UserName",
             @"UnitName":@"UnitName",
             @"NewClientUrl":@"NewClientUrl",
             @"EasemobPassword":@"EasemobPassword",
            };
}

@end
