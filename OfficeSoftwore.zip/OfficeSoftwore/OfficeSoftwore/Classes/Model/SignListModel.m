//
//  SignListModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/20.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "SignListModel.h"

@implementation SignListModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"status":@"status",
             @"result":@"result",
             };
}
//签退Model

@end
