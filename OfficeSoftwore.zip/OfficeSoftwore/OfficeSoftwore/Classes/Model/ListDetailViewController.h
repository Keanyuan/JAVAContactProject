//
//  ListDetailViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/10.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface ListDetailViewController : BaseViewController
@property (strong,nonatomic) NSString *url;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (strong,nonatomic) NSString *tittles;
@end
