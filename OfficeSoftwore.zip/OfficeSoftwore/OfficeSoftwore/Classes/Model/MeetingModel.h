//
//  MeetingModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface MeetingModel : BaseModel

@property (strong ,nonatomic) NSString *length;
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSArray *result;
@property (strong ,nonatomic) NSString *recordCount;


@end
