//
//  SignListModel.h
//  OfficeSoftwore
//
//  Created by user on 16/5/20.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

//签退Model
@interface SignListModel : BaseModel
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *result;

@end
