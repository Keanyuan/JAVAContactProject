//
//  LoginModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/29.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface LoginModel : BaseModel

@property (strong ,nonatomic) NSString *token;
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *result;
@property (strong ,nonatomic) NSString *userName;

@end
