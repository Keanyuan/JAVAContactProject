//
//  calendarModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/30.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "calendarModel.h"

@implementation calendarModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"status":@"status",
             @"result":@"result",
             };
}

@end
