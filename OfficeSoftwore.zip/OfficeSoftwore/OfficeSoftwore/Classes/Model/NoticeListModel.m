//
//  NoticeListModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "NoticeListModel.h"

@implementation NoticeListModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"createDate":@"CreateDate",
             @"title":@"Title",
             @"body":@"Body",
             @"url":@"Url",
             
            };
}


@end
