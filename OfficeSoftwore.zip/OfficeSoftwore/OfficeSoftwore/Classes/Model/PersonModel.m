//
//  PersonModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/18.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "PersonModel.h"
#import "PersonListModel.h"

@implementation PersonModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result"
             };
}
+(NSValueTransformer*)resultJSONTransformer
{
    return [NSValueTransformer mtl_JSONDictionaryTransformerWithModelClass:[PersonListModel class]];
}
@end
