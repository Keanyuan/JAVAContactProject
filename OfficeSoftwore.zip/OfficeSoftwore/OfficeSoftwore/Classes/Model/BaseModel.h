//
//  BaseModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "MTLModel.h"

@interface BaseModel : MTLModel<MTLJSONSerializing>

@end
