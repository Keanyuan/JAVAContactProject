//
//  AboutModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/30.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface AboutModel : BaseModel

@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *result;

@end
