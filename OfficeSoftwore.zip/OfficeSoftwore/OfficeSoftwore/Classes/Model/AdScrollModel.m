//
//  AdScrollModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/22.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "AdScrollModel.h"

@implementation AdScrollModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"status":@"status",
             @"result":@"result",
             };
}


@end
