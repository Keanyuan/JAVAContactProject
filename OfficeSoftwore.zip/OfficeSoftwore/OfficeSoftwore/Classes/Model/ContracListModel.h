//
//  ContracListModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface ContracListModel : BaseModel
@property (nonatomic, strong)NSString *userName;
@property (nonatomic, strong)NSString *telephone;
@property (nonatomic, strong)NSString *imageurl;
@property (nonatomic, strong)NSString *unitNam;
@property (nonatomic, strong)NSString *UserAccount;

@end
