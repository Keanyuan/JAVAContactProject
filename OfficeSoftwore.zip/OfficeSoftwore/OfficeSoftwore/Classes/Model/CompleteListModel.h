//
//  CompleteListModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/3.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface CompleteListModel : BaseModel

@property (nonatomic,strong)NSString * userName;
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *processType;
@property (nonatomic,strong)NSString *stepName;
@property (nonatomic,strong)NSString *type;
@property (nonatomic,strong)NSString *url;

@property (nonatomic,strong)NSString *curHandler;
@property (nonatomic,strong)NSString * ID;
@property (nonatomic,strong)NSString *instanceID;
@property (nonatomic,strong)NSString *itemID;
@property (nonatomic,strong)NSString *roundNum;
@property (nonatomic,strong)NSString *prevHandler;
@property (nonatomic,strong)NSString *prevStep;
@property (nonatomic,strong)NSString *curStep;
@property (nonatomic,strong)NSString *prevHandlerDept;
@property (nonatomic,strong)NSString *curHandlerDept;
@property (nonatomic,strong)NSString *status;
@property (nonatomic,strong)NSString *startTime;
@property (nonatomic,strong)NSString *endTime;
@property (nonatomic,strong)NSString *createDate;
@property (nonatomic,strong)NSString *lastEditDate;
@property (nonatomic,strong)NSString *createUser;
@property (nonatomic,strong)NSString *lastEditUser;
@property (nonatomic,strong)NSString *prevStepName;
@property (nonatomic,strong)NSString *isAgree;

@end
