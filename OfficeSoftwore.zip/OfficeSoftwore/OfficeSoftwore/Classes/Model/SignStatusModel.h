//
//  SignStatusModel.h
//  OfficeSoftwore
//
//  Created by user on 16/6/2.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface SignStatusModel : BaseModel
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *result;

@end
