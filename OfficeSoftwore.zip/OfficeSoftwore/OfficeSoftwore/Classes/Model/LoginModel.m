//
//  LoginModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/29.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "LoginModel.h"

@implementation LoginModel

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             @"token":@"token",
             @"userName":@"userName",
             };
}
@end
