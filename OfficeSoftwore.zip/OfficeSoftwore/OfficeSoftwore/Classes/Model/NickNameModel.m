//
//  NickNameModel.m
//  OfficeSoftwore
//
//  Created by user on 16/7/19.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "NickNameModel.h"
#import "NickListModel.h"
@implementation NickNameModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             @"length":@"length",
             };
}

+(NSValueTransformer*)resultJSONTransformer
{
    return [NSValueTransformer mtl_JSONArrayTransformerWithModelClass:[NickListModel class]];
}


@end
