//
//  PersonListModel.h
//  OfficeSoftwore
//
//  Created by user on 16/5/18.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface PersonListModel : BaseModel
@property (nonatomic,copy)NSString *UserName;
@property (nonatomic,copy)NSString *UnitName;
@property (nonatomic,copy)NSString *NewClientUrl;
@property (nonatomic, copy)NSString *EasemobPassword;


@end
