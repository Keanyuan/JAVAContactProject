//
//  ContracListModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "ContracListModel.h"

@implementation ContracListModel

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"userName":@"UserName",
             @"telephone":@"Telephone",
             @"imageurl":@"Icon",
             @"unitNam":@"UnitName",
             @"UserAccount":@"UserAccount"
             };
}

@end
