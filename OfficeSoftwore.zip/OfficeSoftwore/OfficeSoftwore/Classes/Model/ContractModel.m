//
//  ContractModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "ContractModel.h"
#import "ContracListModel.h"

@implementation ContractModel

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             @"length":@"length",
             };
}

+(NSValueTransformer*)resultJSONTransformer
{
    return [NSValueTransformer mtl_JSONArrayTransformerWithModelClass:[ContracListModel class]];
}

@end
