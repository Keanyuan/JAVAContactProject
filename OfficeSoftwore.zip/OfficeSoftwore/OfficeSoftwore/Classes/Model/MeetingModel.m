//
//  MeetingModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "MeetingModel.h"
#import "MeetingListModel.h"

@implementation MeetingModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             @"length":@"length",
             @"recordCount":@"recordCount",
             };
}

+(NSValueTransformer*)resultJSONTransformer
{
    return [NSValueTransformer mtl_JSONArrayTransformerWithModelClass:[MeetingListModel class]];
}

@end
