//
//  NoticeDetailViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "NoticeDetailViewController.h"

@interface NoticeDetailViewController ()<UIWebViewDelegate>

@end

@implementation NoticeDetailViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"公告通知";
    [self initView];
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.scalesPageToFit = NO;
    _webView.delegate =self;
    _webView.scrollView.bounces = NO;
    [self webViewRequestData:self.webView];
}

- (void)initView
{
    
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(noticeWebBack)]];

    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

- (void)noticeWebBack {
    if (_webView.canGoBack) {
        [_webView goBack];
        
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)webViewRequestData:(UIWebView *)webView{
    if (self.url) {
        [CommonMethod webViewRequest:webView
                                 url:self.url];
    }
    
}

#pragma  mark- UIWebViewDelegate
//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
//
//    return YES;
//}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:nil];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
}

-(void)dealloc
{
    _webView = nil;
    _webView.delegate = nil;
}
-(void)viewWillAppear:(BOOL)animated{
    [CommonMethod validateToken];
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [self hiddenLoadingView];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
