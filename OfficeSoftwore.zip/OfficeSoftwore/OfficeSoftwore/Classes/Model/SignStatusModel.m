//
//  SignStatusModel.m
//  OfficeSoftwore
//
//  Created by user on 16/6/2.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "SignStatusModel.h"

@implementation SignStatusModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"status":@"status",
             @"result":@"result",
             };
}

@end
