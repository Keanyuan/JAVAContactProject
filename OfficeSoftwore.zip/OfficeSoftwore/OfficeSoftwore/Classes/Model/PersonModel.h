//
//  PersonModel.h
//  OfficeSoftwore
//
//  Created by user on 16/5/18.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"
#import "PersonListModel.h"

@interface PersonModel : BaseModel
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) PersonListModel *result;


@end
