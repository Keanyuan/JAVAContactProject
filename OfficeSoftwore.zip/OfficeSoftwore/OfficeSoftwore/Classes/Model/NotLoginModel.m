//
//  NotLoginModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/17.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "NotLoginModel.h"

@implementation NotLoginModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             };
}

@end
