//
//  ListDetailViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/10.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "ListDetailViewController.h"
#import "CommonWebVC.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "WaitWebJS.h"

@interface ListDetailViewController ()<UIWebViewDelegate>
{
    WebViewJavascriptBridge* _bridge;
}
@end

@implementation ListDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.tittles;
    [self initView];
    //self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.scalesPageToFit = NO;
    _webView.delegate = self;
    _webView.scrollView.bounces = NO;
    [self webViewRequestData:self.webView];
    
    if (_bridge) { return; }
    //注册
    [WebViewJavascriptBridge enableLogging];
    _bridge = [WebViewJavascriptBridge bridgeForWebView:_webView webViewDelegate:self handler:^(id data, WVJBResponseCallback responseCallback) {
        
        responseCallback(@"Response for message from ObjC");
    }];
    
    // js调oc方法
    [_bridge registerHandler:@"a" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSDictionary *dic = (NSDictionary *)data;
        CommonWebVC *commonWebVC = (CommonWebVC *)[CommonMethod storyBoardViewController:@"Main"
                                                                               identifer:@"CommonWebVC"];
        commonWebVC.url = dic[@"URL"];
        commonWebVC.title = dic[@"TITLE"];
        [self.navigationController pushViewController:commonWebVC animated:YES];
    }];
    
    // js调oc方法
    [_bridge registerHandler:@"go" handler:^(id data, WVJBResponseCallback responseCallback) {
        //事项办结后加载静态页面
//        NSString *urlToken = [NSString stringWithFormat:@"%@%@",APPLY_URL,APPLY_SUCCESS];
//        NSURL *url = [NSURL URLWithString:urlToken];
//        NSURLRequest *request = [NSURLRequest requestWithURL:url];
//        [_webView loadRequest:request];
        
//        NSString *refresh = @"YES";
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"WaitRefresh"
//                                                            object:self
//                                                          userInfo:@{@"waitRefreshh":refresh}];

    }];


}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                            sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}
- (void)noticeBack_web {
    if (_webView.canGoBack) {
        [_webView goBack];
        
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)webViewRequestData:(UIWebView *)webView{
    if (self.url) {
        [CommonMethod webViewRequest:webView
                                 url:self.url];
    }
    
}

#pragma  mark- UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:nil];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //网页加载之前会调用此方法
    NSString *url = [[request URL] absoluteString];
    NSLog(@"url----==%@",url);
    if([url rangeOfString:@"Success.html"].length > 0){
        NSString *refresh = @"YES";
        [[NSNotificationCenter defaultCenter] postNotificationName:@"WaitRefresh"
                                                            object:self
                                                          userInfo:@{@"waitRefreshh":refresh}];
        
    }
    //    Success.html
    return YES;
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
}

-(void)dealloc
{
    _webView = nil;
    _webView.delegate = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
