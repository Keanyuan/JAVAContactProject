//
//  AdScrollModel.h
//  OfficeSoftwore
//
//  Created by user on 16/5/22.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface AdScrollModel : BaseModel
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSArray *result;

@end
