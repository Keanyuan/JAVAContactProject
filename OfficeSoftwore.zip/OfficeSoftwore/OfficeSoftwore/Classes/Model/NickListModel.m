//
//  NickListModel.m
//  OfficeSoftwore
//
//  Created by user on 16/7/19.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "NickListModel.h"

@implementation NickListModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"username":@"username",
             @"nick":@"nick",
             
             };
}
@end
