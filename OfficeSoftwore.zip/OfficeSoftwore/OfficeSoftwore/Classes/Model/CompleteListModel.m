//
//  CompleteListModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/3.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "CompleteListModel.h"

@implementation CompleteListModel

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"userName":@"Applicant",
             @"title":@"Title",
             @"processType":@"ProcessType",
             @"stepName":@"StepName",
             @"type":@"Type",
             @"url":@"Url",
             
             
             @"curHandler":@"CurHandler",
             @"ID":@"ID",
             @"instanceID":@"InstanceID",
             @"itemID":@"ItemID", 
             @"roundNum":@"RoundNum",
             @"prevHandler":@"PrevHandler",
             @"prevStep":@"PrevStep",
             @"curStep":@"CurStep",
             @"prevHandlerDept":@"PrevHandlerDept",
             @"curHandlerDept":@"CurHandlerDept",
             @"status":@"Status",
             @"startTime":@"StartTime",
             @"endTime":@"EndTime",
             @"createDate":@"CreateDate",
             @"lastEditDate":@"LastEditDate",
             @"createUser":@"CreateUser",
             @"lastEditUser":@"LastEditUser",
             @"isAgree":@"IsAgree",
             @"prevStepName":@"PrevStepName",

             };
}

@end
