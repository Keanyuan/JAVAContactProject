//
//  MeetingListModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface MeetingListModel : BaseModel
@property (nonatomic,strong)NSString *createDate;
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *body;
@property (nonatomic,strong)NSString *url;
@end
