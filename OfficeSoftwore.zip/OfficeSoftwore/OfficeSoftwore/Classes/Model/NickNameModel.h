//
//  NickNameModel.h
//  OfficeSoftwore
//
//  Created by user on 16/7/19.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface NickNameModel : BaseModel
@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *length;
@property (strong ,nonatomic) NSArray *result;


@end
