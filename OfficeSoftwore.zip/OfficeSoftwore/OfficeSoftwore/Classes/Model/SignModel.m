//
//  SignModel.m
//  OfficeSoftwore
//
//  Created by user on 16/5/20.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "SignModel.h"

@implementation SignModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             };
}




@end
