//
//  AboutModel.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/30.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "AboutModel.h"

@implementation AboutModel

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             @"result":@"result",
             };
}

@end
