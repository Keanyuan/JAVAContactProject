//
//  NoticeDetailViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface NoticeDetailViewController : BaseViewController
@property (strong,nonatomic) NSString *url;
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
