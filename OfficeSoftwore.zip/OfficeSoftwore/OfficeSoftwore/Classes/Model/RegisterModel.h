//
//  RegisterModel.h
//  OfficeSoftwore
//
//  Created by 郭川 on 16/8/29.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface RegisterModel : BaseModel
@property (nonatomic, strong)NSString *status;
@end
