//
//  NotLoginModel.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/17.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseModel.h"

@interface NotLoginModel : BaseModel

@property (strong ,nonatomic) NSString *status;
@property (strong ,nonatomic) NSString *result;

@end
