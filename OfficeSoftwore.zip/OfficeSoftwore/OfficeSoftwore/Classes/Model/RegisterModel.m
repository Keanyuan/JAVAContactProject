//
//  RegisterModel.m
//  OfficeSoftwore
//
//  Created by 郭川 on 16/8/29.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "RegisterModel.h"

@implementation RegisterModel
+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"status":@"status",
             };
}

@end
