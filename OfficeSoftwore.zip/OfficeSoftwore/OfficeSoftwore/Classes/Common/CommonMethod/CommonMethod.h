//
//  CommonMethod.h
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NickListModel.h"
@interface CommonMethod : NSObject

//时间字符串转换
+ (NSString *)formatDate:(NSDate *)date format:(NSString *)formatter;
+ (NSDate *)dateFromString:(NSString *)dateString format:(NSString *)formatter;
+ (NSString *)getTimeString:(NSString *)string setDateFormat:(NSString *)dateFormatString;

//是否支持打电话
+ (BOOL)isPhoneSupported;

//storyBoard初始化viewcontroller
+ (UIViewController *)mainStoryBoardViewController:(NSString *)identifier;

//storyBoard初始化loginviewcontroller
+ (UIViewController *)loginStoryBoardViewController:(NSString *)identifier;
+ (UIViewController *)storyBoardViewController:(NSString *)name identifer:(NSString *)identifier;

//用户名和密码的光标颜色
+ (void)colorWithUserName:(UITextField *)userName password:(UITextField *)password;

//获登陆的用户名
+(void)setLoginUsername:(NSString *)username;

//取登陆的用户名
+(NSString *)getLoginUserName;

//获bool
+(void)setLaunchedByNotification:(BOOL)LaunchedByNotification;

//取bool
+(BOOL)getNotification;

//移除key对应的值
+(void)removeObject:(NSString *)string;

//用户名
+(void)setUsername:(NSString *)username;

//获取用户名
+(NSString *)getUserName;

//获取密码
+(void)setPassword:(NSString *)setPassword;

//获取用户名密码
+(void)setUsername:(NSString *)username password:(NSString *)setPassword;

//获取token
+(void)setToken:(NSString *)token;
+(NSString *)getToken;

//webview数据请求
+(void)webViewRequest:(UIWebView *)webview url:(NSString *)stringUrl;

//获取滚动木马的type
+ (NSArray *)getTitttleType;

//保存图片至沙盒
+(NSString *)saveImage:(UIImage *)currentImage withName:(NSString *)imageName;

//颜色背景转换
+ (UIImage *)convertViewToImage:(UIView*)v;

//搜索颜色
+(void)searchBarColor;

+(id)getuseridByKey:(NSString *)key;

//验证token
+(void)validateToken;

//存nickname
+(NSArray *)getNickName;

+(void)setNickName:(id)userInfo;
//取用户信息
+(id)userInfo;

+(void)setBadge:(NSString *)badge;

+(NSString *)getBadge;

//存用户名部门名称
+(void)setUnitName:(NSString *)unitName;
//取用户名部门名称
+(NSString *)getUnitName;

//存环信密码
+(void)setEasePassWord:(NSString *)passWord;
//取环信密码
+(NSString *)getEasePassWord;
//后台进入前台存bool
+ (void)applicationBecomeActive:(BOOL)becomeActive;
//取bool
+ (BOOL)applicationBecomeActive;
@end
