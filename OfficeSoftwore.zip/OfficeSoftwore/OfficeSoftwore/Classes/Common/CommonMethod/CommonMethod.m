//
//  CommonMethod.m
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "CommonMethod.h"
#import <CommonCrypto/CommonDigest.h>
#import "calendarModel.h"
#import "AppDelegate.h"

@implementation CommonMethod
+(void)setUserdefaultWithValue:(id)value forKey:(NSString *)key
{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setValue:value forKey:key];
    [userDefault synchronize];
}

+ (NSString *)formatDate:(NSDate *)date format:(NSString *)formatter {
    static NSDateFormatter *dateFormatter = nil;
    
    if (dateFormatter == nil) {
        dateFormatter = [[NSDateFormatter alloc] init];
    }
    
    [dateFormatter setDateFormat:formatter];
    
    return [dateFormatter stringFromDate:date];
}

+ (NSDate *)dateFromString:(NSString *)dateString format:(NSString *)formatter {
    
    static NSDateFormatter *dateFormatter = nil;
    
    if (dateFormatter == nil) {
        dateFormatter = [[NSDateFormatter alloc] init];
    }
    
    [dateFormatter setDateFormat:formatter];
    
    NSDate *destDate= [dateFormatter dateFromString:dateString];
    
    return destDate;
}

+ (NSString *)getTimeString:(NSString *)string setDateFormat:(NSString *)dateFormatString{
    static NSDateFormatter *dateFormatter = nil;
    
    if (dateFormatter == nil) {
        dateFormatter = [[NSDateFormatter alloc] init];
    }
    
    if (dateFormatString == nil) {
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
    }else{
    [dateFormatter setDateFormat:dateFormatString];
        
    }
    NSString *stringData = [string stringByReplacingOccurrencesOfString:@"/Date(" withString:@""];
    NSString *stringTime = [stringData stringByReplacingOccurrencesOfString:@")/" withString:@""];

    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[stringTime longLongValue] /1000];
    NSString *dateString = [dateFormatter stringForObjectValue:date];
    
    return dateString;
}

//设备是否支持打电话
+ (BOOL)isPhoneSupported {
    NSString* deviceType = [UIDevice currentDevice].model;
    return [deviceType isEqualToString:@"iPhone"];
}

//storyBoard初始化mainviewcontroller
+ (UIViewController *)mainStoryBoardViewController:(NSString *)identifier {
    
    return [self storyBoardViewController:@"Main" identifer:identifier];
}

//storyBoard初始化loginviewcontroller
+ (UIViewController *)loginStoryBoardViewController:(NSString *)identifier {
    
    return [self storyBoardViewController:@"Login" identifer:identifier];
}

+ (UIViewController *)storyBoardViewController:(NSString *)name identifer:(NSString *)identifier {
    
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:name bundle:nil];
    
    UIViewController *viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:identifier];
    
    return viewController;
}

//用户名和密码的光标颜色
+ (void)colorWithUserName:(UITextField *)userName password:(UITextField *)password
{
    userName.tintColor = [UIColor colorWithHexString:@"#75cde5"];
    password.tintColor = [UIColor colorWithHexString:@"#75cde5"];
}

+(void)setUsername:(NSString *)username{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:username forKey:USERNAME];
    [accountDefaults synchronize];
}
//存
+(void)setLoginUsername:(NSString *)username{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:username forKey:LOGIN_USERNAME];
    [accountDefaults synchronize];
}

//取用login户名
+(NSString *)getLoginUserName{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *tokenString = [accountDefaults stringForKey:LOGIN_USERNAME];
    return tokenString;
}

+(void)setPassword:(NSString *)setPassword{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:setPassword forKey:PASSWORD];
    [accountDefaults synchronize];

}
//存
+(void)setUsername:(NSString *)username password:(NSString *)setPassword{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:username forKey:USERNAME];
    [accountDefaults setObject:setPassword forKey:PASSWORD];
    [accountDefaults synchronize];

}
+(id)getuseridByKey:(NSString *)key
{
   return  [[NSUserDefaults standardUserDefaults]objectForKey:key];
}

//取用户名
+(NSString *)getUserName{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *tokenString = [accountDefaults stringForKey:USERNAME];
    return tokenString;
}
//token存
+(void)setToken:(NSString *)token{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:token forKey:TOKEN];
    [accountDefaults synchronize];
}


//获bool
+(void)setLaunchedByNotification:(BOOL)LaunchedByNotification{
    NSUserDefaults *notificationDefaults = [NSUserDefaults standardUserDefaults];
    [notificationDefaults setBool:LaunchedByNotification forKey:isLaunchedByNotification];
    [notificationDefaults synchronize];
    
}

//取bool
+(BOOL)getNotification{
    NSUserDefaults *notificationDefaults = [NSUserDefaults standardUserDefaults];
    BOOL notification = [notificationDefaults boolForKey:isLaunchedByNotification];
    return notification;
}

//移除key对应的值
+(void)removeObject:(NSString *)string{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults removeObjectForKey:string];
    [accountDefaults synchronize];
    
    NSLog(@"%@",string);

    
}

//取token
+(NSString *)getToken{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *tokenString = [accountDefaults stringForKey:TOKEN];
    return tokenString;
}


//webview数据请求
+(void)webViewRequest:(UIWebView *)webview url:(NSString *)stringUrl{
    NSURL* url = [NSURL URLWithString:stringUrl];
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    [webview loadRequest:request];

}

//获取滚动木马的Type
+ (NSArray *)getTitttleType {
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"TittleType" ofType:@"plist"];
    NSArray *data = [[NSArray alloc] initWithContentsOfFile:plistPath];
    return data;
}

//保存图片至沙盒
+(NSString *)saveImage:(UIImage *)currentImage withName:(NSString *)imageName {
    NSData *imageData = UIImageJPEGRepresentation(currentImage, 1);//1为不缩放保存,取值（0.0-1.0）
    //获取沙盒路径
    NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:imageName];
    //将图片写入文件
    [imageData writeToFile:path atomically:NO];
    
    return path;
}
//背景颜色转换
+ (UIImage*)convertViewToImage:(UIView*)v {
    
    UIGraphicsBeginImageContext(v.bounds.size);
    [v.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
    
}

//取nickname
//保存用户信息
+(void)setNickName:(id)userInfo;
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userInfo];
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    [user setObject:data forKey:NICK_NAME];
    [user synchronize];
}
//取
+(id)userInfo
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSData *data = [userDefaults objectForKey:NICK_NAME];
    id userInfo = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return userInfo;

}


+(void)setBadge:(NSString *)badge
{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:badge forKey:BADGE];
    [accountDefaults synchronize];

}

+(NSString *)getBadge
{
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *badgeString = [accountDefaults stringForKey:BADGE];
    return badgeString;

}

//存用户名部门名称
+(void)setUnitName:(NSString *)unitName {
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:unitName forKey:UNIT_NAME];
    [accountDefaults synchronize];

}
//取用户名部门名称
+(NSString *)getUnitName {
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *unitString = [accountDefaults stringForKey:UNIT_NAME];
    return unitString;

}

//存环信密码
+(void)setEasePassWord:(NSString *)passWord {
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    [accountDefaults setObject:passWord forKey:EASE_PASS_WORD];
    [accountDefaults synchronize];
    
}
//取环信密码
+(NSString *)getEasePassWord {
    NSUserDefaults *accountDefaults = [NSUserDefaults standardUserDefaults];
    NSString *unitString = [accountDefaults stringForKey:EASE_PASS_WORD];
    return unitString;
}



//搜索颜色
+ (void)searchBarColor {
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
}
//后台进入前台存bool
+ (void)applicationBecomeActive:(BOOL)becomeActive
{
    NSUserDefaults *notificationDefaults = [NSUserDefaults standardUserDefaults];
    [notificationDefaults setBool:becomeActive forKey:BecomeActive];
    [notificationDefaults synchronize];

}
//后台进入前台取bool
+ (BOOL)applicationBecomeActive
{
    NSUserDefaults *notificationDefaults = [NSUserDefaults standardUserDefaults];
    BOOL notification = [notificationDefaults boolForKey:BecomeActive];
    return notification;
}


//验证token
+(void)validateToken {
    [[AFHttpModelTool shareAFHttpModelTool] getcalendarWithToken:[CommonMethod getToken]
                                                      Completion:^(calendarModel *calendModel) {
                                                          NSLog(@"----%@",calendModel.result);
                                                          NSLog(@"--%@",calendModel.status);
                                                          if (![calendModel.status isEqualToString:@"success"] || ![calendModel.result isEqualToString:@"1"]) {
                                                              [OA_AppDelegate loginout];
                                                          }

                                                      } failure:^(NSError *error) {
                                                          NSLog(@"%@",error);

                                                      }];
}

@end
