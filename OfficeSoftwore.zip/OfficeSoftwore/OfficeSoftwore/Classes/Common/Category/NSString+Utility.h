//
//  NSString+Utility.h
//  SaleHouse
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Utility)

-(CGFloat)getStringHeight:(UIFont*)font width:(CGFloat)width size:(CGFloat)minSize;
-(CGFloat)getStringWidth:(UIFont*)font Height:(CGFloat)height size:(CGFloat)minSize;

@end
