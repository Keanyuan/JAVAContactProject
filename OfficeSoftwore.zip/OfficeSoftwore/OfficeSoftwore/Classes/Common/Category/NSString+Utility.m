//
//  NSString+Utility.m
//  SaleHouse
//
#import "NSString+Utility.h"
#import <UIKit/UIKit.h>


@implementation NSString (Utility)

-(CGFloat)getStringHeight:(UIFont*)font width:(CGFloat)width size:(CGFloat)minSize{
    
//    NSDictionary *attributes = @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica Neue" size:minSize]};
//    CGRect stringRect = [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
//                                              options:NSStringDrawingUsesLineFragmentOrigin
//                                           attributes:attributes
//                                              context:nil];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self];
    NSDictionary *attrSyleDict = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  font, NSFontAttributeName,
                                  nil];
    [attributedString addAttributes:attrSyleDict
                              range:NSMakeRange(0, self.length)];
    CGRect stringRect = [attributedString boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
                                                       options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                                       context:nil];
    
    return stringRect.size.height;
}

-(CGFloat)getStringWidth:(UIFont*)font Height:(CGFloat)height size:(CGFloat)minSize{
    
//    NSDictionary *attributes = @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica Neue" size:minSize]};
//    CGRect stringRect = [self boundingRectWithSize:CGSizeMake(MAXFLOAT, height)
//                                           options:NSStringDrawingUsesLineFragmentOrigin
//                                        attributes:attributes
//                                           context:nil];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self];
    NSDictionary *attrSyleDict = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  font, NSFontAttributeName,
                                  nil];
    
    [attributedString addAttributes:attrSyleDict
                              range:NSMakeRange(0, self.length)];
    CGRect stringRect = [attributedString boundingRectWithSize:CGSizeMake(MAXFLOAT, height)
                                                       options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                         
                                                       context:nil];
    
    return stringRect.size.width;
}

@end
