//
//  BaseService.m
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseService.h"

@implementation BaseService
static BaseService *baseService = nil;

+ (BaseService *)shareBaseService
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        baseService = [[self alloc] init];
    });
    return baseService;
}

//基本service
+ (void) requestWithMethod:(RequestMethodType)methodType
                requestUrl:(NSString *)url
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure
{
    NSURL *baseUrl = [NSURL URLWithString:DEV_FAKE_SERVER];

    AFHTTPRequestOperationManager *manger = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseUrl];
    
    manger.responseSerializer = [AFJSONResponseSerializer serializer];
    manger.requestSerializer  =[AFJSONRequestSerializer serializer];
    
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:ContentType];

    
    [manger.requestSerializer setValue:Content_Type_Value forHTTPHeaderField:Content_Type];
//    [manger.requestSerializer setValue:@"application/json" forHTTPHeaderField:Content_Type];

    
    AFJSONResponseSerializer *response = (AFJSONResponseSerializer *)manger.responseSerializer;
    response.removesKeysWithNullValues = YES;
    
    manger.requestSerializer.timeoutInterval = 25;
    
    switch (methodType) {
        case RequestMethodTypeGet:
        {
            //GET请求
            [manger GET:url parameters:params
                success:^(AFHTTPRequestOperation *operation, id responseObject) {
                if (operation.response.statusCode == 200) {
                    success(responseObject);
                }else{
                    success(nil);
                }
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                
                failure(error);
            }];
        }
            break;
        case RequestMethodTypePost:
        {
            //POST请求
            [manger POST:url parameters:params
                 success:^(AFHTTPRequestOperation* operation, NSDictionary* responseObj) {
                     if (operation.response.statusCode == 200) {
                         success(responseObj);
                     }else{
                         success(nil);
                     }
                 } failure:^(AFHTTPRequestOperation* operation, NSError* error) {
                     if (error) {
                         failure(error);
                     }
                 }];
        }
            break;
        default:
            break;
    }
}

//登陆
+ (void) requestLoginWithrequestUrl:(NSString *)url
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure
{
    NSURL *baseUrl = [NSURL URLWithString:LOGIN_FAKE_SERVER];
        
    AFHTTPRequestOperationManager *manger = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseUrl];
    
    manger.requestSerializer = [AFHTTPRequestSerializer serializer];

    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:ContentType];
    
    manger.securityPolicy.allowInvalidCertificates = YES;
    
    [manger.requestSerializer setValue:Content_Type_Value forHTTPHeaderField:Content_Type];
    
    AFJSONResponseSerializer *response = (AFJSONResponseSerializer *)manger.responseSerializer;
    response.removesKeysWithNullValues = YES;
    
    manger.requestSerializer.timeoutInterval = 25;
    
    [manger POST:url parameters:params
         success:^(AFHTTPRequestOperation* operation, NSDictionary* responseObj) {
             if (operation.response.statusCode == 200) {
                success(responseObj);
             }else{
                 success(nil);
             }
         } failure:^(AFHTTPRequestOperation* operation, NSError* error) {
             if (error) {
                 failure(error);
             }
         }];
}


//上传图片
- (void)uploadImageWithUrl:(NSString *)url
                     image:(UIImage *)image
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure
{
    NSURL *baseUrl = [NSURL URLWithString:DEV_FAKE_SERVER];
    
    AFHTTPRequestOperationManager *manger = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseUrl];
    
    manger.requestSerializer = [AFHTTPRequestSerializer serializer];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:ContentType];
    manger.securityPolicy.allowInvalidCertificates = YES;
    [manger.requestSerializer setValue:Content_Type_Value forHTTPHeaderField:Content_Type];
    AFJSONResponseSerializer *response = (AFJSONResponseSerializer *)manger.responseSerializer;
    response.removesKeysWithNullValues = YES;
    manger.requestSerializer.timeoutInterval = 25;
    //设置我们的缓存大小 其中内存缓存大小设置10M  磁盘缓存50M
    NSURLCache *cache = [[NSURLCache alloc] initWithMemoryCapacity:10 * 1024 * 1024
                                                      diskCapacity:50 * 1024 * 1024
                                                          diskPath:nil];
    
    [NSURLCache setSharedURLCache:cache];
    
    manger.requestSerializer.timeoutInterval = 25;
    
    [manger POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        NSData *imageData = UIImageJPEGRepresentation(image,1.0);
//        if (UIImagePNGRepresentation(image) == nil) {
//            imageData = UIImageJPEGRepresentation(image, 1.0);
//        }else {
//            imageData = UIImagePNGRepresentation(image);
//        }
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        
        [formData appendPartWithFileData:imageData name:@"fileName" fileName:fileName mimeType:@"image/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (operation.response.statusCode == 200) {
            success(responseObject);
        }else{
            success(nil);
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (error) {
            failure(error);
        }

    }];

}
//签到签退
+ (void)kuploadImageWithUrl:(NSString *)url
                      image:(UIImage *)image
                     params:(NSDictionary *)params
                    success:(void (^)(id response))success
                    failure:(void (^)(NSError *err))failure
{
    NSURL *baseUrl = [NSURL URLWithString:DEV_FAKE_SERVER];
    
    AFHTTPRequestOperationManager *manger = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseUrl];
    
    manger.requestSerializer = [AFHTTPRequestSerializer serializer];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:ContentType];
    manger.securityPolicy.allowInvalidCertificates = YES;
    [manger.requestSerializer setValue:Content_Type_Value forHTTPHeaderField:Content_Type];
    AFJSONResponseSerializer *response = (AFJSONResponseSerializer *)manger.responseSerializer;
    response.removesKeysWithNullValues = YES;
    manger.requestSerializer.timeoutInterval = 25;
    //设置我们的缓存大小 其中内存缓存大小设置10M  磁盘缓存50M
    NSURLCache *cache = [[NSURLCache alloc] initWithMemoryCapacity:10 * 1024 * 1024
                                                      diskCapacity:50 * 1024 * 1024
                                                          diskPath:nil];
    
    [NSURLCache setSharedURLCache:cache];
    
    manger.requestSerializer.timeoutInterval = 25;
    
    
    [manger POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        NSData *imageData = UIImageJPEGRepresentation(image,1.0);
//        if (UIImagePNGRepresentation(image) == nil) {
//            imageData = UIImageJPEGRepresentation(image, 1.0);
//        }else {
//            imageData = UIImagePNGRepresentation(image);
//        }
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        
        [formData appendPartWithFileData:imageData name:@"fileName" fileName:fileName mimeType:@"image/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (operation.response.statusCode == 200) {
            success(responseObject);
        }else{
            success(nil);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (error) {
            failure(error);
        }
        
    }];
}




//// 上传图片
//+ (AFHTTPRequestOperation *)uploadImageWithUrl:(NSString *)url
//                                         image:(UIImage *)image
//                                    completion:(HYBRequestCompletion)completion
//                                    errorBlock:(HYBErrorBlock)errorBlock {
//    url = [url addPrefix:@"/CosmetologyShop"];
//    if ([HYBUserInfoTool userToken]) {
//        url = [NSString stringWithFormat:@"%@?TOKEN=%@", url, [HYBUserInfoTool userToken]];
//    }
//    
//    AFHTTPRequestOperationManager *manager = [self operationManagerWithBaseUrl:kFileBaseUrl];
//    AFHTTPRequestOperation *op = [manager POST:url parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//        NSData *imageData = UIImageJPEGRepresentation(image, 1);
//        
//        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//        formatter.dateFormat = @"yyyyMMddHHmmss";
//        NSString *str = [formatter stringFromDate:[NSDate date]];
//        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
//        
//        // 上传图片，以文件流的格式
//        [formData appendPartWithFileData:imageData name:@"myfiles" fileName:fileName mimeType:@"image/jpeg"];
//    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        completion(responseObject);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        errorBlock(error);
//    }];
//    
//    return op;
//}

+ (void) rrrrequestWithMethod:(RequestMethodType)methodType
                requestUrl:(NSString *)url
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure
{
    NSURL *baseUrl = [NSURL URLWithString:DEV_FAKE_SERVER];
    
    AFHTTPRequestOperationManager *manger = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseUrl];
    
    manger.responseSerializer = [AFJSONResponseSerializer serializer];
    manger.requestSerializer  =[AFJSONRequestSerializer serializer];
//    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"charset=utf-8",nil];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:ContentType];

    manger.securityPolicy.allowInvalidCertificates = YES;

    
//    [manger.requestSerializer setValue:@"application/json" forHTTPHeaderField:Content_Type];
    [manger.requestSerializer setValue:Content_Type_Value forHTTPHeaderField:Content_Type];

    
    AFJSONResponseSerializer *response = (AFJSONResponseSerializer *)manger.responseSerializer;
    response.removesKeysWithNullValues = YES;
    
    manger.requestSerializer.timeoutInterval = 25;
    
    switch (methodType) {
        case RequestMethodTypeGet:
        {
            //GET请求
            [manger GET:url parameters:params
                success:^(AFHTTPRequestOperation *operation, id responseObject) {
                    if (operation.response.statusCode == 200) {
                        success(responseObject);
                    }else{
                        success(nil);
                    }
                } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                    
                    failure(error);
                }];
        }
            break;
        case RequestMethodTypePost:
        {
            //POST请求
            [manger POST:url parameters:params
                 success:^(AFHTTPRequestOperation* operation, NSDictionary* responseObj) {
                     if (operation.response.statusCode == 200) {
                         success(responseObj);
                     }else{
                         success(nil);
                     }
                 } failure:^(AFHTTPRequestOperation* operation, NSError* error) {
                     if (error) {
                         failure(error);
                     }
                 }];
        }
            break;
        default:
            break;
    }
}


@end
