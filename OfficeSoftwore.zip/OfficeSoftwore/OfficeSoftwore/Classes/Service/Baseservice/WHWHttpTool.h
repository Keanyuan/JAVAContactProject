//
//  WHWHttpTool.h
//  Afdemo
//
//  Created by wenhaiwang on 
//  Copyright (c) 2015年 wenhaiwang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseService.h"

@interface WHWHttpTool : NSObject

+ (WHWHttpTool *)shareWHWHTTPTool;


//联系人--1
- (void)getContractListToken:(NSString *)token
                     success:(void (^)(id response))success
                     failure:(void (^) (NSError *error))failure;

//登陆
- (void)loginWithUserAccount:(NSString *)userAccount
                    passward:(NSString *)passward
                  deviceType:(NSString *)deviceType
                     success:(void(^)(id reponse))success
                     failure:(void (^)(NSError *error))failure;


//免登陆
- (void)notLoginWithUserToken:(NSString *)token
                      success:(void(^)(id reponse))success
                      failure:(void (^)(NSError *error))failure;


//关于
- (void)aboutWithSuccess:(void(^)(id reponse))success
                 failure:(void (^)(NSError *error))failure;



//代办流程
- (void)waitWithUserToken:(NSString *)token
                     type:(NSString *)type
                   tittle:(NSString *)tittle
                 pageSize:(NSInteger)pageSize
         currentPageIndex:(NSInteger)currentPageIndex
                  success:(void(^)(id reponse))success
                  failure:(void (^)(NSError *error))failure;


//已办流程
- (void)completeWithUserToken:(NSString *)token
                         type:(NSString *)type
                       tittle:(NSString *)tittle
                     pageSize:(NSInteger)pageSize
             currentPageIndex:(NSInteger)currentPageIndex
                      success:(void(^)(id reponse))success
                      failure:(void (^)(NSError *error))failure;


//通知公告
- (void)noticeWithUserToken:(NSString *)token
                     tittle:(NSString *)tittle
                   pageSize:(NSString *)pageSize
           currentPageIndex:(NSString *)currentPageIndex
                    success:(void(^)(id reponse))success
                    failure:(void (^)(NSError *error))failure;

//个人消息---
- (void)PersonMassageWithUserToken:(NSString *)token
                            tittle:(NSString *)tittle
                          pageSize:(NSString *)pageSize
                  currentPageIndex:(NSString *)currentPageIndex
                           success:(void(^)(id reponse))success
                           failure:(void (^)(NSError *error))failure;
//签到
- (void)SignWithUserToken:(NSString *)token
                  picture:(NSData *)picture
                longitude:(NSString *)longitude
                lantitude:(NSString *)lantitude
             locationName:(NSString *)locationName
                  success:(void(^)(id reponse))success
                  failure:(void (^)(NSError *error))failure;
//签退
- (void) SignoutWithUserToken:(NSString *)token
                      picture:(NSData *)picture
                    longitude:(NSString *)longitude
                    lantitude:(NSString *)lantitude
                 locationName:(NSString *)locationName
                      success:(void(^)(id reponse))success
                      failure:(void (^)(NSError *error))failure;

//签到签退状态
-(void) SignStatusToken:(NSString *)token
                success:(void(^)(id reponse))success
                failure:(void (^)(NSError *error))failure;

//会议通知
- (void)meetingWithUserToken:(NSString *)token
                      tittle:(NSString *)tittle
                    pageSize:(NSString *)pageSize
            currentPageIndex:(NSString *)currentPageIndex
                     success:(void(^)(id reponse))success
                     failure:(void (^)(NSError *error))failure;

//待办数量
- (void)waitCountUserToken:(NSString *)token
                      type:(NSString *)type
                    tittle:(NSString *)tittle
                   success:(void(^)(id reponse))success
                   failure:(void (^)(NSError *error))failure;


//广告barner
- (void)AdScrollWithToken:(NSString *)token
                  success:(void(^)(id reponse))success
                  failure:(void (^)(NSError *error))failure;

//验证token
- (void)calendarWithToken:(NSString *)token
                  Success:(void(^)(id reponse))success
                  failure:(void (^)(NSError *error))failure;


//获取个人信息
- (void)loginUserInforToken:(NSString *)token
                 clientType:(NSString *)clientType
              clientVersion:(NSString *)clientVersion
                    success:(void(^)(id reponse))success
                    failure:(void (^)(NSError *error))failure;

//获取昵称名字
- (void)getAllEaseMobNicknameToken:(NSString *)token
                           success:(void(^)(id reponse))success
                           failure:(void (^)(NSError *error))failure;

//是否创建注册入口
- (void)createRegisteredEntranceVersion:(NSString *)version
                                success:(void(^)(id reponse))success
                                failure:(void (^)(NSError *error))failure;




@end
