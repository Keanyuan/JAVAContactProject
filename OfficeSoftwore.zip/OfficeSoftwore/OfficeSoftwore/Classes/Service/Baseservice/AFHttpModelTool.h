//
//  AFHttpModelTool.h
//  Afdemo
//
//  Created by wenhaiwang on 15
//  Copyright (c) 2015年 wenhaiwang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ContractModel,LoginModel,AboutModel,WaitModel,CompleteModel,NoticeModel,MeetingModel,WaitCountModel,NotLoginModel,PersonModel,SignModel,AdScrollModel,calendarModel,SignListModel,SignStatusModel,UserInfoModel,NickNameModel,RegisterModel;
@interface AFHttpModelTool : NSObject
+ (AFHttpModelTool *)shareAFHttpModelTool;


//联系人
-(void) getContractListToken:(NSString *)token
                  Completion:(void (^)(ContractModel *user)) completion
                     failure:(void (^) (NSError *error))failure;


//登陆
-(void) getLoginUserAccount:(NSString *)userAccount
                   passward:(NSString *)passward
                 deviceType:(NSString *)deviceType
                 Completion:(void (^)(LoginModel *login)) completion
                    failure:(void (^) (NSError *error))failure;

//免登陆
- (void)getNotLoginWithUserToken:(NSString *)token
                      Completion:(void (^)(NotLoginModel *notLoginModel)) completion
                         failure:(void (^) (NSError *error))failure;



//关于
- (void)getAboutCompletion:(void(^)(AboutModel *about))completion
                   failure:(void (^)(NSError *error))failure;


//代办流程
- (void)getWaitWithUserToken:(NSString *)token
                        type:(NSString *)type
                      tittle:(NSString *)tittle
                    pageSize:(NSInteger)pageSize
            currentPageIndex:(NSInteger)currentPageIndex
                  Completion:(void(^)(WaitModel *waitProgress))completion
                     failure:(void (^)(NSError *error))failure;

//已办流程
- (void)getCompleteWithUserToken:(NSString *)token
                            type:(NSString *)type
                          tittle:(NSString *)tittle
                        pageSize:(NSInteger)pageSize
                currentPageIndex:(NSInteger)currentPageIndex
                      Completion:(void(^)(CompleteModel *completeModel))completion
                         failure:(void (^)(NSError *error))failure;

//公司公告
- (void)getNoticeWithUserToken:(NSString *)token
                        tittle:(NSString *)tittle
                      pageSize:(NSInteger)pageSize
              currentPageIndex:(NSInteger)currentPageIndex
                    Completion:(void(^)(NoticeModel *noticeModel))completion
                       failure:(void (^)(NSError *error))failure;
//个人消息
- (void)getPersonMassageWithUserToken:(NSString *)token
                               tittle:(NSString *)tittle
                             pageSize:(NSInteger)pageSize
                     currentPageIndex:(NSInteger)currentPageIndex
                           Completion:(void(^)(PersonModel *personModel))completion
                              failure:(void (^)(NSError *error))failure;

//签到
- (void)PostSignWithUserToken:(NSString *)token
                      picture:(NSData *)picture
                    longitude:(NSString *)longitude
                    lantitude:(NSString *)lantitude
                 locationName:(NSString *)locationName
                   Completion:(void(^)(SignModel *signModel))completion
                      failure:(void (^)(NSError *error))failure;
//签退
- (void)PostSignoutWithUserToken:(NSString *)token
                         picture:(NSData *)picture
                       longitude:(NSString *)longitude
                       lantitude:(NSString *)lantitude
                    locationName:(NSString *)locationName
                      Completion:(void(^)(SignListModel *signlistModel))completion
                         failure:(void (^)(NSError *error))failure;

//签到签退状态
-(void)PostSignStatusToken:(NSString *)token
                Completion:(void(^)(SignStatusModel *signStatusModel))completion
                   failure:(void (^)(NSError *error))failure;


//会议通知
- (void)getMeetingWithUserToken:(NSString *)token
                         tittle:(NSString *)tittle
                       pageSize:(NSInteger)pageSize
               currentPageIndex:(NSInteger)currentPageIndex
                     Completion:(void(^)(MeetingModel *meetingModel))completion
                        failure:(void (^)(NSError *error))failure;

//代办数量
- (void)getWaitCountWithUserToken:(NSString *)token
                             type:(NSString *)type
                           tittle:(NSString *)tittle
                       Completion:(void(^)(WaitCountModel *waitCountModel))completion
                          failure:(void (^)(NSError *error))failure;

//广告
- (void)getAdScrollWithToken:(NSString *)token
                  Completion:(void(^)(AdScrollModel *adscrollModel))completion
                     failure:(void (^)(NSError *error))failure;

//日历
- (void)getcalendarWithToken:(NSString *)token
                  Completion:(void(^)(calendarModel *calendModel))completion
                     failure:(void (^)(NSError *error))failure;


//更新&获取个人信息
- (void)getloginUserInforToken:(NSString *)token
                    clientType:(NSString *)clientType
                 clientVersion:(NSString *)clientVersion
                    Completion:(void(^)(PersonModel * person))completion
                       failure:(void (^)(NSError *error))failure;

//获取昵称名字
- (void)getAllEaseMobNicknameToken:(NSString *)token
                           Completion:(void(^)(NickNameModel *nick_Name))completion
                           failure:(void (^)(NSError *error))failure;

//是否创建注册入口
- (void)createRegisteredEntranceVersion:(NSString *)version
                             Completion:(void(^)(RegisterModel *registerModel))Completion
                                failure:(void (^)(NSError *error))failure;




@end
