//
//  BaseService.h
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, RequestMethodType){
    RequestMethodTypePost = 1,
    RequestMethodTypeGet = 2,
    RequestMethodTypeImagePost = 3

};

@interface BaseService : NSObject

/**
 *  发送一个请求
 *
 *  @param methodType   请求方法
 *  @param url          请求路径
 *  @param params       请求参数
 *  @param success      请求成功后的回调（请将请求成功后想做的事情写到这个block中）
 *  @param failure      请求失败后的回调（请将请求失败后想做的事情写到这个block中）
 */

+ (void) requestWithMethod:(RequestMethodType)methodType
                requestUrl:(NSString *)url
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure;

//登陆接口
+ (void) requestLoginWithrequestUrl:(NSString *)url
                             params:(NSDictionary *)params
                            success:(void (^)(id response))success
                            failure:(void (^)(NSError *err))failure;
//请求图片
-(void)uploadImageWithUrl:(NSString *)url
                     image:(UIImage *)image
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure;
//签到签退
+ (void)kuploadImageWithUrl:(NSString *)url
                      image:(UIImage *)image
                     params:(NSDictionary *)params
                    success:(void (^)(id response))success
                    failure:(void (^)(NSError *err))failure;

+ (void) rrrrequestWithMethod:(RequestMethodType)methodType
                requestUrl:(NSString *)url
                    params:(NSDictionary *)params
                   success:(void (^)(id response))success
                   failure:(void (^)(NSError *err))failure;

@end
