//
//  AFHttpModelTool.m
//  Afdemo
//
//  Created by wenhaiwang on
//  Copyright (c) 2015年 wenhaiwang. All rights reserved.
//

#import "AFHttpModelTool.h"
#import "WHWHttpTool.h"
#import "ContracListModel.h"
#import "ContractModel.h"
#import "LoginModel.h"
#import "AboutModel.h"
#import "WaitModel.h"
#import "CompleteModel.h"
#import "NoticeModel.h"
#import "MeetingModel.h"
#import "WaitCountModel.h"
#import "NotLoginModel.h"
#import "PersonModel.h"
#import "SignModel.h"
#import "SignListModel.h"
#import "SignStatusModel.h"
#import "AdScrollModel.h"
#import "calendarModel.h"
#import "NickNameModel.h"
#import "NickListModel.h"
#import "RegisterModel.h"

@implementation AFHttpModelTool
static AFHttpModelTool *AFModelTool = nil;
+ (AFHttpModelTool *)shareAFHttpModelTool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        AFModelTool = [[self alloc] init];
    });
    return AFModelTool;
}



//获取联系人信息
-(void) getContractListToken:(NSString *)token
                  Completion:(void (^)(ContractModel *user)) completion
                     failure:(void (^) (NSError *error))failure{
    [[WHWHttpTool shareWHWHTTPTool] getContractListToken:token
                                                 success:^(id response) {
                                                     NSLog(@"response == %@",response);
        if (response) {
            NSDictionary *dic = (NSDictionary *)response;
            ContractModel *contractModel = [MTLJSONAdapter modelOfClass:[ContractModel class]
                                                     fromJSONDictionary:dic
                                                                  error:nil];
            completion(contractModel);
        }
    } failure:failure];
}

//登陆
-(void) getLoginUserAccount:(NSString *)userAccount
                   passward:(NSString *)passward
                 deviceType:(NSString *)deviceType
                 Completion:(void (^)(LoginModel *login)) completion
                    failure:(void (^) (NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] loginWithUserAccount:userAccount
                                                passward:passward
                                              deviceType:deviceType
                                                 success:^(id reponse) {
        if (reponse) {
            
            NSDictionary *dic = (NSDictionary *)reponse;
            LoginModel *loginModel = [MTLJSONAdapter modelOfClass:[LoginModel class]
                                               fromJSONDictionary:dic
                                                            error:nil];
            completion(loginModel);
        }
    } failure:failure];
}

//免登陆
- (void)getNotLoginWithUserToken:(NSString *)token
                      Completion:(void (^)(NotLoginModel *notLoginModel)) completion
                         failure:(void (^) (NSError *error))failure;
{
    [[WHWHttpTool shareWHWHTTPTool] notLoginWithUserToken:token
                                                 success:^(id reponse) {
                                                     if (reponse) {
                                                         
                                                         NSDictionary *dic = (NSDictionary *)reponse;
                                                         NotLoginModel *loginModel = [MTLJSONAdapter modelOfClass:[NotLoginModel class]
                                                                                            fromJSONDictionary:dic
                                                                                                         error:nil];
                                                         completion(loginModel);
                                                     }
                                                 } failure:failure];

}

//关于
- (void)getAboutCompletion:(void(^)(AboutModel *about))completion
                   failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] aboutWithSuccess:^(id reponse) {
        if (reponse) {
            NSDictionary *dic = (NSDictionary *)reponse;
            AboutModel *aboutModel = [MTLJSONAdapter modelOfClass:[AboutModel class]
                                               fromJSONDictionary:dic
                                                            error:nil];
            completion(aboutModel);
        }
    } failure:failure];
}

//代办流程
- (void)getWaitWithUserToken:(NSString *)token
                        type:(NSString *)type
                      tittle:(NSString *)tittle
                    pageSize:(NSInteger)pageSize
            currentPageIndex:(NSInteger)currentPageIndex
                  Completion:(void(^)(WaitModel *waitProgress))completion
                     failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] waitWithUserToken:token
                                                 type:type
                                               tittle:tittle
                                             pageSize:pageSize
                                     currentPageIndex:currentPageIndex
                                              success:^(id reponse) {
                                                  if (reponse) {
                                                      NSDictionary *dic = (NSDictionary *)reponse;
                                                      
                                                      WaitModel *waitModel = [MTLJSONAdapter modelOfClass:[WaitModel class]
                                                                                       fromJSONDictionary:dic
                                                                                                    error:nil];
                                                      completion(waitModel);
                                                  }
                                                  
                                              } failure:failure];
    
}

//已办流程
- (void)getCompleteWithUserToken:(NSString *)token
                            type:(NSString *)type
                          tittle:(NSString *)tittle
                        pageSize:(NSInteger)pageSize
                currentPageIndex:(NSInteger)currentPageIndex
                      Completion:(void(^)(CompleteModel *completeModel))completion
                         failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] completeWithUserToken:token
                                                     type:type
                                                   tittle:tittle
                                                 pageSize:pageSize
                                         currentPageIndex:currentPageIndex
                                                  success:^(id reponse) {
                                                      if (reponse) {
                                                          NSDictionary *dic = (NSDictionary *)reponse;
                                                          CompleteModel *completeModel = [MTLJSONAdapter modelOfClass:[CompleteModel class]
                                                                                                   fromJSONDictionary:dic
                                                                                                                error:nil];
                                                          completion(completeModel);
                                                      }
                                                      
                                                  } failure:failure];
}

//公司公告
- (void)getNoticeWithUserToken:(NSString *)token
                        tittle:(NSString *)tittle
                      pageSize:(NSInteger)pageSize
              currentPageIndex:(NSInteger)currentPageIndex
                    Completion:(void(^)(NoticeModel *noticeModel))completion
                       failure:(void (^)(NSError *error))failure
{
    NSString *pageSizeString = [NSString stringWithFormat:@"%ld",(long)pageSize];
    NSString *currentPageIndexString = [NSString stringWithFormat:@"%ld",(long)currentPageIndex];
    
    [[WHWHttpTool shareWHWHTTPTool] noticeWithUserToken:token
                                                 tittle:tittle
                                               pageSize:pageSizeString
                                       currentPageIndex:currentPageIndexString
                                                success:^(id reponse) {
                                                    if (reponse) {
                                                        NSDictionary *dic = (NSDictionary *)reponse;
                                                        NSLog(@"--------/%@",reponse);

                                                        NoticeModel *noticeModel = [MTLJSONAdapter modelOfClass:[NoticeModel class]
                                                                                             fromJSONDictionary:dic
                                                                                                          error:nil];
                                                        completion(noticeModel);
                                                    }
                                                    
                                                } failure:failure];
    
}
//个人消息
- (void)getPersonMassageWithUserToken:(NSString *)token
                               tittle:(NSString *)tittle
                             pageSize:(NSInteger)pageSize
                     currentPageIndex:(NSInteger)currentPageIndex
                           Completion:(void(^)(PersonModel *personModel))completion
                              failure:(void (^)(NSError *error))failure
{
    NSString *pageSizeString = [NSString stringWithFormat:@"%ld",(long)pageSize];
    NSString *currentPageIndexString = [NSString stringWithFormat:@"%ld",(long)currentPageIndex];
    
    [[WHWHttpTool shareWHWHTTPTool] PersonMassageWithUserToken:token
                                                        tittle:tittle
                                                      pageSize:pageSizeString
                                              currentPageIndex:currentPageIndexString
                                                       success:^(id reponse) {
                                                           if (reponse) {
                                                                
                                                               NSDictionary *dic = (NSDictionary *)reponse;
                                                               NSLog(@"--------/%@",reponse);
                                                               PersonModel *personModel = [MTLJSONAdapter modelOfClass:[PersonModel class]
                                                                                                        fromJSONDictionary:dic
                                                                                                                     error:nil];
                                                                    completion(personModel);
                                                                }
                                                            
                                                            } failure:failure];
            
}
//签到
- (void)PostSignWithUserToken:(NSString *)token
                      picture:(NSData *)picture
                    longitude:(NSString *)longitude
                    lantitude:(NSString *)lantitude
                 locationName:(NSString *)locationName
                   Completion:(void(^)(SignModel *signModel))completion
                      failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] SignWithUserToken:token
                                              picture:picture
                                            longitude:longitude
                                            lantitude:lantitude
                                         locationName:locationName
                                              success:^(id reponse) {
                                                  NSDictionary *dic = (NSDictionary *)reponse;
                                                  SignModel *signModel = [MTLJSONAdapter modelOfClass:[SignModel class] fromJSONDictionary:dic error:nil];
                                                  completion(signModel);
        
                                              } failure:failure];
}
//签退
- (void)PostSignoutWithUserToken:(NSString *)token
                         picture:(NSData *)picture
                       longitude:(NSString *)longitude
                       lantitude:(NSString *)lantitude
                    locationName:(NSString *)locationName
                      Completion:(void(^)(SignListModel *signlistModel))completion
                         failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] SignoutWithUserToken:token
                                                 picture:picture
                                               longitude:longitude
                                               lantitude:lantitude
                                            locationName:locationName
                                                 success:^(id reponse) {
                                                     NSDictionary *dic = (NSDictionary *)reponse;
                                                     SignListModel *signlistModel = [MTLJSONAdapter modelOfClass:[SignListModel class] fromJSONDictionary:dic error:nil];
                                                     completion(signlistModel);
                                                 } failure:failure];
}

//签到签退状态
-(void)PostSignStatusToken:(NSString *)token
                Completion:(void(^)(SignStatusModel *signStatusModel))completion
                   failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] SignStatusToken:token
                                            success:^(id reponse) {
                                                NSDictionary *dic = (NSDictionary *)reponse;
                                                SignStatusModel *signStatusModel = [MTLJSONAdapter modelOfClass:[SignStatusModel class] fromJSONDictionary:dic error:nil];
                                                completion(signStatusModel);
                                                
                                            } failure:failure];
}

//会议通知
- (void)getMeetingWithUserToken:(NSString *)token
                         tittle:(NSString *)tittle
                       pageSize:(NSInteger)pageSize
               currentPageIndex:(NSInteger)currentPageIndex
                     Completion:(void(^)(MeetingModel *meetingModel))completion
                        failure:(void (^)(NSError *error))failure
{
    NSString *pageSizeString = [NSString stringWithFormat:@"%ld",(long)pageSize];
    NSString *currentPageIndexString = [NSString stringWithFormat:@"%ld",(long)currentPageIndex];
    
    [[WHWHttpTool shareWHWHTTPTool] meetingWithUserToken:token
                                                  tittle:tittle
                                                pageSize:pageSizeString
                                        currentPageIndex:currentPageIndexString
                                                 success:^(id reponse) {
                                                     if (reponse) {
                                                         
                                                         NSDictionary *dic = (NSDictionary *)reponse;
                                                         MeetingModel *meetingModel = [MTLJSONAdapter modelOfClass:[MeetingModel class]
                                                                                                fromJSONDictionary:dic
                                                                                                             error:nil];
                                                         completion(meetingModel);
                                                     }
                                                     
                                                 } failure:failure];
}

//代办数量
- (void)getWaitCountWithUserToken:(NSString *)token
                             type:(NSString *)type
                           tittle:(NSString *)tittle
                       Completion:(void(^)(WaitCountModel *waitCountModel))completion
                          failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] waitCountUserToken:token
                                                  type:type
                                                tittle:tittle
                                               success:^(id reponse) {
                                                   if (reponse) {
                                                       NSDictionary *dic = (NSDictionary *)reponse;
                                                       WaitCountModel *waitCountModel = [MTLJSONAdapter modelOfClass:[WaitCountModel class]
                                                                                                  fromJSONDictionary:dic
                                                                                                               error:nil];
                                                       completion(waitCountModel);
                                                   }
                                                   
                                               } failure:failure];
}

//广告
- (void)getAdScrollWithToken:(NSString *)token
                  Completion:(void(^)(AdScrollModel *adscrollModel))completion
                     failure:(void (^)(NSError *error))failure
{
    
    [[WHWHttpTool shareWHWHTTPTool] AdScrollWithToken:token
                                              success:^(id reponse) {
                                                  NSLog(@"---------/%@",reponse);
                                                    if (reponse) {
                                                        NSDictionary *dic = (NSDictionary *)reponse;
                                                        AdScrollModel *adscrollModel = [MTLJSONAdapter modelOfClass:[AdScrollModel class]
                                                                                            fromJSONDictionary:dic
                                                                                                              error:nil];
                                                                completion(adscrollModel);
                                                        }
                                                    } failure:failure];

}
//日历
- (void)getcalendarWithToken:(NSString *)token
                  Completion:(void(^)(calendarModel *calendModel))completion
                     failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] calendarWithToken:token
                                              Success:^(id reponse) {
                                                  if (reponse) {
                                                      NSDictionary *dic = (NSDictionary *)reponse;
                                                      calendarModel *calendModel = [MTLJSONAdapter modelOfClass:[calendarModel class] fromJSONDictionary:dic error:nil];
                                                      completion(calendModel);
                                                  }
                                              } failure:failure];
}




//更新&获取个人信息
- (void)getloginUserInforToken:(NSString *)token
                    clientType:(NSString *)clientType
                 clientVersion:(NSString *)clientVersion
                    Completion:(void(^)(PersonModel * person))completion
                       failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] loginUserInforToken:token
                                             clientType:clientType
                                          clientVersion:clientVersion
                                                success:^(id reponse) {
                                                    NSDictionary *dict = (NSDictionary *)reponse;
                                                    PersonModel *person = [MTLJSONAdapter modelOfClass:[PersonModel class] fromJSONDictionary:dict error:nil];
                                                    completion (person);
                                                } failure:failure];
}

//获取昵称名字
- (void)getAllEaseMobNicknameToken:(NSString *)token
                        Completion:(void(^)(NickNameModel *nick_Name))completion
                           failure:(void (^)(NSError *error))failure
{
    [[WHWHttpTool shareWHWHTTPTool] getAllEaseMobNicknameToken:token
                                                       success:^(id reponse) {
                                                           
                                                           if (reponse) {
                                                               NSDictionary *dict = (NSDictionary *)reponse;
                                                               NickNameModel *nickNamemodel = [MTLJSONAdapter modelOfClass:[NickNameModel class] fromJSONDictionary:dict error:nil];
                                                               completion (nickNamemodel);
                                                           }
                                                           
                                                       } failure:failure];
}
//是否创建注册入口
- (void)createRegisteredEntranceVersion:(NSString *)version
                             Completion:(void(^)(RegisterModel *registerModel))Completion
                                failure:(void (^)(NSError *error))failure
{
   [[WHWHttpTool shareWHWHTTPTool] createRegisteredEntranceVersion:version
                                                           success:^(id reponse) {
                                                               NSDictionary *dic = (NSDictionary *)reponse;
                                                               RegisterModel *registerModel = [MTLJSONAdapter modelOfClass:[RegisterModel class] fromJSONDictionary:dic error:nil];
                                                               Completion (registerModel);
                                                               
                                                           } failure:failure];
}

@end
