
//  Header.h
//  OfficeSoftwore
//
//  Copyright © 2015年 wangwang. All rights reserved.
//

#ifndef Header_h
#define Header_h
#define IS_IPHONE_4S ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )480 ) < DBL_EPSILON )
#define IS_IPHONE_5  ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )
#define IS_IPHONE_6  ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )667 ) < DBL_EPSILON )
#define IS_IPHONE_6P ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )736 ) < DBL_EPSILON )
#define IS_IPHONE_PX ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )812 ) < DBL_EPSILON )

#define OA_AppDelegate (AppDelegate *)[[UIApplication sharedApplication] delegate]

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#define showMsg(msg) \
{UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:msg delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];\
[alertView show];}

#define ShowMassage(massage)\
{UIAlertController *alertcontrol = [UIAlertController alertControllerWithTitle:massage message:nil preferredStyle:UIAlertControllerStyleAlert];\
UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];\
[alertcontrol addAction:sureAction];\
[self presentViewController:alertcontrol animated:YES completion:nil];}

#pragma mark - Device information
#define DEFAULTCENTER                   [NSNotificationCenter defaultCenter];
#define MODEL_NAME                      [[UIDevice currentDevice] model]
#define MODEL_VERSION                   [[[UIDevice currentDevice] systemVersion] floatValue]
#define APP_SCREEN_WIDTH                [UIScreen mainScreen].bounds.size.width
#define APP_SCREEN_HEIGHT               [UIScreen mainScreen].bounds.size.height
#define SCREEN_MAX_LENGTH               MAX(APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT)
#define SCREEN_MIN_LENGTH               MIN(APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT)

//#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
//#define IS_IPHONE_4_OR_LESS (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
//#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
//#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
//#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)

#define BUTTON_TAG                      100
#define BUTTON_WP_TAG                   300

#define  LOGIN_USERNAME                 @"LOGIN_USERNAME"

#define  USERNAME                       @"USERNAME"
#define  PASSWORD                       @"PASSWORD"
#define  TOKEN                          @"TOKEN"
#define  ALL                            @"All"
#define  isLaunchedByNotification       @"isLaunchedByNotification"

#define BecomeActive                    @"becomeActive"

#define BADGE                           @"BADGE" 
#define UNIT_NAME                       @"UNIT_NAME"
#define NICK_NAME                       @"NICK_NAME"
#define EASE_PASS_WORD                  @"EASE_OASS_WORD"

#define USERDEFAUTS [NSUserDefaults standardUserDefaults];


#define ContentType                     @"text/html"
#define Content_Type                    @"Content-Type"
#define Content_Type_Value              @"application/x-www-form-urlencoded"

//#define _AFNETWORKING_ALLOW_INVALID_SSL_CERTIFICATES_

#define NSRecordCountDidBecomeMainNotification       @"recordCount"
#define TabBarNotificationBadgeValue                 @"TabBarNotificationBadgeValue"
#define NetworkReachabilityStatusNotReachable        @"NetworkReachabilityStatusNotReachable"
#define NetworkDidReceiveMessage                     @"NetworkDidReceiveMessage"
#endif /* Header_h */



//color
#define Maincolor [UIColor colorWithHexString:@"#f0f9fc"]
#define Gcolor(textstring) [UIColor colorWithHexString:textstring]

//font

#define  Font(text) [UIFont systemFontOfSize:text]

//百度地图KEY
#define BMK_MAP_KEY_Dist                @"3nOB9HMj7kLhNbUn70C0okCktIEwZMtk"

//环信key
#define EASE_KEY                        @"anji-allways#myallwaysofficeautomation"

//#define EASE_DEV_dis                    @"OA_PUSH_DEV2"
#define EASE_DEV_dis                    @"OA_PUSH_DIS"





