//
//  serverUrl.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/29.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#ifndef serverUrl_h
#define serverUrl_h


//////生产环境
#define DEV_FAKE_SERVER     @"http://oaapp.anji-allways.com:800/"              //服务器地址
#define LOGIN_FAKE_SERVER   @"https://oaapp.anji-allways.com:881/"             //登陆服务器地址
#define APPLY_URL           @"http://oaapp.anji-allways.com:800/"              //个人申请服务器地址

//测试环境
//#define DEV_FAKE_SERVER        @"http://10.108.10.52:80/"                       // 服务器地址
//#define LOGIN_FAKE_SERVER      @"https://10.108.10.52:81/"                      // 登录服务器地址
//#define LOGIN_FAKE_SERVER      @"https://oa.ssssssa.com:82/"                      // 登录服务器地址
//#define APPLY_URL              @"http://10.108.10.52/"                          // 个人申请地址

//测试环境
//#define DEV_FAKE_SERVER        @"http://oa.anji-allwaystest.com"                       // 服务器地址
//#define LOGIN_FAKE_SERVER      @"https://oaapp.anji-allwaystest.com:81"                // 登录服务器地址
//#define APPLY_URL              @"http://oa.anji-allwaystest.com"                       // 个人申请地址

//oaapp.anji-allwaystest.com
//oa.anji-allwaystest.com

//登陆地址
#define LOGIN_SERVER_URL            @"webapi/CommonHelper.ashx"                 //登陆地址

//其他地址

#define POSTIMAGE_SERVER_url        @"Hander/SaveDoc.ashx"                      //上传图片
#define CONTRACT_SERVER_url         @"webapi/commonhelper.ashx"                 //联系人地址
#define ABOUNT_SERVER_url           @"webapi/CommonHelper.ashx"                 //关于地址
#define WAIT_SERVER_url             @"webapi/CommonHelper.ashx"                 //代办地址
#define COMPLETE_SERVER_url         @"webapi/CommonHelper.ashx"                 //已办地址
#define NOTICE_SERVER_url           @"webapi/CommonHelper.ashx"                 //公告
#define MEETING_SERVER_url          @"webapi/CommonHelper.ashx"                 //会议
#define MEETING_COUNT_SERVER_url    @"webapi/CommonHelper.ashx"                 //待办数量
#define PERSONMESSAGE_SERVER_url    @"webapi/CommonHelper.ashx"                 //个人消息
#define SIGN_SERVER_url             @"webapi/CommonHelper.ashx"                 //签到
#define SIGNOUT_SERVER_url          @"webapi/CommonHelper.ashx"                 //签退
#define SIGNSTATUS_url              @"webapi/CommonHelper.ashx"                 //签到签退状态
#define AD_SCROLL_url               @"webapi/CommonHelper.ashx"                 //广告
#define CALENDAR_url                @"webapi/CommonHelper.ashx"                 //日历
#define SERVER_CHECK_VERSION        @"webapi/CommonHelper.ashx"                 //更新
#define USER_INFORMATION            @"webapi/CommonHelper.ashx"                 //用户信息
#define EASE_NAME                   @"webapi/CommonHelper.ashx"                 //环信获取昵称名字
#define APPLY_SUCCESS               @"UI/Success.html"                          //申请成功
#define REGISTER_url                @"webapi/CommonHelper.ashx"                 //注册
//#define COMMON_SERVER_URL           @"webapi/CommonHelper.ashx"


#endif /* serverUrl_h */
