//
//  MineViewController.h
//  OfficeSoftwore
//
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface MineViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
