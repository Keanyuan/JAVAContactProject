//
//  AboutViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/16.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface AboutViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
