//
//  MineViewController.m
//  OfficeSoftwore
//
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "MineViewController.h"
#import "AboutViewController.h"
#import "BaseService.h"
#import "PersonModel.h"
#import "PersonListModel.h"

@interface MineViewController ()<QRCodeReaderDelegate,UIActionSheetDelegate,UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    NSString                    *AboutCellText;
    UIImageView                 *touxiangImg;
    NSMutableArray              *nameArray;
    NSString                    *MyPoint;
    NSString                    *username;
}
@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [CommonMethod validateToken];

    self.navigationController.navigationBar.translucent = NO;
    
    nameArray = [[NSMutableArray alloc] init];
    self.tableView.bounces = NO;
    self.tableView.tableFooterView = [[UIView alloc]init];
//    self.tableView.tableHeaderView.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
    AboutCellText = [NSString stringWithFormat:@"上海安吉加加信息技术有限公司自主开发的办公自动化平台手机端APP应用，目的是为了实现员工可以通过手机端完成流程审批工作及自主考勤，提高办公效率，使工作更加省事、省力、省心。\n本软件的下载和使用完全免费。"];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //取用户部门名称
    MyPoint = [CommonMethod getUnitName];

}

#pragma mark- tableview

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 8;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 68;
    }else if (indexPath.section == 2){
        return 88;
    }else if (indexPath.section == 4){
        return 140;
    }else if (indexPath.section == 6){
        return 44;
    }
    return 20;

    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
//    userinfoListModel *userinfo = nil;
//    userinfo = nameArray[indexPath.row];
    
    if (indexPath.section == 0) {
        
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell_user"];
        touxiangImg = (UIImageView *)[cell.contentView viewWithTag:665];
        //取本地图片
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *imageFilePath = [documentsDirectory stringByAppendingPathComponent:@"selfPhoto.jpg"];
        NSLog(@"imageFile->>%@",imageFilePath);
        UIImage *selfPhoto = [UIImage imageWithContentsOfFile:imageFilePath];
        if (selfPhoto == nil) {
            touxiangImg.image = [UIImage imageNamed:@"customer"];
        }else{
//            touxiangImg.image = selfPhoto;
            touxiangImg.image = [UIImage imageNamed:@"customer"];

        }
        touxiangImg.layer.cornerRadius = CGRectGetHeight([touxiangImg bounds])/2;
        touxiangImg.layer.masksToBounds = YES;

        UIButton *touxiangBt = (UIButton *)[cell.contentView viewWithTag:664];
        [touxiangBt addTarget:self action:@selector(TXButtonClick) forControlEvents:UIControlEventTouchUpInside];
        
        
        UILabel *userLabel = (UILabel *)[cell.contentView viewWithTag:666];
        userLabel.text = [CommonMethod getLoginUserName];
//        userLabel.text = userinfo.UserName;
        
        UILabel *department = (UILabel *)[cell.contentView viewWithTag:667];
        department.text = MyPoint;
        NSLog(@"%@",MyPoint);
        
        UIView *userView = (UIView *)[cell.contentView viewWithTag:301];
        userView.layer.borderWidth = 1.0f;
        userView.layer.borderColor = [UIColor colorWithHexString:@"#dbd6d6"].CGColor;
        
    }else if (indexPath.section == 1||indexPath.section == 3||indexPath.section == 5||indexPath.section == 7){
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell_kong"];

    }else if (indexPath.section == 2){
        
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell_version"];
        
        UIView *userView = (UIView *)[cell.contentView viewWithTag:302];
        userView.layer.borderWidth = 1.0f;
        userView.layer.borderColor = [UIColor colorWithHexString:@"#dbd6d6"].CGColor;
        //版本号
        NSString *version = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
        UILabel *versionlable = (UILabel *)[cell.contentView viewWithTag:3022];
        versionlable.text = [NSString stringWithFormat:@"版本 %@",version];
        
        //缓存
        UILabel *cleanLabel = (UILabel *)[cell.contentView viewWithTag:200];
        cleanLabel.text = @"清除缓存";
        UILabel *cleanCountLabel = (UILabel *)[cell.contentView viewWithTag:201];
        NSString* cacheSize = [NSString stringWithFormat:@"%@",@([[SDImageCache sharedImageCache] getSize])];
        
        if (![cacheSize isEqualToString:@"0"])
        {
            cleanCountLabel.text = [NSString stringWithFormat:@"%.01f M",cacheSize.floatValue/1024.0/1024.0] ;
        }
        else
        {
            cleanCountLabel.text = @"0 KB";
        }

        UIButton *cacheBtn = (UIButton *)[cell.contentView viewWithTag:300];
        [cacheBtn addTarget:self action:@selector(cacheButtonClick) forControlEvents:UIControlEventTouchUpInside];
        
    }else if (indexPath.section == 4){
       
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell_about"];
        tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        
        UIView *userView = (UIView *)[cell.contentView viewWithTag:303];
        userView.layer.borderWidth = 1.0f;
        userView.layer.borderColor = [UIColor colorWithHexString:@"#dbd6d6"].CGColor;


        if (IS_IPHONE_4S||IS_IPHONE_5) {
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 4;// 字体的行间距
            
            NSDictionary *attributes = @{
                                         NSFontAttributeName:[UIFont systemFontOfSize:13],
                                         NSParagraphStyleAttributeName:paragraphStyle,
                                         NSForegroundColorAttributeName:[UIColor colorWithHexString:@"#474747"]
                                         };
            
            UITextView *textView = (UITextView *)[cell.contentView viewWithTag:100];
            textView.attributedText =  [[NSAttributedString alloc] initWithString:AboutCellText attributes:attributes];
            //设置textview不可编辑
            textView.editable = NO;
            textView.scrollEnabled = NO;//设置不可上下滑动
            paragraphStyle.headIndent = 5;
            paragraphStyle.firstLineHeadIndent = 5;//首行缩进
            
        }else{
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 7;// 字体的行间距
            
            NSDictionary *attributes = @{
                                         NSFontAttributeName:[UIFont systemFontOfSize:14],
                                         NSParagraphStyleAttributeName:paragraphStyle,
                                         NSForegroundColorAttributeName:[UIColor colorWithHexString:@"#474747"]
                                         };
            
            
            UITextView *textView = (UITextView *)[cell.contentView viewWithTag:100];
            textView.attributedText =  [[NSAttributedString alloc] initWithString:AboutCellText attributes:attributes];
            textView.editable = NO;
            paragraphStyle.headIndent = 2;
            paragraphStyle.firstLineHeadIndent = 2;

        }
        
    }else{
        
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell_quit"];
        
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        UIButton *quitBtn = (UIButton *)[cell.contentView viewWithTag:304];
        quitBtn.layer.borderWidth = 1.0f;
        quitBtn.layer.borderColor = [UIColor colorWithHexString:@"#dbd6d6"].CGColor;

    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell * cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

}

- (void)cacheButtonClick
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"是否清除缓存"
                                                                             message:@""
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *action){
                                                           [self clearCache];
                                                       }];
    [alertController addAction:cancleAction];
    [alertController addAction:sureAction];
    [self presentViewController:alertController animated:YES completion:nil];

}
//清除缓存
- (void)clearCache
{
    [self showLoadingView:@"清除缓存中..."];
    
    [SDWebImageManager.sharedManager.imageCache clearMemory];
    [SDWebImageManager.sharedManager.imageCache clearDisk];
    
    [[SDImageCache sharedImageCache] calculateSizeWithCompletionBlock:^(NSUInteger fileCount, NSUInteger totalSize) {

        [self hiddenLoadingView];
        
        [self.tableView reloadData];
    }];
    
}
#pragma mark - QRCodeReader Delegate Methods

- (void)reader:(QRCodeReaderViewController *)reader didScanResult:(NSString *)result
{
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:result delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        [alert show];
   
}

#pragma mark - UIAlertViewDelegate
//
//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    if (buttonIndex == 0) {
//        if ([alertView.message hasPrefix:@"http"]) {
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:alertView.message]];
//        }
//   }
//}

- (void)readerDidCancel:(QRCodeReaderViewController *)reader
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 退出账号UIAlertController
//退出账号按钮
- (IBAction)QuitLogin:(id)sender {
    
   UIAlertController *AlertControl = [UIAlertController alertControllerWithTitle:@"是否退出账号"
                                                                         message:@"退出或切换账号"
                                                                  preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *action){
                                                           [self ExitFromCurrentAccount];
                                                       }];
    [AlertControl addAction:cancelAction];
    [AlertControl addAction:sureAction];
    [self presentViewController:AlertControl animated:YES completion:nil];

}
//退出
-(void)ExitFromCurrentAccount{
    [self presentViewController:[[UIStoryboard storyboardWithName:@"Login"
                                                           bundle:nil] instantiateInitialViewController]
                                          animated:YES completion:^{
                                              NSString *tempuserid;
                                              tempuserid= [CommonMethod getuseridByKey:TOKEN];
                                              NSString *usernme;
                                              usernme= [CommonMethod getuseridByKey:USERNAME];
                                              NSLog(@"tempuserid===%@  =username==%@==",tempuserid,usernme);
                                              
                                              [CommonMethod removeObject:TOKEN];
                                              [CommonMethod removeObject:USERNAME];
                                              [CommonMethod removeObject:LOGIN_USERNAME];
                                              [CommonMethod removeObject:PASSWORD];
                                              [CommonMethod removeObject:ALL];
                                              [CommonMethod removeObject:isLaunchedByNotification];
                                              [CommonMethod removeObject:UNIT_NAME];
                                              [CommonMethod removeObject:EASE_PASS_WORD];
                                              //退出账号时退出环信账号
                                              EMError *error = [[EMClient sharedClient] logout:YES];
                                              if (!error) {
                                                  NSLog(@"退出成功");
                                              }
                                               tempuserid = [CommonMethod getuseridByKey:TOKEN];
                                               username = [CommonMethod getuseridByKey:USERNAME];

                                              NSLog(@"tempuserid===%@  =username==%@==",tempuserid,username);
        
                                              [JPUSHService setTags:NULL
                                                           alias:@""
                                                callbackSelector:@selector(tagsAliasCallback:tags:alias:)
                                                          target:self];
                                          }];
    //退出环信
    EMError *error = [[EMClient sharedClient] logout:YES];
    if (!error) {
        NSLog(@"退出成功");
    }
    
}

- (void)tagsAliasCallback:(int)iResCode
                     tags:(NSSet *)tags
                    alias:(NSString *)alias {
    NSLog(@"iResCode :%d, \nalias: %@\n", iResCode,alias);
}
#pragma mark---TXButtonClick:---
//调用相机相册
-(void)TXButtonClick{
    
    UIAlertController *alertControl = [UIAlertController alertControllerWithTitle:@"请选择图片来源"
                                                                          message:nil
                                                                   preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *calcelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *cameraAction = [UIAlertAction actionWithTitle:@"相机"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction *action){
                                                             if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                                                                 UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
                                                                 
                                                                 imagePicker.delegate = self;
                                                                 imagePicker.allowsEditing = YES;
                                                                 imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                                                 [self presentViewController:imagePicker animated:YES completion:nil];
                                                                 
                                                             }else{
                                                                 ShowMassage(@"相机不可用");
                                                             }
                                                         }];
    UIAlertAction *photoAction = [UIAlertAction actionWithTitle:@"相册"
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction *action){
                                                            UIImagePickerController*imagePicker = [[UIImagePickerController alloc] init];
                                                            imagePicker.delegate = self;
                                                            imagePicker.allowsEditing = YES;
                                                            imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                                            [self presentViewController:imagePicker animated:YES completion:nil];
                                                        }];
    [alertControl addAction:calcelAction];
    [alertControl addAction:cameraAction];
    [alertControl addAction:photoAction];
//    [self presentViewController:alertControl animated:YES completion:nil];
}
//取图片
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //    if ([[info objectForKey:UIImagePickerControllerMediaType] isEqualToString:(__bridge NSString *)kUTTypeImage]) {
    UIImage *img = [info objectForKey:UIImagePickerControllerEditedImage];
    
    NSLog(@"-----%f\n----%f",img.size.height,img.size.width);
    
    [self performSelector:@selector(saveImage:) withObject:img afterDelay:0.5];
    
    //    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}
//取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}
//保存图片
- (void)saveImage:(UIImage *)image{
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths  objectAtIndex:0];
    NSString *imageFilePath = [documentsDirectory stringByAppendingPathComponent:@"selfPhoto.jpg"];
    NSLog(@"imageFile->>%@",imageFilePath);
    success = [fileManager fileExistsAtPath:imageFilePath];
    if(success) {
        success = [fileManager removeItemAtPath:imageFilePath error:&error];
    }
    UIImage *smallImage=[self scaleFromImage:image toSize:CGSizeMake(80.0f, 80.0f)];//改变图片尺寸
    //    UIImage *smallImage = [self thumbnailWithImageWithoutScale:image size:CGSizeMake(80, 80)];
    [UIImageJPEGRepresentation(smallImage, 1.0f) writeToFile:imageFilePath atomically:YES];//写入文件
    UIImage *selfPhoto = [UIImage imageWithContentsOfFile:imageFilePath];//读取图片文件
    touxiangImg.image = selfPhoto;
    NSLog(@"%f%f",touxiangImg.image.size.width,touxiangImg.image.size.height);

}

//改变图像的尺寸
- (UIImage *) scaleFromImage: (UIImage *) image toSize: (CGSize) size
{
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
//改变尺寸（2）
- (UIImage *)thumbnailWithImageWithoutScale:(UIImage *)image size:(CGSize)asize
{
    UIImage *newimage;
    if (nil == image) {
        newimage = nil;
    }
    else{
        CGSize oldsize = image.size;
        CGRect rect;
        if (asize.width/asize.height > oldsize.width/oldsize.height) {
//            rect.size.width = asize.height*oldsize.width/oldsize.height;
            rect.size.width = asize.height;//*oldsize.width/oldsize.height;

            rect.size.height = asize.height;
            rect.origin.x = (asize.width - rect.size.width)/2;
            rect.origin.y = 0;
        }
        else{
            rect.size.width = asize.width;
//            rect.size.height = asize.width*oldsize.height/oldsize.width;
            rect.size.height = asize.width;//*oldsize.height/oldsize.width;
            rect.origin.x = 0;
            rect.origin.y = (asize.height - rect.size.height)/2;
        }
        UIGraphicsBeginImageContext(asize);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextSetFillColorWithColor(context, [[UIColor clearColor] CGColor]);
        UIRectFill(CGRectMake(0, 0, asize.width, asize.height));//clear background
        [image drawInRect:rect];
        newimage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    return newimage;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
