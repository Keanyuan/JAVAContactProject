//
//  AboutViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/16.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "AboutViewController.h"
#import "AboutModel.h"

@interface AboutViewController ()<UIWebViewDelegate>

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"关于";
    [self initView];

    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView.scalesPageToFit = NO;
    _webView.delegate = self;
    _webView.scrollView.bounces = NO;
    
    [self webViewRequestData:self.webView];
}

- (void)webViewRequestData:(UIWebView *)webView{
    [self showLoadingView:nil];
    [[AFHttpModelTool shareAFHttpModelTool] getAboutCompletion:^(AboutModel *about) {
        
        if ([about.status isEqualToString:@"success"]) {
            [CommonMethod webViewRequest:webView
                                     url:about.result];
        }

    } failure:^(NSError *error) {
        [self hiddenLoadingView];
        [self showOnlyTextAlertView:@"加载失败,请检查为网络"];
    }];
}
- (void)initView
{
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"backBtnImg"] style:UIBarButtonItemStylePlain target:self action:@selector(webViewBack)];
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,left];

    
//    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
//                                                                                          backgroundImage:nil
//                                                                                               foreground:@"backBtnImg"
//                                                                                                      sel:@selector(back)]];
//    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
//                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
//                                           target:nil action:nil];
//    if (MODEL_VERSION >=7.0) {
//        
//        leftNegativeSpacer.width = -15;
//    }
//    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

- (void)webViewBack {
    if (_webView.canGoBack) {
        [_webView goBack];
        
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
#pragma  mark- UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:@"正在加载..."];

}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];

}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [self hiddenLoadingView];

    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    
}



-(void)dealloc
{
    _webView = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//
//- (IBAction)buttonClick:(id)sender {
//    //添加 字典，将label的值通过key值设置传递
//    NSDictionary *dict =[[NSDictionary alloc] initWithObjectsAndKeys:self.textFieldOne.text,@"textOne",self.textFieldTwo.text,@"textTwo", nil];
//    //创建通知
//    NSNotification *notification =[NSNotification notificationWithName:@"tongzhi" object:nil userInfo:dict];
//    //通过通知中心发送通知
//    [[NSNotificationCenter defaultCenter] postNotification:notification];
//    [self.navigationController popViewControllerAnimated:YES];
//    
//}
////在发送通知后，在所要接收的控制器中注册通知监听者，将通知发送的信息接收
//- (void)viewDidLoad {
//    [super viewDidLoad];
//    //注册通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tongzhi:) name:@"tongzhi" object:nil];
//    
//}
//- (void)tongzhi:(NSNotification *)text{
//    NSLog(@"%@",text.userInfo[@"textOne"]);
//    NSLog(@"－－－－－接收到通知------");
//    
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
