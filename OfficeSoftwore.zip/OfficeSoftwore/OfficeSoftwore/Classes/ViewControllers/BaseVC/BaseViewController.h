//
//  BaseViewController.h
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface BaseViewController : UIViewController
{
    MBProgressHUD *mbHUD;
    MBProgressHUD *onlyTextHUD;

}

typedef NS_ENUM(NSInteger) {
    
    EmployeeExpenseFees = 0,    //员工报销
    EmployeeLeave,              //员工请假
    PurchaseApplication,        //采购申请
    PurchaseReview,             //采购订单合同评审
    PurchaseDrawings,           //采购支款
    BusinessTrip,               //公务出差结算申请
    BusinessTripExceed,         //差旅超标准
    PersonnelFinancialTaxesFees,//人事财政税费支款
    BusinessReception,          //业务招待
    StampLicense,               //公司印章执照使用
}Type;


@property (nonatomic,assign) Type type;


- (void)setNavTitle:(NSString *)title leftButtonItem:(UIButton *)leftBtn rightButtonItem:(UIButton *)rightBtn;
- (UIButton *)customBarItemButton:(NSString *)title backgroundImage:(NSString *)bgImg foreground:(NSString *)fgImg sel:(SEL)sel;
-(NSArray *)setRightItemsWithFirstImage:(NSString *)firstImage andSecondImage:(NSString *)secondImage andFirstAction:(SEL)firstAction andSecondAction:(SEL)secondAction;
-(void)back;

//MBProgressHUD
-(void)showLoadingView:(NSString *)message;
-(void)hiddenLoadingView;

-(void)showOnlyTextAlertView:(NSString *)message;
-(void)hiddenOnlyTextAlertView;

//RefreshEnd
-(void)endRefreshWithTableView:(UITableView *)tableView;

//json转字典
-(NSDictionary *)getDicWithJsonString:(NSString *)jsonString;

//- (void)handleError:(Error *)error ;

//commonMenuClickMethod
-(UIViewController *)commonMenuButtonClicked:(NSInteger)selectItemTag andMenuList:(NSArray *)listArray;

//打电话
- (BOOL)callPhone:(NSString *)num;

//发短信
-(void)createMessageViewControllerWithPhoneNum:(NSString *)phoneNum;
//验证token


@end
