//
//  CommonWebVC.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/16.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "CommonWebVC.h"

@interface CommonWebVC ()<UIWebViewDelegate>

@end

@implementation CommonWebVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initView];
    self.navigationController.navigationBar.translucent = NO;
//    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView.scalesPageToFit =YES;
    _webView.delegate =self;
    _webView.scrollView.bounces = NO;
    [self webViewRequestData:self.webView];
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

- (void)webViewRequestData:(UIWebView *)webView{
    if (self.url) {
        [CommonMethod webViewRequest:webView
                                 url:self.url];
    }
    
}

#pragma  mark- UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:nil];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
    //    [self showOnlyTextAlertView:@"加载失败,请检查为网络"];
    
}

-(void)dealloc
{
    _webView = nil;
    _webView.delegate = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
