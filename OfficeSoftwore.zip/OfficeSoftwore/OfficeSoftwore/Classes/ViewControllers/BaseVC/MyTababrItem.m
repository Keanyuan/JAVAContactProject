//
//  MyTababrItem.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/16.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "MyTababrItem.h"

@implementation MyTababrItem
- (void)awakeFromNib {
    [super awakeFromNib];
    [self setTitleTextAttributes:[NSDictionary
                                  dictionaryWithObjectsAndKeys: [UIColor colorWithHexString:@"#4ab6d3"],
                                  NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    [self setTitleTextAttributes:[NSDictionary
                                  dictionaryWithObjectsAndKeys: [UIColor colorWithHexString:@"#a8b1c4"],
                                  NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
}

@end
