//
//  TabBarViewController.m
//  OfficeSoftwore
//
//  Copyright (c) 2015年 wangwang. All rights reserved.
//

#import "TabBarViewController.h"
#import "WaitCountModel.h"
#import "EMCallSession.h"
#import "ConversationListController.h"
#import "ApplyViewController.h"
#import "ContactListViewController.h"
#import "ChatViewController.h"
#import "ChatDemoHelper.h"
#import "NickListModel.h"

static const CGFloat kDefaultPlaySoundInterval = 3.0;
static NSString *kMessageType = @"MessageType";
static NSString *kConversationChatter = @"ConversationChatter";
static NSString *kGroupName = @"GroupName";


@interface TabBarViewController ()<EMChatManagerDelegate,EMGroupManagerDelegate>
{
    ConversationListController *_chatListVC;
    ContactListViewController *_contactsVC;
//    ChatViewController *ChatViewContrVC;
    NSString *number;
}

@property (strong, nonatomic) NSDate *lastPlaySoundDate;
@property (nonatomic, weak) ChatViewController *chatVC;
@property (nonatomic, weak) ConversationListController *conversationListVC;

@end

@implementation TabBarViewController

- (void)viewWillAppear:(BOOL)animated {
    [self requestWaitCount];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerNotifications];//实现环信代理
    
    //设置navigationBar背景图
    //    UIImage *bgimage = [UIColor imageWithColor:[UIColor colorWithHexString:@"#f0f9fc"]];
    //    [self.navigationController.navigationBar setBackgroundImage:bgimage forBarMetrics:UIBarMetricsDefault];
    
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [[UINavigationBar appearance]setTintColor:[UIColor colorWithHexString:@"#4ab6d3"]];
    [[UINavigationBar appearance]setBarTintColor:Maincolor];
    //    [[UINavigationBar appearance]setBackgroundColor:[UIColor colorWithHexString:@"#4ab6d3"]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(WaitTabbarItemBecame:)
                                                 name:NSRecordCountDidBecomeMainNotification
                                               object:nil];
    
    //if 使tabBarController中管理的viewControllers都符合 UIRectEdgeNone
    if ([UIDevice currentDevice].systemVersion.floatValue >= 7) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    //获取未读消息数，此时并没有把self注册为SDK的delegate，读取出的未读数是上次退出程序时的
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setupUntreatedApplyCount) name:@"setupUntreatedApplyCount" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setupUnreadMessageCount) name:@"setupUnreadMessageCount" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(removeBadgeValue:) name:@"badge_notification" object:nil];
    
    
    //tabarItem  图片选择
    [self setItemsImages:@[@"home",@"todo",@"communication",@"contacts",@"setting"] selectedImages:@[@"home_on",@"todo_on",@"communication_on",@"contacts_on",@"setting_on"]];
    self.tabBar.opaque = NO;
    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 83)];
    backView.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
    [self.tabBar insertSubview:backView atIndex:0];
    self.tabBar.opaque = YES;
    
    CGRect rect = CGRectMake(0, 0, APP_SCREEN_WIDTH, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context,Gcolor(@"#d3edf4").CGColor);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [[UITabBar appearance] setShadowImage:img];
    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc]init]];
    
    [self setupUnreadMessageCount];//xg
    [ChatDemoHelper shareHelper].contactViewVC = _contactsVC;
    [ChatDemoHelper shareHelper].conversationListVC = _chatListVC;
    
}
//请求待办数量
- (void)requestWaitCount
{
    __weak typeof(self) weakSelf = self;
    [[AFHttpModelTool shareAFHttpModelTool] getWaitCountWithUserToken:[CommonMethod getToken]
                                                                 type:ALL
                                                               tittle:@""
                                                           Completion:^(WaitCountModel *waitCountModel) {
                                                               
                                                               __strong typeof(weakSelf) waitSelf = weakSelf;
                                                               
                                                               ////////xg
                                                               if ([waitCountModel.result isEqualToString:@"0"]) {
                                                                   [CommonMethod setBadge:waitCountModel.result];
                                                               }
                                                               
                                                               if ([waitCountModel.status isEqualToString:@"success"]) {
                                                                   if (![waitCountModel.result isEqualToString:@"0"]) {
                                                                       NSLog(@"%@",waitCountModel.result);
                                                                       waitSelf.tabBar.items[1].badgeValue = waitCountModel.result;
                                                                       number = waitCountModel.result;
                                                                       [self tongzhi];
                                                                       
                                                                   }else{
                                                                       waitSelf.tabBar.items[1].badgeValue = nil;
                                                                       number = @"0";
                                                                       [self tongzhi];
                                                                   }
                                                               }
                                                           } failure:^(NSError *error) {
                                                               weakSelf.tabBar.items[1].badgeValue = nil;
                                                           }];
}

//图片选择方法
- (void)setItemsImages:(NSArray *)imageArray selectedImages:(NSArray *)selectedImageArray {
    for (int i = 0; i < self.tabBar.items.count; i ++) {
        UITabBarItem * barItem = self.tabBar.items[i];
        if (imageArray.count > i && selectedImageArray.count > i) {
            //这里是重点了，使用原始图片UIImageRenderingModeAlwaysOriginal，这样才能保证正常显示图片
            barItem.image = [[UIImage imageNamed:imageArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            barItem.selectedImage = [[UIImage imageNamed:selectedImageArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
    }
}
//代办数量传值icon
- (void)tongzhi{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"waitNumber"
                                                        object:self
                                                      userInfo:@{@"bdnumber":number}];
    
}

- (void)WaitTabbarItemBecame:(NSNotification *)notification
{
    [self requestWaitCount];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (BOOL)_needShowNotification:(NSString *)fromChatter
{
    BOOL ret = YES;
    NSArray *igGroupIds = [[EMClient sharedClient].groupManager getAllIgnoredGroupIds];
    for (NSString *str in igGroupIds) {
        if ([str isEqualToString:fromChatter]) {
            ret = NO;
            break;
        }
    }
    return ret;
}

- (ChatViewController*)_getCurrentChatView
{
    NSMutableArray *viewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    ChatViewController *chatViewContrller = nil;
    for (id viewController in viewControllers)
    {
        if ([viewController isKindOfClass:[ChatViewController class]])
        {
            chatViewContrller = viewController;
            break;
        }
    }
    return chatViewContrller;
}
- (void)_handleReceivedAtMessage:(EMMessage*)aMessage
{
    if (aMessage.chatType != EMChatTypeGroupChat || aMessage.direction != EMMessageDirectionReceive) {
        return;
    }
    
    NSString *loginUser = [EMClient sharedClient].currentUsername;
    NSDictionary *ext = aMessage.ext;
    EMConversation *conversation = [[EMClient sharedClient].chatManager getConversation:aMessage.conversationId type:EMConversationTypeGroupChat createIfNotExist:NO];
    if (loginUser && conversation && ext && [ext objectForKey:kGroupMessageAtList]) {
        id target = [ext objectForKey:kGroupMessageAtList];
        if ([target isKindOfClass:[NSString class]] && [(NSString*)target compare:kGroupMessageAtAll options:NSCaseInsensitiveSearch] == NSOrderedSame) {
            NSNumber *atAll = conversation.ext[kHaveUnreadAtMessage];
            if ([atAll intValue] != kAtAllMessage) {
                NSMutableDictionary *conversationExt = conversation.ext ? [conversation.ext mutableCopy] : [NSMutableDictionary dictionary];
                [conversationExt removeObjectForKey:kHaveUnreadAtMessage];
                [conversationExt setObject:@kAtAllMessage forKey:kHaveUnreadAtMessage];
                conversation.ext = conversationExt;
            }
        }
        else if ([target isKindOfClass:[NSArray class]]) {
            if ([target containsObject:loginUser]) {
                if (conversation.ext[kHaveUnreadAtMessage] == nil) {
                    NSMutableDictionary *conversationExt = conversation.ext ? [conversation.ext mutableCopy] : [NSMutableDictionary dictionary];
                    [conversationExt setObject:@kAtYouMessage forKey:kHaveUnreadAtMessage];
                    conversation.ext = conversationExt;
                }
            }
        }
    }
}

- (void)didReceiveMessages:(NSArray *)aMessages
{
    [self setupUnreadMessageCount];
    BOOL isRefreshCons = YES;
    for(EMMessage *message in aMessages){
        BOOL needShowNotification = (message.chatType != EMChatTypeChat) ? [self _needShowNotification:message.conversationId] : YES;
#ifdef REDPACKET_AVALABLE
        
        /**
         *  屏蔽红包被抢消息的提示
         */
        NSDictionary *dict = message.ext;
        needShowNotification = (dict && [dict valueForKey:RedpacketKeyRedpacketTakenMessageSign]) ? NO : needShowNotification;
#endif
        
        if (needShowNotification) {
#if !TARGET_IPHONE_SIMULATOR
            
            UIApplicationState state = [[UIApplication sharedApplication] applicationState];
            switch (state) {
                case UIApplicationStateActive:
                    [self playSoundAndVibration];
                    break;
                case UIApplicationStateInactive:
                    [self playSoundAndVibration];
                    break;
                case UIApplicationStateBackground:
                    [self showNotificationWithMessage:message];
                    break;
                default:
                    break;
            }
#endif
            
        }
        
        if (_chatVC == nil) {
            _chatVC = [self _getCurrentChatView];
        }
        BOOL isChatting = NO;
        if (_chatVC) {
            isChatting = [message.conversationId isEqualToString:_chatVC.conversation.conversationId];
        }
        if (_chatVC == nil || !isChatting) {
            [self _handleReceivedAtMessage:message];
            
            if (self.conversationListVC) {
                [_conversationListVC refresh];
            }
            
                [self setupUnreadMessageCount];
            return;
        }
        
        if (isChatting) {
            isRefreshCons = NO;
        }
    }
    
    if (isRefreshCons) {
        if (self.conversationListVC) {
            [_conversationListVC refresh];
        }
        
        [self setupUnreadMessageCount];
    }
}


-(void)registerNotifications{
    [[EMClient sharedClient].chatManager addDelegate:self delegateQueue:nil];
    [[EMClient sharedClient].groupManager addDelegate:self delegateQueue:nil];
}

//统计未读消息数(即时聊天信息未读数量)
-(void)setupUnreadMessageCount
{
    NSArray *conversations = [[EMClient sharedClient].chatManager getAllConversations];
    NSInteger unreadCount = 0;
    for (EMConversation *conversation in conversations) {
        unreadCount += conversation.unreadMessagesCount;
    }
        if (unreadCount > 0) {
            self.tabBar.items[2].badgeValue = [NSString stringWithFormat:@"%i",(int)unreadCount];
        }else{
            self.tabBar.items[2].badgeValue = nil;
        }
    
    UIApplication *application = [UIApplication sharedApplication];
    [application setApplicationIconBadgeNumber:unreadCount];
}

- (void)setupUntreatedApplyCount
{
//    NSInteger unreadCount = [[[ApplyViewController shareController] dataSource] count];
//    if (_contactsVC) {
//        
//        if (unreadCount > 0) {
//            self.tabBar.items[2].badgeValue = [NSString stringWithFormat:@"%i",(int)unreadCount];
//        }else{
//            self.tabBar.items[2].badgeValue = nil;
//        }
//    }
}

- (void)jumpToChatList
{
    if ([self.navigationController.topViewController isKindOfClass:[ChatViewController class]]) {
//        ChatViewController *chatController = (ChatViewController *)self.navigationController.topViewController;
    }
    else if(_chatListVC)
    {
        [self.navigationController popToViewController:self animated:NO];
        [self setSelectedViewController:_chatListVC];
    }
}

//声音震动提醒
- (void)playSoundAndVibration{
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSinceDate:self.lastPlaySoundDate];
    if (timeInterval < kDefaultPlaySoundInterval) {
        //如果距离上次响铃和震动时间太短, 则跳过响铃
        NSLog(@"skip ringing & vibration %@, %@", [NSDate date], self.lastPlaySoundDate);
        return;
    }
        //保存最后一次响铃时间
        self.lastPlaySoundDate = [NSDate date];
        
        // 收到消息时，播放音频
        [[EMCDDeviceManager sharedInstance] playNewMessageSound];
        // 收到消息时，震动
        [[EMCDDeviceManager sharedInstance] playVibration];
        
}
- (void)networkChanged:(EMConnectionState)connectionState
{
    _connectionState = connectionState;
    [_chatListVC networkChanged:connectionState];
}


- (EMConversationType)conversationTypeFromMessageType:(EMChatType)type
{
    EMConversationType conversatinType = EMConversationTypeChat;
    switch (type) {
        case EMChatTypeChat:
            conversatinType = EMConversationTypeChat;
            break;
        case EMChatTypeGroupChat:
            conversatinType = EMConversationTypeGroupChat;
            break;
        case EMChatTypeChatRoom:
            conversatinType = EMConversationTypeChatRoom;
            break;
        default:
            break;
    }
    return conversatinType;
}
//didReceiveMessages里调用本地推送
- (void)showNotificationWithMessage:(EMMessage *)message
{
    //昵称拼音汉字转换
    NSArray *tempArray = [CommonMethod userInfo];
    NickListModel *_userInfo;
    NSString *title = message.from;
    NSString *_str;
    for (int i = 0; i<tempArray.count; i++) {
        _userInfo = tempArray[i];
        if ([title isEqualToString:_userInfo.username]) {
            _str = _userInfo.nick;
            title = _userInfo.nick;
            break;
        }
    }
    
    EMPushOptions *options = [[EMClient sharedClient] pushOptions];
    NSLog(@"options----%@",options);
    //发送本地推送
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    notification.fireDate = [NSDate date]; //触发通知的时间
    EMMessageBody *messageBody = message.body;
    NSString *messageStr = nil;
    switch (messageBody.type) {
        case EMMessageBodyTypeText:
        {
            //设置推送消息实体显示表情而不是符号
            NSString *didReceiveText = [EaseConvertToCommonEmoticonsHelper
                                        convertToSystemEmoticons:((EMTextMessageBody *)messageBody).text];
            messageStr = didReceiveText;

//            messageStr = ((EMTextMessageBody *)messageBody).text;
        }
            break;
        case EMMessageBodyTypeImage:
        {
            messageStr = NSLocalizedString(@"message.image", @"Image");
        }
            break;
        case EMMessageBodyTypeLocation:
        {
            messageStr = NSLocalizedString(@"message.location", @"Location");
        }
            break;
        case EMMessageBodyTypeVoice:
        {
            messageStr = NSLocalizedString(@"message.voice", @"Voice");
        }
            break;
        case EMMessageBodyTypeVideo:{
            messageStr = NSLocalizedString(@"message.video", @"Video");
        }
            break;
        default:
            break;
    }
    
    notification.alertBody = [NSString stringWithFormat:@"%@:%@", title, messageStr];
    
#warning 去掉注释会显示[本地]开头, 方便在开发中区分是否为本地推送
    //notification.alertBody = [[NSString alloc] initWithFormat:@"[本地]%@", notification.alertBody];
    
    notification.alertAction = NSLocalizedString(@"open", @"Open");
    notification.timeZone = [NSTimeZone defaultTimeZone];
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSinceDate:self.lastPlaySoundDate];
    if (timeInterval < kDefaultPlaySoundInterval) {
        NSLog(@"skip ringing & vibration %@, %@", [NSDate date], self.lastPlaySoundDate);
    } else {
        notification.soundName = UILocalNotificationDefaultSoundName;
        self.lastPlaySoundDate = [NSDate date];
    }
    
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    [userInfo setObject:[NSNumber numberWithInt:message.chatType] forKey:kMessageType];
    [userInfo setObject:message.conversationId forKey:kConversationChatter];
    notification.userInfo = userInfo;
    
    //发送通知
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

- (void)didReceiveLocalNotification:(UILocalNotification *)notification
{
    NSDictionary *userInfo = notification.userInfo;
    if (userInfo)
    {
        if ([self.navigationController.topViewController isKindOfClass:[ChatViewController class]]) {
        }
        
        NSArray *viewControllers = self.navigationController.viewControllers;
        [viewControllers enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL *stop){
            if (obj != self)
            {
                if (![obj isKindOfClass:[ChatViewController class]])
                {
                    [self.navigationController popViewControllerAnimated:NO];
                }
                else
                {
                    NSString *conversationChatter = userInfo[kConversationChatter];
                    ChatViewController *chatViewController = (ChatViewController *)obj;
                    if (![chatViewController.conversation.conversationId isEqualToString:conversationChatter])
                    {
                        [self.navigationController popViewControllerAnimated:NO];
                        EMChatType messageType = [userInfo[kMessageType] intValue];
#ifdef REDPACKET_AVALABLE
                        chatViewController = [[RedPacketChatViewController alloc]
#else
                        chatViewController = [[ChatViewController alloc]
#endif
                                        initWithConversationChatter:conversationChatter conversationType:[self conversationTypeFromMessageType:messageType]];
                        switch (messageType) {
                            case EMChatTypeChat:
                            {
                                NSArray *groupArray = [[EMClient sharedClient].groupManager getAllGroups];
                                for (EMGroup *group in groupArray) {
                                    if ([group.groupId isEqualToString:conversationChatter]) {
                                        chatViewController.title = group.subject;
                                        break;
                                    }
                                }
                            }
                                break;
                            default:
                                chatViewController.title = conversationChatter;
                                break;
                    }
                     [self.navigationController pushViewController:chatViewController animated:NO];
                }
                *stop= YES;
            }
        }
        else
        {
            ChatViewController *chatViewController = nil;
            NSString *conversationChatter = userInfo[kConversationChatter];
            EMChatType messageType = [userInfo[kMessageType] intValue];
#ifdef REDPACKET_AVALABLE
            chatViewController = [[RedPacketChatViewController alloc]
#else
            chatViewController = [[ChatViewController alloc]
#endif
                              initWithConversationChatter:conversationChatter conversationType:[self conversationTypeFromMessageType:messageType]];
                switch (messageType) {
                    case EMChatTypeGroupChat:
                    {
                        NSArray *groupArray = [[EMClient sharedClient].groupManager getAllGroups];
                        for (EMGroup *group in groupArray) {
                            if ([group.groupId isEqualToString:conversationChatter]) {
                                chatViewController.title = group.subject;
                                break;
                            }
                        }
                    }
                        break;
                    default:
                        chatViewController.title = conversationChatter;
                        break;
                }
                [self.navigationController pushViewController:chatViewController animated:NO];
            }
        }];
    }
    else if (_chatListVC)
    {
        [self.navigationController popToViewController:self animated:NO];
        [self setSelectedViewController:_chatListVC];
    }
}

- (void)removeBadgeValue:(NSNotification *)notification
{
    self.tabBar.items[2].badgeValue = nil;
}

- (void)dealloc
{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"badge_notification" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
