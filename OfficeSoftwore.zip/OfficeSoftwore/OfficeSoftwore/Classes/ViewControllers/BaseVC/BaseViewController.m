//
//  BaseViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/9/24.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"



@interface BaseViewController ()<MFMessageComposeViewControllerDelegate>
{
    MFMessageComposeViewController *MessagePicker;
}
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self unifyLayout];
    [self initHUDView];
    [self initOnlyTextHUDView];

    self.view.backgroundColor = [UIColor whiteColor];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(statusNotReachable:)
                                                 name:NetworkReachabilityStatusNotReachable
                                               object:nil];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;


}

- (void)statusNotReachable:(NSNotification *)notification
{
    [self hiddenLoadingView];
 }

#pragma mark - GestureRecognizerDelegate
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    //当前controller是否是根controller
    if (gestureRecognizer == self.navigationController.interactivePopGestureRecognizer) {
        return !(self == self.navigationController.topViewController);
    }
    return YES;
}

#pragma mark - Unified view style method
- (void)unifyLayout {
    
    // 统一iOS 7 和 iOS 6 的布局，是的布局代码统一
    if (MODEL_VERSION >= 7.0) {
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
}

#pragma mark -

#pragma mark - MBProgressHUD
-(void)initHUDView
{
    [mbHUD removeFromSuperview];
    mbHUD = nil;
    
    mbHUD = [[MBProgressHUD alloc] initWithView:self.view];
    mbHUD.mode = MBProgressHUDModeCustomView;
    
    UIImageView *hudBgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(-5, -6, 45, 45)];
    [hudBgImageView setImage:[UIImage imageNamed:@"spinner_outer"]];
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    animation.duration = MAXFLOAT * 0.4;
    animation.additive = YES;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.fromValue = [NSNumber numberWithFloat:0];
    animation.toValue = [NSNumber numberWithFloat:MAXFLOAT];
    animation.repeatCount = MAXFLOAT;
    [hudBgImageView.layer addAnimation:animation forKey:nil];
    
    UIImageView *iconView = [[UIImageView alloc] initWithFrame:CGRectMake(5, -3, 35, 35)];
    [iconView setImage:[UIImage imageNamed:@"zy_icon"]];
    
    [iconView addSubview:hudBgImageView];
    
    mbHUD.customView = iconView;
    [self.view addSubview:mbHUD];
    
}


-(void)showLoadingView:(NSString *)message
{
    [self initHUDView];
    
    mbHUD.labelText = message ? message : @"加载中...";
    mbHUD.mode = MBProgressHUDModeIndeterminate;

    [mbHUD show:YES];
}

-(void)hiddenLoadingView
{
    if (mbHUD) {
        [mbHUD hide:YES];
    }
}

#pragma mark - MBProgressHUD
-(void)initOnlyTextHUDView
{
    onlyTextHUD = [[MBProgressHUD alloc]initWithView:self.view];
    onlyTextHUD.mode = MBProgressHUDModeText;
    [self.view addSubview:onlyTextHUD];
}

-(void)showOnlyTextAlertView:(NSString *)message
{
    [self initHUDView];
    if (onlyTextHUD) {
        
        onlyTextHUD.labelText = message ? message : @"操作成功";
        [onlyTextHUD show:YES];
        
        [self performSelector:@selector(hiddenOnlyTextAlertView)
                   withObject:nil
                   afterDelay:1.5];
    }
}

-(void)hiddenOnlyTextAlertView
{
    if (onlyTextHUD) {
        [onlyTextHUD hide:YES];
    }
}

#pragma mark - ShowAlert
-(void)showAlertWithTitle:(NSString *)alertTitle andMessage:(NSString *)message
{
    
    UIAlertView *titleAlert = [[UIAlertView alloc]initWithTitle:alertTitle
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"确认", nil];
    [titleAlert show];
    
}

#pragma mark - EndRefresh
-(void)endRefreshWithTableView:(UITableView *)tableView
{
    if (tableView.mj_footer) {
        
        [tableView.mj_footer endRefreshing];
    }
    if (tableView.mj_header) {
        
        [tableView.mj_header endRefreshing];
    }
}

#pragma mark - CustomNavigationBar

- (void)setNavTitle:(NSString *)title leftButtonItem:(UIButton *)leftBtn rightButtonItem:(UIButton *)rightBtn {
    
    CGFloat _x = 0.0f; // 需要计算的nav title view 的x
    CGFloat _w = 0.0f; // 需要计算的nav title view 的y
    CGFloat l_w = 0.0f; // 获取的左button宽
    CGFloat r_w = 0.0f; // 获取的右button宽
    CGFloat btn_w_max = 0.0f; //获取button的最大宽
    
    if (leftBtn && rightBtn) {
        l_w = leftBtn.frame.size.width;
        r_w = rightBtn.frame.size.width;
    } else if (leftBtn && !rightBtn) {
        r_w = 0.0f;
        l_w = leftBtn.frame.size.width;
    } else if (!leftBtn && rightBtn) {
        r_w = rightBtn.frame.size.width;
        l_w = 0.0f;
    } else {
        r_w = 0.0f;
        l_w = 0.0f;
    }
    
    btn_w_max = l_w >= r_w ? l_w : r_w;
    
    _x = btn_w_max;
    
    if (MODEL_VERSION >= 7.0f) {
        _w = 320 - btn_w_max * 2;
        [self.navigationItem setTitleView:[self setNavTitle:title initWithFrame:CGRectMake(_x, 0, _w, 44)]];
    } else {
        _w = 320 - btn_w_max * 2;
        [self.navigationItem setTitleView:[self setNavTitle:title initWithFrame:CGRectMake(_x, 0, _w, 44)]];
    }
    UIBarButtonItem *rightNegativeSpacer = [[UIBarButtonItem alloc]
                                            initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                            target:nil action:nil];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    
    if (MODEL_VERSION >=7.0) {
        
        rightNegativeSpacer.width = -15;
        leftNegativeSpacer.width = -15;
    }
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    
    self.navigationItem.rightBarButtonItems = nil;
    self.navigationItem.leftBarButtonItems = nil;
    self.navigationItem.rightBarButtonItem = nil;
    self.navigationItem.leftBarButtonItem = nil;
    
    
    if (!leftBtn && rightBtn) {
        
        self.navigationItem.rightBarButtonItems = @[rightNegativeSpacer,rightItem];
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:@"" backgroundImage:nil foreground:nil sel:nil]];
    }
    
    if (leftBtn && !rightBtn) {
        self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftItem];
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:@"" backgroundImage:nil foreground:nil sel:nil]];
    }
    
    if (leftBtn && rightBtn) {
        self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftItem];
        self.navigationItem.rightBarButtonItems = @[rightNegativeSpacer,rightItem];
    }
}

- (UIView *)setNavTitle:(NSString *)title initWithFrame:(CGRect)rect {
    UIView *view = [[UIView alloc] initWithFrame:rect];
    [view setBackgroundColor:[UIColor clearColor]];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight ];
    
    UILabel *nameLabel = [[UILabel alloc] init];
    [nameLabel setFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
    [nameLabel setBackgroundColor:[UIColor clearColor]];
    [nameLabel setAutoresizingMask:UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin];
    [nameLabel setTextColor:[UIColor whiteColor]];
    [nameLabel setFont:[UIFont fontWithName:@"Helvetica" size:18.0f]];
    nameLabel.adjustsFontSizeToFitWidth = NO;
    [nameLabel setText:title];
    [nameLabel setTextAlignment:NSTextAlignmentCenter];
    [nameLabel setNumberOfLines:1];
    
    [view addSubview:nameLabel];
    
    return view;
}

- (UIButton *)customBarItemButton:(NSString *)title backgroundImage:(NSString *)bgImg foreground:(NSString *)fgImg sel:(SEL)sel {
    
    UIButton *customBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIFont *font = [UIFont systemFontOfSize:15.0];
    [customBtn setFrame:CGRectMake(0, 0, 44, 44)];
    [customBtn setBackgroundColor:[UIColor clearColor]];
    customBtn.titleLabel.textAlignment = NSTextAlignmentRight;
    if (bgImg) {
        UIImage *image = [UIImage imageNamed:bgImg];
        [customBtn setBackgroundImage:image forState:UIControlStateNormal];
    }
    
    if (fgImg && MODEL_VERSION >=7.0) {
        [customBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 10)];
        [customBtn setImage:[UIImage imageNamed:fgImg] forState:UIControlStateNormal];
    }
    
    if (title) {
        
        [customBtn setTitle:title forState:UIControlStateNormal];
    }
    
    [customBtn.titleLabel setFont:font];
    [customBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [customBtn setTintColor:Maincolor];

    
    if (sel) {
        [customBtn addTarget:self action:sel forControlEvents:UIControlEventTouchUpInside];
    }
    
    return customBtn;
}

//自定义右边两个item

-(NSArray *)setRightItemsWithFirstImage:(NSString *)firstImage andSecondImage:(NSString *)secondImage andFirstAction:(SEL)firstAction andSecondAction:(SEL)secondAction
{
    UIButton *firstRightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *secondRightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [firstRightBtn setFrame:CGRectMake(0, 0, 30, 30)];
    [firstRightBtn setBackgroundColor:[UIColor clearColor ]];
    
    [secondRightBtn setFrame:CGRectMake(0, 0, 30, 30)];
    [secondRightBtn setBackgroundColor:[UIColor clearColor]];
    
    [firstRightBtn setImage:[UIImage imageNamed:firstImage]
                   forState:UIControlStateNormal];
    [secondRightBtn setImage:[UIImage imageNamed:secondImage]
                    forState:UIControlStateNormal];
    
    [firstRightBtn addTarget:self
                      action:firstAction
            forControlEvents:UIControlEventTouchUpInside];
    [secondRightBtn addTarget:self
                       action:secondAction
             forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *firstRightItem = [[UIBarButtonItem alloc] initWithCustomView:firstRightBtn];
    UIBarButtonItem *secondRightItem = [[UIBarButtonItem alloc]initWithCustomView:secondRightBtn];
    
    UIBarButtonItem *rightNegativeSpacer = [[UIBarButtonItem alloc]
                                            initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                            target:nil action:nil];
    rightNegativeSpacer.width = -10;
    
    return @[rightNegativeSpacer,firstRightItem,secondRightItem];
    
}

#pragma mark -

//#pragma mark - TableViewDelegate
//-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    if (MODEL_VERSION >= 7.0) {
//        
//        // Remove seperator inset
//        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
//            [cell setSeparatorInset:UIEdgeInsetsMake(0, 0, 0, 0)];
//        }
//        
//        if (MODEL_VERSION >= 8.0) {
//            
//            // Prevent the cell from inheriting the Table View's margin settings
//            if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
//                [cell setPreservesSuperviewLayoutMargins:NO];
//            }
//            
//            // Explictly set your cell's layout margins
//            if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
//                [cell setLayoutMargins:UIEdgeInsetsZero];
//            }
//        }
//    }
//    
//}

#pragma mark - ActionMethod
-(NSDictionary *)getDicWithJsonString:(NSString *)jsonString
{
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *jsonDic;
    
    if (jsonData) {
        jsonDic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                  options:NSJSONReadingMutableContainers
                                                    error:nil];
    }
    
    return jsonDic;
}

- (void)pushMethod
{
    UIViewController *viewController = [[UIViewController alloc]initWithNibName:@"nibName"
                                                                         bundle:nil];
    viewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:viewController
                                         animated:YES];
    if ([viewController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        
        if (MODEL_VERSION >= 7.0) {
            
            self.navigationController.interactivePopGestureRecognizer.delegate = nil;
        }
    }
    
}

- (void)back{
    
    NSArray *vcArray = [self.navigationController viewControllers];
    
    if (vcArray.count > 1) {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (BOOL)callPhone:(NSString *)num {
    
    if (![CommonMethod isPhoneSupported]) {
        showMsg(@"当前设备不支持拨打电话");
        return NO;
    }
    
    NSURL *telURL =[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", num]];
    [[UIApplication sharedApplication] openURL:telURL];
    
    return YES;
}


-(void)createMessageViewControllerWithPhoneNum:(NSString *)phoneNum
{
    MessagePicker = [[MFMessageComposeViewController alloc] init];
    MessagePicker.messageComposeDelegate = self;
    MessagePicker.navigationBar.tintColor = [UIColor blackColor];
    // 默认收件人(可多个)
    MessagePicker.recipients = [NSArray arrayWithObject:phoneNum];
    
    //因为添加了FDFullscreenPopGesture所以需要自定义picker的取消及NavigationItem
    UINavigationItem *navigationItem = [[[MessagePicker viewControllers] lastObject] navigationItem];
    [navigationItem setTitle:@"新iMessage"];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setFrame:CGRectMake(0, 0, 40, 20)];
    [button setTitle:@"取消" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor colorWithHexString:@"#4ab6d3"] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:17.0];
    [button addTarget:self action:@selector(messageBtnCancel) forControlEvents:UIControlEventTouchUpInside];
    navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    if (MessagePicker) {
        
        [self presentViewController:MessagePicker
                           animated:YES
                         completion:^{
                             
                         }];
    }else{
        
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[NSString stringWithFormat:@"sms://%@",phoneNum]]];
    }

}
//取消事件
- (void)messageBtnCancel
{
    [MessagePicker dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma mark - MFMessageComposeViewControllerDelegate

-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    switch (result) {
        case MessageComposeResultCancelled:
            
            break;
        case MessageComposeResultSent:
            ShowMassage(@"发送成功");
            break;
        case MessageComposeResultFailed:
            
            break;
        default:
            break;
    }
    
    [controller dismissViewControllerAnimated:YES completion:^{
        
    }];
}



- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:NetworkReachabilityStatusNotReachable
                                                  object:nil];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
