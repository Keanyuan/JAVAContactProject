//
//  LoginViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/26.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginModel.h"
#import "AppDelegate.h"
#import "RegisterViewController.h"
#import "BaseService.h"
#import "RegisterModel.h"
@interface LoginViewController ()<UITextFieldDelegate>
{
    UITapGestureRecognizer  *_gesture;
}

@end

@implementation LoginViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self createRegisterBtn];
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self createRegisterBtn];
    NSString *uuid = [[UIDevice currentDevice].identifierForVendor UUIDString];
    NSLog(@"identifierForVendor---%@",uuid);
    
    NSString *str = [JPUSHService registrationID];
    NSLog(@"appservice--------%@",str);
    [CommonMethod colorWithUserName:self.userName
                           password:self.password];
    
    [self.pwView setCornerRadiuss:20.0];
    self.pwView.layer.borderWidth = 1.0f;
    self.pwView.layer.borderColor = [UIColor colorWithHexString:@"#D9D6D6"].CGColor;
    [self.userView setCornerRadiuss:20.0];
    self.userView.layer.borderWidth = 1.0f;
    self.userView.layer.borderColor = [UIColor colorWithHexString:@"#D9D6D6"].CGColor;
    
    [self.login setCornerRadiuss:20.0];
    [self.login setBackgroundColor:[UIColor colorWithHexString:@"#F5AB17"]];

    [self.titlelable setTextColor:[UIColor colorWithHexString:@"#777777"]];
    
//    self.BGImage.frame = CGRectMake(0, APP_SCREEN_HEIGHT-(APP_SCREEN_WIDTH*187)/320, APP_SCREEN_WIDTH, (APP_SCREEN_WIDTH*187)/320);
    self.BGImage.frame = CGRectMake(0, 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT);

    self.login.frame = CGRectMake(48, 395, APP_SCREEN_WIDTH - 96, 40);
    self.userView.frame = CGRectMake(48, 271, APP_SCREEN_WIDTH-48*2, 40);
    self.pwView.frame = CGRectMake(48, 325, APP_SCREEN_WIDTH-48*2, 40);
    self.titlelable.frame = CGRectMake(0, 214, APP_SCREEN_WIDTH, 15);
    self.logoImage.frame = CGRectMake(APP_SCREEN_WIDTH/2-60, 90, 120, 110);
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];

    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    //增加监听，当键退出时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (IBAction)loginAction:(id)sender {
    if ([self.userName.text compare:@""] == NSOrderedSame) {
        [self hiddenLoadingView];
        [CustomAlertMessage showAlertMessage:@"登录名不能为空"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*2];
        return;
    }
    
    if ([self.password.text compare:@""] == NSOrderedSame) {
        [self hiddenLoadingView];
        [CustomAlertMessage showAlertMessage:@"密码不能为空"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*2];
        return;
    }
    
    [self loginSuccessedUsername:self.userName.text
                        password:self.password.text];

}

-(void)loginSuccessedUsername:(NSString *)username password:(NSString *)password{
    
    if(username !=nil && [username compare:@""]!= NSOrderedSame && password != nil && [password compare:@""]!= NSOrderedSame){

        [self userLoginUsername:username
                       password:password];
        
    }
    
}

- (void)userLoginUsername:(NSString *)username password:(NSString *)password
{
    [self showLoadingView:@"正在登录..."];
    
    username = [username ms_trim];
    password = [password ms_trim];
    NSString *str = [JPUSHService registrationID];
    NSLog(@"appservice--------%@",str);

    [[AFHttpModelTool shareAFHttpModelTool] getLoginUserAccount:username
                                                       passward:password
                                                     deviceType:@"IOS"
                                                     Completion:^(LoginModel *login) {
                                                         
                                                         if ([login.status isEqualToString:@"error"]) {
                                                             [self hiddenLoadingView];

                                                             [CustomAlertMessage showAlertMessage:login.result andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*2];
                                                         }else{
                                                             if ([login.result isEqualToString:@"1"]) {
                                                                 //储存用户名和密码
                                                                 [CommonMethod setUsername:username password:password];
                                                                 [CommonMethod setToken:login.token];
                                                                 NSLog(@"--------/%@",login.token);
                                                                 [CommonMethod setLoginUsername:login.userName];
                                                                 NSString *tempuserid = [CommonMethod getuseridByKey:TOKEN];
                                                                 NSLog(@"tempuserid===%@",tempuserid);
                                                                 
                                                                 //按照别名推送
                                                                 [self pushAlias];
                                                                 
                                                                 [self hiddenLoadingView];

                                                                 [self presentMainViewController];

                                                             }else{
                                                                 [self hiddenLoadingView];

                                                                 [CustomAlertMessage showAlertMessage:@"登录名或密码错误" andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*2];
                                                             }
                                                        }
                                                     } failure:^(NSError *error) {
                                                         [self hiddenLoadingView];
                                                         [CustomAlertMessage showAlertMessage:@"登录失败" andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];

                                                     }];

}

- (void)pushAlias
{
    //按照alias发送推送
     NSString *alias = self.userName.text;
    [self analyseInput:&alias tags:NULL];
    
    [JPUSHService setTags:NULL
                 alias:alias
      callbackSelector:@selector(tagsAliasCallback:tags:alias:)
                target:self];

}

- (void)tagsAliasCallback:(int)iResCode
                     tags:(NSSet *)tags
                    alias:(NSString *)alias {
    NSLog(@"iResCode :%d, \nalias: %@\n", iResCode,alias);
}

- (void)analyseInput:(NSString **)alias tags:(NSSet **)tags {
    if (![*alias length]) {
        *alias = nil;
    }
}

//登录成功
- (void)presentMainViewController{
    
    UIStoryboard *stryBoard=[UIStoryboard storyboardWithName:@"Main"
                                                      bundle:nil];
    [self presentViewController:[stryBoard instantiateInitialViewController]
                       animated:YES
                     completion:^(void) {
                         //登陆成功修改跟控制器
                         [OA_AppDelegate reSetRootViewControll:[stryBoard instantiateInitialViewController]];
                         //iOS8 dismiss会闪退
                         if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=9.0))
                         {
//                             [self dismissViewControllerAnimated:YES completion:^{
//                             }];
                         }
                     }];
    
}



-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);
    self.view.frame = rect;
    [UIView commitAnimations];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    return YES;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    return YES;
    
}

- (void)keyboardWillShow:(NSNotification *)aNotification
{
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    int kbheight = keyboardRect.size.height;
    NSLog(@"键盘高度是  %d",kbheight);
    
    CGRect frame = _pwView.frame;
    CGFloat heights = self.view.frame.size.height;
    int offset = frame.origin.y + 40 - ( heights - kbheight);//键盘高度216
    
    NSTimeInterval animationDuration = 0.20f;
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    
    float width = self.view.frame.size.width;
    float height = self.view.frame.size.height;
    
    if(offset > 0)
    {
        CGRect rect = CGRectMake(0.0f, -offset,width,height);
        self.view.frame = rect;
    }
    NSLog(@"----/%d",offset);
    [UIView commitAnimations];
    
}

//当键退出时调用
- (void)keyboardWillHide:(NSNotification *)aNotification
{
    NSLog(@"键盘隐藏了");
}

//判断应用程序是否是第一次启动
//NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//if ([userDefault boolForKey:@"FirstLanching"] == NO) {
//    [userDefault setBool:YES forKey:@"FirstLanching"];
//    [userDefault synchronize];
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    [self presentViewController:[storyboard instantiateViewControllerWithIdentifier:@"UserGuideView"] animated:YES completion:^(void) {}];
//}else{
//    UIStoryboard *stryBoard=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    [self presentViewController:[stryBoard instantiateInitialViewController] animated:YES completion:^(void) {}];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)CreateRegistrationButton
{
    UIButton *rebutton = [[UIButton alloc] initWithFrame:CGRectMake(0, APP_SCREEN_HEIGHT-50, APP_SCREEN_WIDTH, 50)];
    rebutton.backgroundColor = [UIColor clearColor];
    [rebutton setTitle:@"新用户注册" forState:UIControlStateNormal];
    rebutton.titleLabel.font = [UIFont systemFontOfSize:15];
    [rebutton setTitleColor:[UIColor colorWithHexString:@"#4ab6d3"] forState:UIControlStateNormal];
    [rebutton addTarget:self action:@selector(registerBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rebutton];

}

- (void)createRegisterBtn
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];//获取当前版本
    
    [[AFHttpModelTool shareAFHttpModelTool] createRegisteredEntranceVersion:app_Version
                                                                 Completion:^(RegisterModel *registerModel) {
                                                                     
                                                                     if ([registerModel.status isEqualToString:@"success"]) {
                                                                         [self CreateRegistrationButton];
                                                                     }
                                                                     
                                                                     } failure:^(NSError *error) {
                                                                         [self creatAlertController];
        
                                                                 }];

}

- (void)creatAlertController
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"您的网络似乎有点问题"
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定"
                                                         style:UIAlertActionStyleCancel
                                                       handler:^(UIAlertAction * _Nonnull action) {
                                                           [self createRegisterBtn];
                                                           
                                                       }];
    [alertController addAction:sureAction];
    [self presentViewController:alertController animated:YES completion:nil];

}

//  http://oaapp.anji-allways.com:800/webapi/CommonHelper.ashx?action=isOpenRegistration&version=1.0.6

- (void)registerBtnClick
{
    RegisterViewController *registerVC = [[RegisterViewController alloc] init];
    [self presentViewController:registerVC animated:YES completion:nil];
    
}


@end
