//
//  RegisterViewController.m
//  OfficeSoftwore
//
//  Created by 郭川 on 16/8/26.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "RegisterViewController.h"
#import "AFHttpModelTool.h"
#import "LoginModel.h"


@interface RegisterViewController ()
{
    UITextField *nameField;
    UITextField *phoneField;
    UITextField *idField;
}
@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
    
    self.navigationItem.title = @"注册";
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(10, 110, 90, 36)];
    name.text = @"姓名";
    name.textColor = [UIColor colorWithHexString:@"#4ab6d3"];
    
    UILabel *phone = [[UILabel alloc] initWithFrame:CGRectMake(10, 150, 90, 36)];
    phone.text = @"手机号码";
    phone.textColor = [UIColor colorWithHexString:@"#4ab6d3"];

    UILabel *idNumber = [[UILabel alloc] initWithFrame:CGRectMake(10, 190, 90, 36)];
    idNumber.text = @"身份证号码";
    idNumber.textColor = [UIColor colorWithHexString:@"#4ab6d3"];

    nameField = [[UITextField alloc] initWithFrame:CGRectMake(110, 110, APP_SCREEN_WIDTH-110-20, 35)];
    nameField.placeholder = @"请输入姓名";
    nameField.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [nameField setValue:[UIFont systemFontOfSize:13]forKeyPath:@"_placeholderLabel.font"];
    
    phoneField = [[UITextField alloc] initWithFrame:CGRectMake(110, 150, APP_SCREEN_WIDTH-110-20, 35)];
    phoneField.placeholder = @"请输入手机号码";
    phoneField.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [phoneField setValue:[UIFont systemFontOfSize:13]forKeyPath:@"_placeholderLabel.font"];
    phoneField.keyboardType = UIKeyboardTypeNumberPad;
    
    idField = [[UITextField alloc] initWithFrame:CGRectMake(110, 190, APP_SCREEN_WIDTH-110-20, 35)];
    idField.placeholder = @"请输入身份证号";
    idField.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [idField setValue:[UIFont systemFontOfSize:13]forKeyPath:@"_placeholderLabel.font"];
    
    UIView *nameView = [[UIView alloc] initWithFrame:CGRectMake(110, 136, APP_SCREEN_WIDTH-110-20, 1)];
    nameView.backgroundColor = [UIColor lightGrayColor];
    UIView *phoneView = [[UIView alloc] initWithFrame:CGRectMake(110, 176, APP_SCREEN_WIDTH-110-20, 1)];
    phoneView.backgroundColor = [UIColor lightGrayColor];
    UIView *idView = [[UIView alloc] initWithFrame:CGRectMake(110, 216, APP_SCREEN_WIDTH-110-20, 1)];
    idView.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *sureBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 260, APP_SCREEN_WIDTH, 40)];
    sureBtn.backgroundColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [sureBtn setTitle:@"确认" forState:UIControlStateNormal];
    [sureBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sureBtn addTarget:self action:@selector(sureBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    UIView *navItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 70)];
    navItemView.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
    
    UIButton *CancelBtn = [[UIButton alloc] initWithFrame:CGRectMake(APP_SCREEN_WIDTH-80, 40, 80, 30)];
    CancelBtn.backgroundColor = [UIColor clearColor];
    [CancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    CancelBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [CancelBtn setTitleColor:[UIColor colorWithHexString:@"#4ab6d3"] forState:UIControlStateNormal];
    [CancelBtn addTarget:self action:@selector(CancelClick) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(APP_SCREEN_WIDTH/2-50/2, 40, 50, 30)];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColor colorWithHexString:@"#4ab6d3"];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"注册";
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, APP_SCREEN_HEIGHT-213, APP_SCREEN_WIDTH, 213)];
    imageView.image = [UIImage imageNamed:@"background_img.png"];
    
    [self.view addSubview:name];
    [self.view addSubview:phone];
    [self.view addSubview:idNumber];
    [self.view addSubview:nameField];
    [self.view addSubview:phoneField];
    [self.view addSubview:idField];
    [self.view addSubview:nameView];
    [self.view addSubview:phoneView];
    [self.view addSubview:idView];
    
    [self.view addSubview:sureBtn];
    [self.view addSubview:navItemView];
    [navItemView addSubview:CancelBtn];
    [navItemView addSubview:titleLabel];
    [self.view addSubview:imageView];
    
    
}

- (void)sureBtnClick
{
    if (![self notEmpty]) {
        return;
    }
    NSLog(@"---%@",nameField.text);
    
    [[AFHttpModelTool shareAFHttpModelTool] getloginUserInforToken:nameField.text
                                                        clientType:phoneField.text
                                                     clientVersion:idField.text
                                                        Completion:^(PersonModel *person) {
                                                            NSLog(@"---%@",nameField.text);
                                                            
                                                            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"您的信息已提交公司审核,请耐心等待" preferredStyle:UIAlertControllerStyleAlert];
                                                            UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                                                                [self dismissViewControllerAnimated:YES completion:nil];
                                                                
                                                            }];
                                                            [alertController addAction:sureAction];
                                                            [self presentViewController:alertController animated:YES completion:nil];


                                                        } failure:^(NSError *error) {
                                                            NSLog(@"---%@",nameField.text);

                                                        }];

    
    
    
}

- (void)CancelClick
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (BOOL)notEmpty
{
    if (nameField.text.length == 0) {
        [CustomAlertMessage showAlertMessage:@"姓名不能为空"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];
        return NO;
    }else if (![self validateChineseEnglishNumber:nameField.text]){
        
        [CustomAlertMessage showAlertMessage:@"请输入正确的姓名"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];

        return NO;
    }else if (phoneField.text.length == 0){
        [CustomAlertMessage showAlertMessage:@"手机号码不能为空"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];
        return NO;
    }else if (![self validateMobile:phoneField.text]){
        [CustomAlertMessage showAlertMessage:@"手机号码格式不正确"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];
        return NO;

    }else if (idField.text.length == 0){
        [CustomAlertMessage showAlertMessage:@"身份证号码不能为空"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];
        return NO;
    }else if (![self validateIDCardNumber:idField.text]) {
        [CustomAlertMessage showAlertMessage:@"身份证号码格式不正确"
                             andButtomHeight:(APP_SCREEN_HEIGHT/5.0)*3];
        return NO;
    }
    return YES;
}


-(BOOL)validateChineseEnglishNumber:(NSString *)str{
    NSString *regex = @"[a-zA-Z\u4e00-\u9fa5][a-zA-Z0-9\u4e00-\u9fa5]+";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    if (([pred evaluateWithObject:str] == YES)){
        return YES;
    }else{
        return NO;
    }
}

#pragma mark 正则校验电话号
- (BOOL)validateMobile:(NSString *)mobileNum{
    /**
     * 手机号码
     * 移动：134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     * 联通：130,131,132,152,155,156,185,186
     * 电信：133,1349,153,180,189
     */
    NSString * MOBILE = @"^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$";
    /**
     * 中国移动：China Mobile
     * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     */
    NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d)\\d{7}$";
    /**
     * 中国联通：China Unicom
     * 130,131,132,152,155,156,185,186
     */
    NSString * CU = @"^1(3[0-2]|5[256]|8[56])\\d{8}$";
    /**
     * 中国电信：China Telecom
     * 133,1349,153,180,189
     */
    NSString * CT = @"^1((33|53|8[09])[0-9]|349)\\d{7}$";
    /**
     * 大陆地区固话及小灵通
     * 区号：010,020,021,022,023,024,025,027,028,029
     * 号码：七位或八位
     */
    // NSString * PHS = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    
    if (([regextestmobile evaluateWithObject:mobileNum] == YES)
        || ([regextestcm evaluateWithObject:mobileNum] == YES)
        || ([regextestct evaluateWithObject:mobileNum] == YES)
        || ([regextestcu evaluateWithObject:mobileNum] == YES))
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
#pragma mark 正则校验身份证
-(BOOL)validateIDCardNumber:(NSString *)value {
    value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    int length = 0;
    if (!value) {
        return NO;
    }else {
        //        length = value.length;
        
        length = [[NSString stringWithFormat:@"%lu",(unsigned long)value.length] intValue];
        
        if (length !=15 && length !=18) {
            return NO;
        }
    }
    // 省份代码
    NSArray *areasArray =@[@"11",@"12", @"13",@"14", @"15",@"21", @"22",@"23", @"31",@"32", @"33",@"34", @"35",@"36", @"37",@"41", @"42",@"43", @"44",@"45", @"46",@"50", @"51",@"52", @"53",@"54", @"61",@"62", @"63",@"64", @"65",@"71", @"81",@"82", @"91"];
    
    NSString *valueStart2 = [value substringToIndex:2];
    BOOL areaFlag =NO;
    for (NSString *areaCode in areasArray) {
        if ([areaCode isEqualToString:valueStart2]) {
            areaFlag =YES;
            break;
        }
    }
    
    if (!areaFlag) {
        return false;
    }
    
    
    NSRegularExpression *regularExpression;
    NSUInteger numberofMatch;
    
    int year =0;
    switch (length) {
        case 15:
            year = [[value substringWithRange:NSMakeRange(6,2)] intValue] +1900;
            
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }else {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            
            
            if(numberofMatch >0) {
                return YES;
            }else {
                return NO;
            }
        case 18:
            
            year = [[value substringWithRange:NSMakeRange(6,4)] intValue];
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }else {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            
            
            if(numberofMatch >0) {
                int S = ([value substringWithRange:NSMakeRange(0,1)].intValue + [value substringWithRange:NSMakeRange(10,1)].intValue) *7 + ([value substringWithRange:NSMakeRange(1,1)].intValue + [value substringWithRange:NSMakeRange(11,1)].intValue) *9 + ([value substringWithRange:NSMakeRange(2,1)].intValue + [value substringWithRange:NSMakeRange(12,1)].intValue) *10 + ([value substringWithRange:NSMakeRange(3,1)].intValue + [value substringWithRange:NSMakeRange(13,1)].intValue) *5 + ([value substringWithRange:NSMakeRange(4,1)].intValue + [value substringWithRange:NSMakeRange(14,1)].intValue) *8 + ([value substringWithRange:NSMakeRange(5,1)].intValue + [value substringWithRange:NSMakeRange(15,1)].intValue) *4 + ([value substringWithRange:NSMakeRange(6,1)].intValue + [value substringWithRange:NSMakeRange(16,1)].intValue) *2 + [value substringWithRange:NSMakeRange(7,1)].intValue *1 + [value substringWithRange:NSMakeRange(8,1)].intValue *6 + [value substringWithRange:NSMakeRange(9,1)].intValue *3;
                int Y = S %11;
                NSString *M =@"F";
                NSString *JYM =@"10X98765432";
                M = [JYM substringWithRange:NSMakeRange(Y,1)];// 判断校验位
                if ([M isEqualToString:[[value uppercaseString] substringWithRange:NSMakeRange(17,1)]]) {
                    return YES;// 检测ID的校验位
                }else {
                    return NO;
                }
                
            }else {
                return NO;
            }
        default:
            return false;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
