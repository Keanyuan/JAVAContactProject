//
//  LoginViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/26.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"
#import "AppDelegate.h"

@interface LoginViewController : BaseViewController<UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *login;

@property (weak, nonatomic) IBOutlet UILabel *titlelable;

@property (weak, nonatomic) IBOutlet UIView *pwView;
@property (weak, nonatomic) IBOutlet UIView *userView;


@property (weak, nonatomic) IBOutlet UIImageView *BGImage;


//@property (weak, nonatomic) IBOutlet UIScrollView *l_scrollView;


@property (weak, nonatomic) IBOutlet UIImageView *logoImage;




@end
