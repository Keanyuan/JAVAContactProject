//
//  GroupViewController.m
//  OfficeSoftwore
//
//  Created by user on 16/7/15.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "GroupViewController.h"
#import "ContractModel.h"
#import "ContracListModel.h"
#import "ChatViewController.h"


@interface GroupViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITextField *textfield;
    NSMutableArray      *_newDataArray;
    ContracListModel *userInfo;
}
@end

@implementation GroupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"选择联系人";//自己建的没用到
    _newDataArray = [[NSMutableArray alloc] init];

    
//    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(APP_SCREEN_WIDTH/2, 0, APP_SCREEN_WIDTH/2, 40)];
//    button.backgroundColor = [UIColor lightGrayColor];
//    [button setTitle:@"确定" forState:UIControlStateNormal];
//    [button setTintColor:[UIColor colorWithHexString:@"#4ab6d3"]];
//    [button addTarget:self action:@selector(buttonSure) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:button];
    
    UIBarButtonItem *button_sure = [[UIBarButtonItem alloc] initWithTitle:@"确定" style:UIBarButtonItemStyleDone target:self action:@selector(button_sure_click)];
    [button_sure setTintColor:[UIColor colorWithHexString:@"#4ab6d3"]];
    [self.navigationItem setRightBarButtonItem:button_sure];

    
    textfield = [[UITextField alloc] init];
    
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT-65) style:UITableViewStylePlain];
    _tableView.bounces = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:_tableView];
    
    [self initWithData];

}
//请求数据
- (void)initWithData
{
    [self showLoadingView:nil];
    
    [[AFHttpModelTool shareAFHttpModelTool] getContractListToken:[CommonMethod getToken]
                                                      Completion:^(ContractModel *user) {
                                                          if (user) {
                                                              if ([user.result count] != 0) {
                                                                  
                                                                  [self hiddenLoadingView];
                                                                  
                                                                  [_newDataArray addObjectsFromArray:user.result];
                                                                  
                                                                  [_tableView reloadData];
                                                              }
                                                          }else{
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                          }
                                                      } failure:^(NSError *error) {
                                                          [self hiddenLoadingView];
                                                      }];
}
#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
        return _newDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellidentifier = @"cell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellidentifier];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidentifier];
    }
    
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(80, 10, 30, 30)];
    UILabel *name_label = [[UILabel alloc] initWithFrame:CGRectMake(120, 5, 120, 15)];
    UILabel *unit_label = [[UILabel alloc] initWithFrame:CGRectMake(120, 25, 120, 14)];
    name_label.textColor = [UIColor colorWithHexString:@"474747"];
    unit_label.textColor = [UIColor colorWithHexString:@"999999"];
    name_label.font = [UIFont systemFontOfSize:15];
    unit_label.font = [UIFont systemFontOfSize:12];
    [cell addSubview:image];
    [cell addSubview:name_label];
    [cell addSubview:unit_label];
    
    userInfo = _newDataArray[indexPath.row];
    name_label.text = userInfo.userName;
    unit_label.text = userInfo.unitNam;
    [image sd_setImageWithURL:[NSURL URLWithString:userInfo.imageurl] placeholderImage:[UIImage imageNamed:@"tagging.png"]];

    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}


- (void)button_sure_click {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
