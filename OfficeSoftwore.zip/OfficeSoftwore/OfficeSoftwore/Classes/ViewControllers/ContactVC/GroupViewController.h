//
//  GroupViewController.h
//  OfficeSoftwore
//
//  Created by user on 16/7/15.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface GroupViewController : BaseViewController
@property (nonatomic, strong)UITableView *tableView;
@end
