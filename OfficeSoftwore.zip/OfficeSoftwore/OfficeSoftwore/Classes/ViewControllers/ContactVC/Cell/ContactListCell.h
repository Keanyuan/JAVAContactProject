//
//  ContactListCell.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol ContactListCellDelegate <NSObject>

@required
- (void)handlerMessageAction:(NSString *)phoneNumber name:(NSString *)name;
- (void)handlerPhoneAction:(NSString *)phoneNumber name:(NSString *)name;
- (void)handlerEaseAction:(NSString *)userAccount name:(NSString *)name;
@end

@interface ContactListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *userImage;

@property (strong,nonatomic) NSString *phoneNumber;
@property (strong,nonatomic) NSString *name;
@property (strong,nonatomic) NSString *userAccount;

@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UILabel *userPhone;
@property (assign,nonatomic)id<ContactListCellDelegate>delegate;
@end
