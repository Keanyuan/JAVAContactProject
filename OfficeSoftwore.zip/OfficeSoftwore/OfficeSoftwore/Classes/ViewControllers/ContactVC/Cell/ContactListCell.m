//
//  ContactListCell.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/27.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "ContactListCell.h"

@implementation ContactListCell

- (void)awakeFromNib {
    // Initialization code
}
- (IBAction)phoneAction:(id)sender {
    //代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(handlerPhoneAction: name:)]) {
        [self.delegate handlerPhoneAction:self.phoneNumber name:self.name];
    }
}
- (IBAction)messageAction:(id)sender {
    //代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(handlerPhoneAction: name:)]) {
        [self.delegate handlerMessageAction:self.phoneNumber  name:self.name];
    }

}

- (IBAction)easeAction:(id)sender {
    //代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(handlerPhoneAction: name:)]) {
        [self.delegate handlerEaseAction:self.userAccount  name:self.name];
    }
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
