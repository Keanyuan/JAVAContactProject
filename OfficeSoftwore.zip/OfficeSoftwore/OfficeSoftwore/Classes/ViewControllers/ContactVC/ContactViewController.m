//
//  ContactViewController.m
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/25.
//  Copyright (c) 2015年 wangwang. All rights reserved.
//  EasemobPassword

#import "ContactViewController.h"
#import "ContractModel.h"
#import "ContracListModel.h"
#import "ContactListCell.h"
#import "ChatViewController.h"


@interface ContactViewController ()<UISearchDisplayDelegate,UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,ContactListCellDelegate,UIAlertViewDelegate>
{
    BOOL                _enableCall400;
    NSMutableArray      *_newDataArray;
    ContracListModel *userInfo;

}

@end

@implementation ContactViewController

- (void)viewWillAppear:(BOOL)animate{
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [CommonMethod validateToken];///
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

    
    _filterData = [[NSMutableArray alloc] init];
    _newDataArray = [[NSMutableArray alloc] init];
    
    self.tableView.bounces = NO;

    [self initWithData];
    [self tableViewAndSearchDisplyerController];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];

}

//请求数据
- (void)initWithData
{
    [self showLoadingView:nil];

    [[AFHttpModelTool shareAFHttpModelTool] getContractListToken:[CommonMethod getToken]
                                                      Completion:^(ContractModel *user) {
        if (user) {
            if ([user.result count] != 0) {
                
                [self hiddenLoadingView];
                
                [_newDataArray addObjectsFromArray:user.result];
                
                [_tableView reloadData];
            }else {
                [self hiddenLoadingView];
                [self showOnlyTextAlertView:@"联系人信息为空"];
            }

        }else{
            [self hiddenLoadingView];
            [self showOnlyTextAlertView:@"加载失败"];
        }
    } failure:^(NSError *error) {
            [self hiddenLoadingView];
    }];
}


//联系人搜索
- (void)tableViewAndSearchDisplyerController
{
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    UIView *bgview = [[UIView alloc]init];
    bgview.frame = searchBar.frame;
    bgview.backgroundColor = Gcolor(@"#f0f9fc");
//    Maincolor;
    UIImage *bgimage = [CommonMethod convertViewToImage:bgview];
    searchBar.placeholder = @"搜索";
    searchBar.backgroundImage = bgimage;
//    [UIImage imageNamed:@"bgimage"];
    searchBar.delegate = self;
    searchBar.showsScopeBar = YES;
    [searchBar setContentMode:UIViewContentModeTopLeft];
    searchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    
//    self.tableView.tableHeaderView.backgroundColor = Maincolor;
//    UIView *headerview = [[UIView alloc]initWithFrame:searchBar.frame];
//    headerview.backgroundColor = Maincolor;
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [btn setTitle:@"搜索" forState:UIControlStateNormal];
//    btn.backgroundColor = [UIColor whiteColor] ;
//    btn.frame = CGRectMake(20,10,APP_SCREEN_WIDTH-40,24);
//    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//    [btn setImage:[UIImage imageNamed:@"search"] forState:UIControlStateNormal];
//    [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
//    btn.layer.masksToBounds = YES;
//    btn.layer.cornerRadius = 6;
//    [btn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
//    [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
//    btn.titleLabel.font = Font(14);
//    [headerview addSubview:btn];
//    self.tableView.tableHeaderView = btn;
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
    [self.view addSubview:searchBar];

//    [self.tableView setTableHeaderView:searchBar];
    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    _searchDisplayController.delegate = self;

    
    [self.tableView registerNib:[UINib nibWithNibName:@"ContactListCell" bundle:nil] forCellReuseIdentifier:@"contract"];
    [_searchDisplayController.searchResultsTableView registerNib:[UINib nibWithNibName:@"ContactListCell" bundle:nil] forCellReuseIdentifier:@"contract"];

    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
}

#pragma mark - viewWillDisappear

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self hiddenLoadingView];
    [self endRefreshWithTableView:self.tableView];

}


#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{  
    
    if (tableView == self.tableView){
        
        return _newDataArray.count;
    }else{
        // 谓词搜索
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains [cd] %@",_searchDisplayController.searchBar.text];
        
        if (self.filterData!= nil) {
            [self.filterData removeAllObjects];
        }
        NSMutableArray *listModelArray = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray *userNameArray = [NSMutableArray arrayWithCapacity:0];
        
        for (int i = 0 ; i < _newDataArray.count; i++) {
            ContracListModel *listModel = _newDataArray[i];
            
            [userNameArray addObject:listModel.userName];
            [listModelArray addObject:listModel];
        }
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjects:listModelArray forKeys:userNameArray];
        NSMutableArray *array = [[NSMutableArray alloc] init];
        NSArray *Arr = [[NSArray alloc] init];
        Arr = [userNameArray filteredArrayUsingPredicate:predicate];
        for (NSString *name in Arr) {
            [array addObject:dic[name]];
        }
        _filterData =  [[NSMutableArray alloc] initWithArray:array];
        return _filterData.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ContactListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contract"];

    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [cell addSubview:view];
    cell.backgroundColor = [UIColor clearColor];
    // 需要添加footview否则最下方没有分割线
    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];

    
    cell.delegate = self;
//    ContracListModel *userInfo;
    if (tableView == self.tableView) {
        userInfo = _newDataArray[indexPath.row];
        
    }else{
        userInfo = _filterData[indexPath.row];
    }
    cell.userName.text = userInfo.userName;
    cell.userPhone.text = userInfo.unitNam;
    
    cell.phoneNumber = userInfo.telephone;
    cell.name = userInfo.userName;
    cell.userAccount = userInfo.UserAccount;
    [cell.userImage sd_setImageWithURL:[NSURL URLWithString:userInfo.imageurl] placeholderImage:[UIImage imageNamed:@"tagging.png"]];
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 54;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"----%@",indexPath);
}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    return YES;
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    [self endRefreshWithTableView:self.tableView];
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{

    return YES;
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSString *string = searchBar.text;
    NSLog(@"%@",string);
    
}
// called when keyboard search button pressed

#pragma mark - ContactListCellDelegate
//聊天
- (void)handlerEaseAction:(NSString *)userAccount name:(NSString *)name
{
    ChatViewController *chatController = [[ChatViewController alloc] initWithConversationChatter:userAccount
                                                                                conversationType:EMConversationTypeChat];

    chatController.title = name;
    chatController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:chatController animated:YES];

}
//打电话
- (void)handlerPhoneAction:(NSString *)phoneNumber name:(NSString *)name
{
    if ([phoneNumber isEqualToString:@""]) {
        showMsg(@"电话号码为空,无法拨打电话");
    }else{

        NSString *str = [NSString stringWithFormat:@"是否拨打 * %@ * 的电话",name];
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:str message:phoneNumber preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"否" style:UIAlertActionStyleDefault handler:nil];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            [self callPhone:[NSString stringWithFormat:@"%@",phoneNumber]];

        }];
        
        [alertController addAction:sureAction];
        [alertController addAction:cancelAction];
        [self presentViewController:alertController animated:YES completion:nil];

    }
}

//发短信
- (void)handlerMessageAction:(NSString *)phoneNumber name:(NSString *)name
{
    if ([phoneNumber isEqualToString:@""]) {
        
        showMsg(@"手机号为空");
    }else{
        
        [self createMessageViewControllerWithPhoneNum:phoneNumber];
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
