//
//  WaitWebJS.h
//  OfficeSoftwore
//
//  Created by user on 16/6/24.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol WaitWebJSProtocol <JSExport>

- (void)onApproveSuccess;
//- (void)onApproveSuccess:(NSString *)message;

@end

@interface WaitWebJS : NSObject<WaitWebJSProtocol>

@end
