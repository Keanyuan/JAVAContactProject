//
//  WaitViewController.m
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/25.
//  Copyright (c) 2015年 wangwang. All rights reserved.
//

#import "WaitViewController.h"
#import "WaitListModel.h"
#import "WaitModel.h"
#import "WaitListCell.h"
#import "WaitDetailViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
//#import "WaitWebJS.h"

@interface WaitViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>
{
    NSMutableArray *_newDataArray;
    NSInteger _i;
    NSInteger _totalPage;
    int SelectRow;
    NSString *countnumber;
    NSString *wait_select;
    NSString *select_cell;
    int  number_count;
    BOOL  refresh;
    NSString *badge_str;
    UIImageView *imgView;
}
@end

@implementation WaitViewController

-(void)viewWillAppear:(BOOL)animated {
    [CommonMethod validateToken];
    badge_str = [CommonMethod getBadge];
    if ([badge_str isEqualToString:@"1"]) {
        [self getWaitToDo];
    }
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(waitRefreshOrNot:)
                                                 name:@"WaitRefresh"
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(selectRow_cell:)
                                                 name:@"selectCell"
                                               object:nil];
}
//获取listVC操作行
- (void)selectRow_cell:(NSNotification *)notification {
    select_cell = notification.userInfo[@"SelectRow"];
    NSLog(@"%@",select_cell);
}
//- (void)reciveMassage:(NSNotification *)notification {
//    NSString *_str = notification.userInfo[@"recive_msg"];
//    if ([_str isEqualToString:@"str_yes"] && [badge_str isEqualToString:@"0"]) {
////        [self headerRefreshMethod];
//        [self getWaitToDo];
//
//    }
//}

//- (void)WaitNumbers:(NSNotification *)notification {
//    NSString *str = notification.userInfo[@"bdnumber"];
//    number_count = [str intValue];
//    if (number_count == 0) {
//        refresh = YES;
//    }
//    if (number_count == 1) {
//        refresh = YES;
////        [self headerRefreshMethod];
//        [self getWaitToDo];
//    }
//}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(reciveMassage:)
//                                                 name:@"Recive_msg"
//                                               object:nil];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(WaitNumbers:)
//                                                 name:@"waitNumber"
//                                               object:nil];

    
    self.view.backgroundColor = [UIColor whiteColor];
    _i = 0;
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

    
    _newDataArray = [[NSMutableArray alloc] init];
    _filterData = [[NSMutableArray alloc] init];
    
    [self initTableViewAndSearchDisplyerController];

    [self initRequestList];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [self getWaitToDo];
    
    
}
//JS调用OC
- (void)waitRefreshOrNot:(NSNotification *)notification {
    NSLog(@"%@",notification.userInfo[@"waitRefreshh"]);
    NSString *yesOrNo = notification.userInfo[@"waitRefreshh"];
    if ([yesOrNo isEqualToString:@"YES"]) {
        
        //办结成功后发通知到CompleteViewController,实现刷新
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"Refresh_com"
//                                                            object:self
//                                                          userInfo:@{@"refresh_com":wait_select
//                                                                     }];

        NSLog(@"---%d",SelectRow);
        NSLog(@"_i = %ld",(long)_i);
        NSLog(@"_totalPage = %ld",(long)_totalPage);
        
        if (select_cell != nil) {
         int list_select_cell = [select_cell intValue];
            SelectRow = list_select_cell;
            select_cell = nil;
        }
        
        if (SelectRow != 999999) {
            //删除数据源及选中行（已经办结事项）
            [_newDataArray removeObjectAtIndex:SelectRow];
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:SelectRow inSection:0];
            [_tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            SelectRow = 999999;
            [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                object:countnumber];
            NSLog(@"_i = %ld",(long)_i);

        }
        
        if (_newDataArray.count == 0) {
            self.tableView.backgroundView.alpha = 1;
        }else {
            self.tableView.backgroundView.alpha = 0;
        }
        
        NSLog(@"_i = %ld",(long)_i);
        NSLog(@"_totalPage = %ld",(long)_totalPage);
    }
    
}

- (void)initTableViewAndSearchDisplyerController
{
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    UIImage *bgimage = [UIColor imageWithColor:[UIColor colorWithHexString:@"#f0f9fc"]];
    searchBar.placeholder = @"搜索";
    searchBar.delegate = self;
    searchBar.backgroundImage = bgimage;
    searchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [self.view addSubview:searchBar];
    
    imgView = [[UIImageView alloc] init];
    imgView.contentMode = UIViewContentModeCenter;
    imgView.image = [UIImage imageNamed:@"blank_undo"];
    self.tableView.backgroundView = imgView;
    
    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"WaitListCell" bundle:nil] forCellReuseIdentifier:@"wait"];
    [_searchDisplayController.searchResultsTableView registerNib:[UINib nibWithNibName:@"WaitListCell" bundle:nil] forCellReuseIdentifier:@"wait"];
    
    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
}

//请求数据
- (void)requestDatapageSize:(NSInteger )pageSize tittle:(NSString *)tittle Success:(void (^)(NSString *recordCount))success failure:(void (^)())failure
{
    [self showLoadingView:nil];
    NSLog(@"_i = %ld",(long)_i);

    [[AFHttpModelTool shareAFHttpModelTool] getWaitWithUserToken:[CommonMethod getToken]
                                                            type:ALL
                                                          tittle:tittle
                                                        pageSize:pageSize
                                                currentPageIndex:_i
                                                      Completion:^(WaitModel *waitProgress) {
                                                          NSLog(@"%@",waitProgress.recordCount);
                                                          if (waitProgress) {
                                                              _totalPage = ceil([waitProgress.recordCount integerValue]/10.0);
                                                              NSString *count = [NSString stringWithFormat:@"%@",waitProgress.recordCount];
                                                              success ? success(count) : nil;
                                                              int countt = [count intValue]-1 ;
                                                              countnumber = [NSString stringWithFormat:@"%d",countt];

                                                              if (_i == 0) {
                                                                  [_newDataArray removeAllObjects];
                                                              }

                                                              if ([waitProgress.result count] != 0) {
                                                                  
                                                                  
//                                                                  if (_i == 0) {
//                                                                      [_newDataArray removeAllObjects];
//                                                                  }
                                                                  
                                                                  [_newDataArray addObjectsFromArray:waitProgress.result];
                                                                  [self hiddenLoadingView];

                                                                  [self endRefreshWithTableView:self.tableView];
                                                                  
                                                                  [_tableView reloadData];
                                                                  
                                                              }else{
                                                                  
                                                                  [_newDataArray addObjectsFromArray:waitProgress.result];
                                                                  failure ? failure() : nil;

                                                                  [self hiddenLoadingView];
                                                                  [self endRefreshWithTableView:self.tableView];
                                                                  [_tableView reloadData];

                                                              }
//                                                              int str = 1;
//                                                              _newDataArray.count = str;
                                                              if (_newDataArray.count == 0) {
                                                                  self.tableView.backgroundView.alpha = 1;
                                                              }else {
                                                                  self.tableView.backgroundView.alpha = 0;
                                                              }

                                                          }else{
                                                              failure ? failure() : nil;

                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                              [_tableView reloadData];

                                                          }
                                                      } failure:^(NSError *error) {
                                                          failure ? failure() : nil;
                                                          [self endRefreshWithTableView:self.tableView];
                                                          [self hiddenLoadingView];
                                                          [_tableView reloadData];
                                                      }];
    
}

- (void)getWaitToDo{
    [self hiddenLoadingView];
    
    _i = 0;
    [self requestDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                            object:recordCount];
        
    }failure:nil];
}

- (void)viewDidAppear:(BOOL)animated
{

    [super viewDidAppear:animated];
    
//    [self hiddenLoadingView];
//
//    _i = 0;
//    [self requestDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
//        
//    [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
//                                                        object:recordCount];
//        
//    }failure:nil];
    
//    [self waitRefresh_row];

}
//第二种方法（未使用）
- (void)waitRefresh_row {
    
    NSLog(@"_i = %ld",(long)_i);
    
    NSLog(@"%d",SelectRow);
    if (SelectRow >= 11  ) {
        int SelectCell = SelectRow-1;
        NSLog(@"%d",SelectCell);
        NSLog(@"_i = %ld",(long)_i);
        
        if (_i < _totalPage || _i == _totalPage) {
            NSLog(@"_i = %ld",(long)_i);
            _i++;
            [self requestDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                    object:recordCount];
            } failure:nil];
            SelectRow = 0;
            
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:SelectCell inSection:0];
            [self.tableView scrollToRowAtIndexPath:scrollIndexPath
                                  atScrollPosition:UITableViewScrollPositionNone animated:YES];
        }
        
    }else if (SelectRow == 0||SelectRow < 11){
        _i = 0;
        [self requestDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                object:recordCount];
            
        } failure:nil];
    }
}

#pragma mark - MJRefreshMethod
-(void)initRequestList
{
    [self showLoadingView:nil];
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self headerRefreshMethod];
    }];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self footerRefreshMethod];
        
    }];

}

#pragma mark - MJRefreshMethod
-(void)headerRefreshMethod
{
    NSInteger tempPage = _i;
    _i = 0;
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
        _i = tempPage;
    }];

}

-(void)footerRefreshMethod
{
    _i++;
    NSLog(@"_i = %ld",(long)_i);
    if (_i >= _totalPage) {
        [self endRefreshWithTableView:self.tableView];
        _i--;
    } else {
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
            _i--;
        }];
    }

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];
//    [self endRefreshWithTableView:self.tableView];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tableView) {
        return _newDataArray.count;
    }else{
        return _filterData.count;
        }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    WaitListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"wait"];
    UIImageView *image = [[UIImageView alloc]initWithImage: [UIImage imageNamed:@"list_right"]];
    cell.accessoryView = image;
    //分割线
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [cell addSubview:view];
    cell.backgroundColor = [UIColor clearColor];

    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];


//    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
    WaitListModel *userInfo = nil;
    
    if (tableView == self.tableView) {

        userInfo = _newDataArray[indexPath.row];
    }else{
        
        userInfo = _filterData[indexPath.row];
    }
    
    cell.tittle.text = userInfo.title;
    cell.approve.text = userInfo.stepName;
    cell.applay.text = userInfo.processType;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 68;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WaitListModel *userInfo = nil;
    if (tableView == self.tableView) {
        userInfo = _newDataArray[indexPath.row];
    } else {
        userInfo = _filterData[indexPath.row];
    }
    WaitDetailViewController *WaitDetailVC = (WaitDetailViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"WaitDetailViewController"];
    WaitDetailVC.url = userInfo.url;

    WaitDetailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:WaitDetailVC animated:YES];
    NSLog(@"select_row---%ld",(long)indexPath.row);
    SelectRow = [@(indexPath.row) intValue];
    
    wait_select = [NSString stringWithFormat:@"%d",SelectRow];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"selectCell"
//                                                        object:self
//                                                      userInfo:@{@"SelectRow":selectcel
//                                                                 }];

    
}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (self.filterData!= nil) {
        [self.filterData removeAllObjects];
    }
    
    return YES;
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    [self endRefreshWithTableView:self.tableView];
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{   
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {

    [[AFHttpModelTool shareAFHttpModelTool] getWaitWithUserToken:[CommonMethod getToken]
                                                        type:ALL
                                                      tittle:searchBar.text
                                                    pageSize:99999999
                                            currentPageIndex:0
                                                  Completion:^(WaitModel *waitProgress) {
                                                      
                                                      if (self.filterData!= nil) {
                                                          [self.filterData removeAllObjects];
                                                      }
                                                      
                                                      if (waitProgress) {
                                                          
                                                          if ([waitProgress.result count] != 0) {
                                                              [self hiddenLoadingView];
                                                              
                                                              [_filterData addObjectsFromArray:waitProgress.result];
                                                              [_searchDisplayController.searchResultsTableView reloadData];

                                                          }else{
                                                              [self hiddenLoadingView];
                                                              [self endRefreshWithTableView:self.tableView];
                                                              [_searchDisplayController.searchResultsTableView reloadData];
                                                          }
                                                      }else{
                                                          [self hiddenLoadingView];
                                                          [self showOnlyTextAlertView:@"加载失败"];
                                                      }
                                                  } failure:^(NSError *error) {
                                                      [self hiddenLoadingView];
                                                      [_searchDisplayController.searchResultsTableView reloadData];
                                                  }];
    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
