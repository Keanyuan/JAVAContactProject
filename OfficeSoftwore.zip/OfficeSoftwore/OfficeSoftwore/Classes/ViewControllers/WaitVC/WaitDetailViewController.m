//
//  WaitDetailViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/5.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "WaitDetailViewController.h"
#import "CommonWebVC.h"
#import "WaitWebJS.h"


@interface WaitDetailViewController ()<UIWebViewDelegate>
{
    UIWebView *_webView;
    WebViewJavascriptBridge* _bridge;
    NSString *_currentURLString;
    NSString *select_cell;
}
@property (nonatomic, copy) finishBlock myBlock;

@end

@implementation WaitDetailViewController
- (instancetype)initWithBlock:(finishBlock)block{
    if (self = [super init]) {
        self.myBlock = block;
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
//    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    UIImage *bgimage = [UIColor imageWithColor:[UIColor colorWithHexString:@"#f0f9fc"]];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:bgimage];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"待办流程";
    [self initView];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView.scalesPageToFit = NO;
    _webView.delegate =self;
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.scrollView.bounces = NO;
    [self webViewRequestData:_webView];
    
    if (_bridge) { return; }
    //注册
    [WebViewJavascriptBridge enableLogging];
    _bridge = [WebViewJavascriptBridge bridgeForWebView:_webView webViewDelegate:self handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"__________ObjC received message from JS: %@", data);
        
        responseCallback(@"Response for message from ObjC");
    }];
    
    // js调oc方法
    [_bridge registerHandler:@"a" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSDictionary *dic = (NSDictionary *)data;
        CommonWebVC *commonWebVC = (CommonWebVC *)[CommonMethod storyBoardViewController:@"Main"
                                                                               identifer:@"CommonWebVC"];
        commonWebVC.url = dic[@"URL"];
        commonWebVC.title = dic[@"TITLE"];
        [self.navigationController pushViewController:commonWebVC animated:YES];
    }];
    
    // js调oc方法
    [_bridge registerHandler:@"go" handler:^(id data, WVJBResponseCallback responseCallback) {
        //事项办结后加载静态页面
        NSString *urlToken = [NSString stringWithFormat:@"%@%@",APPLY_URL,APPLY_SUCCESS];
        NSURL *url = [NSURL URLWithString:urlToken];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
//        [_webView loadRequest:request];
        
//        NSString *refresh = @"YES";
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"WaitRefresh"
//                                                            object:self
//                                                          userInfo:@{@"waitRefreshh":refresh}];

    }];
}

//  2016-08-18 08:48:48.256 OfficeSoftwore[2263:707068] WVJB RCVD: {"callbackId":"cb_1_1471481328252","handlerName":"a","data":{"URL":"http:\/\/10.108.6.213:83\/Handler\/Download.ashx?type=attachment&id=F633FAECF90B71421C29AEF70A150B32&fn=1.xlsx","TITLE":"附件内容"}}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}
/*
- (void)waitBack_web {
    if (_webView.canGoBack) {
        [_webView goBack];
        
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
*/

- (void)webViewRequestData:(UIWebView *)webView{
    if (self.url) {
        NSString *urlToken = self.url;
        NSURL *url = [NSURL URLWithString:urlToken];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [_webView loadRequest:request];
        
    }
}

#pragma  mark- UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:nil];
}

//jsInterface.onApproveSuccess();
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
    //    [self showOnlyTextAlertView:@"加载失败,请检查为网络"];
    
}
#pragma mark --webViewDelegate
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //网页加载之前会调用此方法
//    return YES;
    NSString *url = [[request URL] absoluteString];
    NSLog(@"url----==%@",url);
    if([url rangeOfString:@"Success.html"].length > 0){
        NSString *refresh = @"YES";
        [[NSNotificationCenter defaultCenter] postNotificationName:@"WaitRefresh"
                                                            object:self
                                                          userInfo:@{@"waitRefreshh":refresh
                                                                     }];
    }
//    Success.html
    return YES;
}

-(void)reloadSuccessHtml{
    _webView = nil;
}

-(void)dealloc
{
    _webView = nil;
    _webView.delegate = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
