//
//  WaitViewController.h
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/25.
//  Copyright (c) 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface WaitViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong,nonatomic) NSMutableArray *filterData;
@property (strong,nonatomic) UISearchDisplayController *searchDisplayController;


@end
