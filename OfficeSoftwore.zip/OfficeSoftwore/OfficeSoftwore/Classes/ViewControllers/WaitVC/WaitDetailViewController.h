//
//  WaitDetailViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/5.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface WaitDetailViewController : BaseViewController
//@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong,nonatomic) NSString *url;

typedef void(^finishBlock)(NSObject *model);
//提供一个函数
- (instancetype)initWithBlock:(finishBlock)block;

@end
