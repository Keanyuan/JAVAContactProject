//
//  WaitWebJS.m
//  OfficeSoftwore
//
//  Created by user on 16/6/24.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "WaitWebJS.h"

@implementation WaitWebJS

- (void)onApproveSuccess {
    
    NSString *refresh = @"YES";
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WaitRefresh"
                                                        object:self
                                                      userInfo:@{@"waitRefreshh":refresh}];
}

@end
