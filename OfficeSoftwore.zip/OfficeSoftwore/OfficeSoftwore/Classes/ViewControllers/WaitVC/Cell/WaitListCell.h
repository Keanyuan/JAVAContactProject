//
//  WaitListCell.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/3.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaitListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *tittle;
@property (weak, nonatomic) IBOutlet UILabel *approve;
@property (weak, nonatomic) IBOutlet UILabel *applay;
@end
