//
//  KLoacationModel.h
//  OfficeSoftwore
//
//  Created by KeanQ on 2017/12/6.
//  Copyright © 2017年 wangwang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KLoacationModel : NSObject
@property (copy ,nonatomic) NSString *longitudeP;
@property (copy ,nonatomic) NSString *latitudeP;
@property (copy ,nonatomic) NSString  *labeldetailadress;
- (instancetype)initWithLongitudeP:(NSString *)longitudeP latitudeP:(NSString *)latitudeP labeldetailadress:(NSString *)labeldetailadress;
@end
