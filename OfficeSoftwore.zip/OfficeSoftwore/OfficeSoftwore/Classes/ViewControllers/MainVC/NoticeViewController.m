//
//  NoticeViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "NoticeViewController.h"
#import "NoticeModel.h"
#import "NoticeListModel.h"
#import "NoticeAndMeetingViewCell.h"
#import "NoticeDetailViewController.h"

@interface NoticeViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>
{
    NSMutableArray *_newDataArray;
    NSInteger _i;
    NSInteger _totalPage;
    UIImageView *imgView;
}

@end

@implementation NoticeViewController
-(void)viewWillAppear:(BOOL)animated {
    [CommonMethod validateToken];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"公告通知";
    _i = 0;
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    _newDataArray = [[NSMutableArray alloc] init];
    _filterData = [[NSMutableArray alloc] init];
    
    [self initTableViewAndSearchDisplyerController];
    [self initView];
    [self initRequestList];
    
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

- (void)initTableViewAndSearchDisplyerController
{
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    UIView *bgview = [[UIView alloc]init];
    bgview.frame = searchBar.frame;
    bgview.backgroundColor = Gcolor(@"#f0f9fc");
    UIImage *bgimage = [CommonMethod convertViewToImage:bgview];
    searchBar.placeholder = @"搜索";
    searchBar.backgroundImage = bgimage;
    searchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    searchBar.delegate = self;
    [self.view addSubview:searchBar];
//    self.tableView.tableHeaderView = searchBar;
    
    imgView = [[UIImageView alloc] init];
    imgView.contentMode = UIViewContentModeCenter;
    imgView.image = [UIImage imageNamed:@"blank_undo"];
    self.tableView.backgroundView = imgView;

    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"NoticeAndMeetingViewCell" bundle:nil] forCellReuseIdentifier:@"NoticeAndMeetingViewCell"];
    [_searchDisplayController.searchResultsTableView registerNib:[UINib nibWithNibName:@"NoticeAndMeetingViewCell" bundle:nil] forCellReuseIdentifier:@"NoticeAndMeetingViewCell"];
    
    
    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
                                                                       
}

- (void)requestDatapageSize:(NSInteger )pageSize tittle:(NSString *)tittle Success:(void (^)())success failure:(void (^)())failure
{
    [self showLoadingView:nil];
    
//    [[AFHttpModelTool shareAFHttpModelTool] getNoticeWithUserToken:[CommonMethod getToken]
//                                                          tittle:tittle
//                                                        pageSize:pageSize
//                                                currentPageIndex:_i
//                                                      Completion:^(NoticeModel *noticeModel) {
//                                                          NSLog(@"-----%@",noticeModel);
//
//                                                          if (noticeModel) {
//                                                              _totalPage = ceil([noticeModel.recordCount integerValue]/10.0);
//                                                              
//                                                              if ([noticeModel.result count] != 0) {
//                                                                  success ? success() : nil;
//                                                                  [self hiddenLoadingView];
//                                                                  
//                                                                  if (_newDataArray!= nil) {
//                                                                      [_newDataArray removeAllObjects];
//                                                                  }
//                                                                  
//                                                                  [_newDataArray addObjectsFromArray:noticeModel.result];
//                                                                  
//                                                                  [self endRefreshWithTableView:_tableView];
//                                                                  
//                                                                  [self.tableView reloadData];
//                                                              }else{
//                                                                  [self hiddenLoadingView];
//                                                                  [self endRefreshWithTableView:self.tableView];
//                                                                  failure ? failure() : nil;
//                                                              }
//                                                          }else{
//                                                              [self hiddenLoadingView];
//                                                              [self showOnlyTextAlertView:@"加载失败"];
//                                                          }
//                                                      } failure:^(NSError *error) {
//                                                          failure ? failure() : nil;
//                                                          [self endRefreshWithTableView:self.tableView];
//                                                          [self hiddenLoadingView];
//                                                      }];

    
    [[AFHttpModelTool shareAFHttpModelTool] getNoticeWithUserToken:[CommonMethod getToken]
                                                            tittle:tittle
                                                          pageSize:pageSize
                                                  currentPageIndex:_i
                                                        Completion:^(NoticeModel *noticeModel) {
                                                            NSLog(@"-----%@",noticeModel);
                                                            
                                                            if (noticeModel) {
                                                                _totalPage = ceil([noticeModel.recordCount integerValue]/10.0);

                                                                if ([noticeModel.result count] != 0) {
    
                                                                    if (_i == 0) {
                                                                        [_newDataArray removeAllObjects];
                                                                    }
                                                                    [_newDataArray addObjectsFromArray:noticeModel.result];
                                                                    success ? success():nil;
                                                                    [self hiddenLoadingView];
                                                                    [self endRefreshWithTableView:self.tableView];
    
                                                                    [_tableView reloadData];
                                                                }else{
                                                                    failure ? failure() : nil;
    
                                                                    [self hiddenLoadingView];
                                                                    [self endRefreshWithTableView:self.tableView];
                                                                    [_tableView reloadData];
                                                                }
                                                                
                                                                if (_newDataArray.count == 0) {
                                                                    self.tableView.backgroundView.alpha = 1;
                                                                }else {
                                                                    self.tableView.backgroundView.alpha = 0;
                                                                }

                                                            }else{
                                                                failure ? failure() : nil;
    
                                                                [self hiddenLoadingView];
                                                                [self showOnlyTextAlertView:@"加载失败"];
                                                                [_tableView reloadData];
    
                                                            }
                                                        } failure:^(NSError *error) {
                                                            failure ? failure() : nil;
                                                            [self endRefreshWithTableView:self.tableView];
                                                            [self hiddenLoadingView];
                                                            [_tableView reloadData];
                                                            
                                                        }];

    
    
}

#pragma mark - MJRefreshMethod
-(void)initRequestList
{
    [self showLoadingView:nil];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self headerRefreshMethod];
    }];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self footerRefreshMethod];
    }];
    
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];////////
    
}

#pragma mark - MJRefreshMethod
-(void)headerRefreshMethod
{
    NSInteger tempPage = _i;
    _i = 0;
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
        _i = tempPage;
    }];
    
}

-(void)footerRefreshMethod
{
    _i++;
    if (_i >= _totalPage) {
        [self endRefreshWithTableView:self.tableView];
    } else {
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
            _i--;
        }];
    }
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];
    [self endRefreshWithTableView:self.tableView];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tableView) {
        return _newDataArray.count;
    }else{
        return _filterData.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NoticeAndMeetingViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NoticeAndMeetingViewCell"];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //分割线
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    cell.backgroundColor = [UIColor clearColor];
    [cell addSubview:view];

    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];

    
    NoticeListModel *userInfo = nil;
    
    if (tableView == self.tableView) {
        
        userInfo = _newDataArray[indexPath.row];
    }else{
        
        userInfo = _filterData[indexPath.row];
    }
    
    cell.tittle.text = userInfo.title;
    cell.dataTime.text = [CommonMethod getTimeString:userInfo.createDate
                                       setDateFormat:@"yyyy/MM/dd"];
                          
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 68;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NoticeListModel *userInfo = nil;
    if (tableView == self.tableView) {
        userInfo = _newDataArray[indexPath.row];
    } else {
        userInfo = _filterData[indexPath.row];
    }
    NoticeDetailViewController *NoticeDetailVC = (NoticeDetailViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"NoticeDetailViewController"];
    NoticeDetailVC.url = userInfo.url;
    NoticeDetailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:NoticeDetailVC animated:YES];
    
    
}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    
    if (self.filterData!= nil) {
        [self.filterData removeAllObjects];
    }
    return YES;
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    [self endRefreshWithTableView:self.tableView];
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
    [[AFHttpModelTool shareAFHttpModelTool] getNoticeWithUserToken:[CommonMethod getToken]
                                                          tittle:searchBar.text
                                                        pageSize:99999999
                                                currentPageIndex:0
                                                      Completion:^(NoticeModel *noticeModel) {
                                                          if (noticeModel) {
                                                              
                                                              if (self.filterData!= nil) {
                                                                  [self.filterData removeAllObjects];
                                                              }

                                                              if ([noticeModel.result count] != 0) {
                                                                  [self hiddenLoadingView];
                                                                  
                                                                  if (self.filterData!= nil) {
                                                                      [self.filterData removeAllObjects];
                                                                  }

                                                                  [_filterData addObjectsFromArray:noticeModel.result];
                                                                  [_searchDisplayController.searchResultsTableView reloadData];
                                                                  
                                                              }
                                                              
                                                          }else{
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                          }
                                                      } failure:^(NSError *error) {
                                                          [self hiddenLoadingView];
                                                          
                                                      }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
