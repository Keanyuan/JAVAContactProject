//
//  NoticeViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/6.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface NoticeViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong,nonatomic) NSMutableArray *filterData;
@property (strong,nonatomic) UISearchDisplayController *searchDisplayController;
@property (strong,nonatomic) NSString *url;

@end
