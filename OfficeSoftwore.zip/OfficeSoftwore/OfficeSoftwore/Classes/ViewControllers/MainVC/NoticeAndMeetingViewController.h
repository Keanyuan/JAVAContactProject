//
//  NoticeAndMeetingViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/26.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface NoticeAndMeetingViewController : BaseViewController

@property (strong,nonatomic) NSMutableArray *data;
@property (strong,nonatomic) NSMutableArray *filterData;
@property (strong,nonatomic) UISearchDisplayController *searchDisplayController;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
