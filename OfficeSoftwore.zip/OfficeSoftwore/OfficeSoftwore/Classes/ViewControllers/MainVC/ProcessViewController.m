//
//  ProcessViewController.m
//  OfficeSoftwore
//
//  Created by user on 16/8/11.
//  Copyright © 2016年 wangwang. All rights reserved.
//
//  个人发起流程申请

#import "ProcessViewController.h"
#import "CommonWebVC.h"

@interface ProcessViewController ()
{
//    WebViewJavascriptBridge* _bridge;
}
@property (nonatomic, copy) finishBlock myBlock;

@end

@implementation ProcessViewController
- (instancetype)initWithBlock:(finishBlock)block{
    if (self = [super init]) {
        self.myBlock = block;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = _title_apply;
    [self initView];
    NSLog(@"CarouselType == %@",_CarouselType);
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView = [[UIWebView alloc] init];
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.frame = CGRectMake(0, 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT-49);
    _webView.scalesPageToFit = NO;
    _webView.delegate = self;
    _webView.scrollView.bounces = NO;
    [self.view addSubview:_webView];
    [self webViewRequestData:_webView type:_CarouselType];
    
    if (_bridge) { return; }
    //注册JS
    [WebViewJavascriptBridge enableLogging];
    _bridge = [WebViewJavascriptBridge bridgeForWebView:_webView webViewDelegate:self handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"WebViewJavascriptBridge -- : %@", data);
        responseCallback(@"Response for message from ObjC");
    }];
    
    [_bridge registerHandler:@"go" handler:^(id data, WVJBResponseCallback responseCallback) {
        //申请成功加载静态页面
        NSString *urlToken = [NSString stringWithFormat:@"%@%@",APPLY_URL,APPLY_SUCCESS];
        NSURL *url = [NSURL URLWithString:urlToken];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
//        [_webView loadRequest:request];
        NSLog(@"%@",request);
        self.myBlock(urlToken);
    }];

    // js调oc方法
    [_bridge registerHandler:@"back" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSLog(@"WebViewJavascriptBridge -- : %@", data);
        
        [self.navigationController popViewControllerAnimated:YES];
    }];

}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //网页加载之前会调用此方法
    NSString *url = [[request URL] absoluteString];
    NSLog(@"url----==%@",url);
    return YES;
}


- (void)webViewRequestData:(UIWebView *)webView type:(NSString *)type{
    [self showLoadingView:nil];
    
    //EmployeeExpenseFees  //EmployeeLeave  //PurchaseApplication  //PurchaseReview  //PurchaseDrawings
    //BusinessTrip  //BusinessTripExceed  //PersonnelFinancialTaxesFees  //BusinessReception  //StampLicense
    
//    if ([type isEqualToString:@"EmployeeExpenseFees"]) {
//        NSLog(@"EmployeeExpenseFees");
    
//    }else if ([type isEqualToString:@"EmployeeLeave"]){
//
//    }else if ([type isEqualToString:@"PurchaseApplication"]){
//        NSLog(@"PurchaseApplication");
//
//    }else if ([type isEqualToString:@"PurchaseReview"]){
//        NSLog(@"PurchaseReview");
//
//    }else if ([type isEqualToString:@"PurchaseDrawings"]){
//        NSLog(@"PurchaseDrawings");
//
//    }else if ([type isEqualToString:@"BusinessTrip"]){
//        NSLog(@"BusinessTrip");
//
//    }else if ([type isEqualToString:@"BusinessTripExceed"]){
//        NSLog(@"BusinessTripExceed");
//
//    }else if ([type isEqualToString:@"PersonnelFinancialTaxesFees"]){
//        NSLog(@"PersonnelFinancialTaxesFees");
//
//    }else if ([type isEqualToString:@"BusinessReception"]){
//        NSLog(@"BusinessReception");
//
//    }else if ([type isEqualToString:@"StampLicense"]){
//        NSLog(@"StampLicense");
//
//    }
    
    
    
    NSString *strToken = @"UI/EmployeeLeave/Drafter.aspx?from=mobile";
    NSString *token = [CommonMethod getToken];
    NSString *urlToken = [NSString stringWithFormat:@"%@%@&token=%@",APPLY_URL,strToken,token];
    
    NSURL *url = [NSURL URLWithString:urlToken];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
    
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

#pragma  mark- UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:@"正在加载..."];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [self hiddenLoadingView];
    
    
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [CommonMethod validateToken];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    
}


-(void)dealloc
{
    _webView = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
