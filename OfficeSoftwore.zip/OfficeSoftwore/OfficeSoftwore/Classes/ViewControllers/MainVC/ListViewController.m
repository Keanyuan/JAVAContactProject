 //
//  ListViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/19.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "ListViewController.h"
#import "MainProcessCell.h"
#import "WaitListModel.h"
#import "WaitModel.h"
#import "CompleteModel.h"
#import "CompleteListModel.h"
#import "ListDetailViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "WaitWebJS.h"
#import "ProcessViewController.h"

#import "CompeleDetailViewController.h"



@interface ListViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,DZNEmptyDataSetDelegate,DZNEmptyDataSetSource,UISearchDisplayDelegate>
{
    BOOL                    _isFlag;
    BOOL                    _isImage;

    NSMutableArray          *_newDataArray;
    NSInteger               _i;
    NSInteger               _totalPage;
    UISearchBar             *ssearchBar;
    NSString                *countnumber;
    int SelectRow;
    int msgCount;
    NSString *selectcel;

    NSString *select_cell;
    UIImageView *imgView;


}

@property (strong ,nonatomic) UIButton *btn;

@property (weak, nonatomic) IBOutlet UIButton *waitProcessBtn;
@property (weak, nonatomic) IBOutlet UIButton *completeProcessBtn;
@property (weak, nonatomic) IBOutlet UIView *view_process;

@end

@implementation ListViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    _i = 0;
    _isFlag = 0;
    _isImage = 0;
    self.navigationController.navigationBar.translucent = NO;
    _newDataArray = [[NSMutableArray alloc] init];
    _filterData = [[NSMutableArray alloc] init];
    
    [self initView];
    //添加请假流程申请 -- EmployeeLeave
    if ([self.tittleType isEqualToString:@"EmployeeLeave"]) {
        [self add_applyForProcessBtn];
    }
    [self initTableViewAndSearchDisplyerController];
    
    [self initRequestList];
    
    [self viewBackgroundColor:_isFlag];
    
    UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStyleDone target:self action:@selector(searchBarClick)];
    [self.navigationItem setRightBarButtonItem:searchButton];
    
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    ssearchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    //请求
    [self requestListFailure:nil];

    
}

- (void)viewWillAppear:(BOOL)animate{
    [CommonMethod validateToken];

    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    self.navigationController.navigationBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(waitRefreshOrNot:)
                                                 name:@"WaitRefresh"
                                               object:nil];

}

- (void)waitRefreshOrNot:(NSNotification *)notification {
    NSLog(@"%@",notification.userInfo[@"waitRefreshh"]);
    NSString *yesOrNo = notification.userInfo[@"waitRefreshh"];
    
    if ([yesOrNo isEqualToString:@"YES"]) {
        
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"List_Cell"
//                                                            object:self
//                                                          userInfo:@{@"List_Row":selectcel
//                                                                     }];

        NSLog(@"---%d",SelectRow);
        NSLog(@"_i = %ld",(long)_i);
        NSLog(@"_totalPage = %ld",(long)_totalPage);
        if (SelectRow != 999999) {
            
            [_newDataArray removeObjectAtIndex:SelectRow];
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:SelectRow inSection:0];
            [_tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            SelectRow = 999999;
            [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                object:countnumber];
            NSLog(@"_i = %ld",(long)_i);
            
        }
        
        if (_newDataArray.count == 0) {
            self.tableView.backgroundView.alpha = 1;
        }else {
            self.tableView.backgroundView.alpha = 0;
        }

        NSLog(@"_i = %ld",(long)_i);
        NSLog(@"_totalPage = %ld",(long)_totalPage);
    }

    
}
//第二种方法（未使用）bug
- (void)ListRefresh_row {
    
    NSLog(@"_i = %ld",(long)_i);
    
    NSLog(@"%d",SelectRow);
    if (SelectRow >= 11  ) {
        int SelectCell = SelectRow-1;
        NSLog(@"%d",SelectCell);
        NSLog(@"_i = %ld",(long)_i);
        
        if (_i < _totalPage || _i == _totalPage) {
            NSLog(@"_i = %ld",(long)_i);
            
            [self requestWaitDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                    object:recordCount];
            } failure:nil];
            SelectRow = 0;
            
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:SelectCell inSection:0];
            [self.tableView scrollToRowAtIndexPath:scrollIndexPath
                                  atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
        }
        
    }else if (SelectRow == 0||SelectRow < 11){
        _i = 0;
        [self requestWaitDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                object:recordCount];
            
        } failure:nil];
    }
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                      initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil
                                           action:nil];
    
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];

}
//个人申请入口
- (void)add_applyForProcessBtn{
    UIBarButtonItem *rightBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self
                                                                                  customBarItemButton:nil
                                                                                  backgroundImage:nil
                                                                                  foreground:@"application"
                                                                                  sel:@selector(applyForProcess:)]];
    UIBarButtonItem *rightNegativeSpacer = [[UIBarButtonItem alloc]
                                            initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                            target:                                                                                                                                             nil
                                            action:nil];
    
    if (MODEL_VERSION >=7.0) {
        
        rightNegativeSpacer.width = -15;
    }
    self.navigationItem.rightBarButtonItems = @[rightNegativeSpacer,rightBackItem];

}

//个人发起流程申请
/*
 *直接跳转Safari
 *[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://10.108.10.52/h5imageupload.aspx"]];
 *
 */
- (void)applyForProcess:(NSString *)type
{
    ProcessViewController *processVC = [[ProcessViewController alloc] initWithBlock:^(NSObject *model) {
        NSLog(@"%@",model);
    }];
    processVC.CarouselType = self.tittleType;
    processVC.title_apply = self.title;
    processVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:processVC animated:YES];
    
}

- (void)initTableViewAndSearchDisplyerController
{
    ssearchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    ssearchBar.placeholder = @"搜索";
    ssearchBar.delegate = self;
//    self.tableView.tableHeaderView = searchBar;
    
    imgView = [[UIImageView alloc] init];
    imgView.contentMode = UIViewContentModeCenter;
    imgView.image = [UIImage imageNamed:@"blank_undo"];
    self.tableView.backgroundView = imgView;
    
    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:ssearchBar contentsController:self];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"MainProcessCell" bundle:nil] forCellReuseIdentifier:@"MainProcessCell"];
    [_searchDisplayController.searchResultsTableView registerNib:[UINib nibWithNibName:@"MainProcessCell" bundle:nil] forCellReuseIdentifier:@"MainProcessCell"];
    
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    _searchDisplayController.delegate= self;
    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
    
}
//搜索
-(void)searchBarClick{
    
    [self.view addSubview:ssearchBar];
    [ssearchBar becomeFirstResponder];
    
}
#pragma mark - UISearchBarDelegate
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    /*[searchBar removeFromSuperview];
     *[self.view insertSubview:searchBar belowSubview:_tableView];
     */
    [self.view sendSubviewToBack:searchBar];
    [self.view becomeFirstResponder];
}

- (void) searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller {
    
    [_searchDisplayController.searchBar resignFirstResponder];
    [self.view sendSubviewToBack:_searchDisplayController.searchBar];
    [self.view becomeFirstResponder];
}

- (void)viewDidAppear:(BOOL)animated
{

    [self hiddenLoadingView];

    [super viewDidAppear:animated];

//    _i = 0;
//    //请求
//    [self requestListFailure:nil];

}

//请求
-(void)requestListFailure:(void (^)())failure
{
    if (_isFlag == 0) {
        [self requestWaitDatapageSize:10 tittle:@"" Success:^(NSString *recordCount){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NSRecordCountDidBecomeMainNotification
                                                                object:recordCount];
            
        }failure:failure];

    }else{
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:failure];
    }
}

-(void)initRequestList
{
    [self showLoadingView:nil];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self headerRefreshMethod];
    }];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self footerRefreshMethod];
    }];
    
}

#pragma mark - MJRefreshMethod
-(void)headerRefreshMethod
{
    NSInteger tempPage = _i;
    _i = 0;
    [self requestListFailure:^{
        _i = tempPage;

    }];
}

-(void)footerRefreshMethod
{
    _i++;
    NSLog(@"_i = %ld",(long)_i);
    NSLog(@"_totalPage = %ld",(long)_totalPage);

    if (_i >= _totalPage) {
        [self endRefreshWithTableView:self.tableView];
        _i--;
    } else {
        [self requestListFailure:^{
            _i--;
        }];
    }
}

//待办
- (void)requestWaitDatapageSize:(NSInteger )pageSize tittle:(NSString *)tittle Success:(void (^)(NSString *recordCount))success failure:(void (^)())failure
{
    [self showLoadingView:nil];
    
    [[AFHttpModelTool shareAFHttpModelTool] getWaitWithUserToken:[CommonMethod getToken]
                                                            type:self.tittleType
                                                          tittle:tittle
                                                        pageSize:pageSize
                                                currentPageIndex:_i
                                                      Completion:^(WaitModel *waitProgress) {
                                                          if (waitProgress) {
                                                              NSLog(@"--%@",waitProgress);
                                                              _totalPage = ceil([waitProgress.recordCount integerValue]/10.0);
                                                              NSLog(@"_totalPage = %ld",(long)_totalPage);

                                                              NSString *msgcount = waitProgress.recordCount;
                                                              msgCount = [msgcount intValue];
                                                              NSLog(@"msgCount====%d",msgCount);
                                                              NSString *count = [NSString stringWithFormat:@"%@",waitProgress.recordCount];
                                                              int countt = [count intValue]-1 ;
                                                              countnumber = [NSString stringWithFormat:@"%d",countt];
                                                              NSLog(@"%@",countnumber);
                                                              success ? success(count) : nil;
                                                              if (_i == 0) {
                                                                  [_newDataArray removeAllObjects];
                                                              }
                                                              
                                                              if ([waitProgress.result count] != 0) {
                                                                  
                                                                  //                                                                  if (_i == 0) {
                                                                  //                                                                      [_newDataArray removeAllObjects];
                                                                  //                                                                  }
                                                                  
                                                                  [_newDataArray addObjectsFromArray:waitProgress.result];
                                                                  [self hiddenLoadingView];
                                                                  
                                                                  [self endRefreshWithTableView:self.tableView];
                                                                  
                                                                  [_tableView reloadData];
                                                              }else{
                                                                  
                                                                  [_newDataArray addObjectsFromArray:waitProgress.result];
                                                                  failure ? failure() : nil;
                                                                  
                                                                  [self hiddenLoadingView];
                                                                  [self endRefreshWithTableView:self.tableView];
                                                                  [_tableView reloadData];
                                                                  
                                                              }
                                                              /////////
//                                                              if (_isImage == NO) {
                                                              
                                                                  if (_newDataArray.count == 0) {
                                                                      self.tableView.backgroundView.alpha = 1;
                                                                  }else {
                                                                      self.tableView.backgroundView.alpha = 0;
                                                                  }
                                                                  
//                                                              }else {
//                                                                  self.tableView.backgroundView.alpha = 0;
//
//                                                              }

                                                          }else{
                                                              failure ? failure() : nil;
                                                              
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                              [_tableView reloadData];
                                                              
                                                          }
                                                      } failure:^(NSError *error) {
                                                          failure ? failure() : nil;
                                                          [self endRefreshWithTableView:self.tableView];
                                                          [self hiddenLoadingView];
                                                          [_tableView reloadData];
                                                      }];

}

//已办
- (void)requestDatapageSize:(NSInteger )pageSize  tittle:(NSString *)tittle Success:(void (^)())success failure:(void (^)())failure
{
    [self showLoadingView:nil];
    
    [[AFHttpModelTool shareAFHttpModelTool] getCompleteWithUserToken:[CommonMethod getToken]
                                                                type:self.tittleType
                                                              tittle:tittle
                                                            pageSize:pageSize
                                                    currentPageIndex:_i
                                                          Completion:^(CompleteModel *completeProgress) {
                                                              
                                                              if (completeProgress) {
                                                                  
                                                                  _totalPage = ceil([completeProgress.recordCount integerValue]/10.0);
                                                                  
                                                                  if ([completeProgress.result count] != 0) {
                                                                      [self hiddenLoadingView];
                                                                      
                                                                      if (_i == 0) {
                                                                          [_newDataArray removeAllObjects];
                                                                      }

                                                                      
                                                                      [_newDataArray addObjectsFromArray:completeProgress.result];
                                                                      
                                                                      
                                                                      success ? success() : nil;
                                                                      
                                                                      [self endRefreshWithTableView:self.tableView];
                                                                      
                                                                      [_tableView reloadData];
                                                                  }else{
                                                                      failure ? failure() : nil;
                                                                      
                                                                      [self hiddenLoadingView];
                                                                      [self endRefreshWithTableView:self.tableView];
                                                                      [_tableView reloadData];

                                                                  }
                                                                  ///////
                                                                  if (_newDataArray.count == 0) {
                                                                      self.tableView.backgroundView.alpha = 0;
                                                                  }else {
                                                                      self.tableView.backgroundView.alpha = 0;
                                                                  }

                                                              }else{
                                                                  failure ? failure() : nil;
                                                                  
                                                                  [self hiddenLoadingView];
                                                                  [self showOnlyTextAlertView:@"加载失败"];
                                                                  [_tableView reloadData];

                                                              }
                                                          } failure:^(NSError *error) {
                                                              failure ? failure() : nil;
                                                              [self endRefreshWithTableView:self.tableView];
                                                              [self hiddenLoadingView];
                                                              [self.tableView reloadData];

                                                          }];
    
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tableView) {
        return _newDataArray.count;
    }else{
        return _filterData.count;
    }
}
#pragma mark ----TableView cell----
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MainProcessCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainProcessCell"];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
    UIImageView *image = [[UIImageView alloc]initWithImage: [UIImage imageNamed:@"list_right"]];
    cell.accessoryView = image;
    
    //cell分割线
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [cell addSubview:view];
    cell.backgroundColor = [UIColor clearColor];

    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];
    
    if (_isImage == 0) {
        WaitListModel *userInfo = nil;
        if (tableView == self.tableView) {
            
            userInfo = _newDataArray[indexPath.row];
        }else{
            
            userInfo = _filterData[indexPath.row];
        }
        
        cell.tittle.text = userInfo.title;
        cell.approve.text = userInfo.stepName;
        cell.applay.text = [CommonMethod getTimeString:userInfo.createDate
                                         setDateFormat:@"yyyy/MM/dd"];
        
        return cell;

    }else{
        CompleteListModel *userInfo = nil;
        if (tableView == self.tableView) {
            
            userInfo = _newDataArray[indexPath.row];
        }else{
            
            userInfo = _filterData[indexPath.row];
        }
        
        cell.tittle.text = userInfo.title;
        cell.approve.text = userInfo.stepName;
        cell.applay.text = [CommonMethod getTimeString:userInfo.createDate
                                         setDateFormat:@"yyyy/MM/dd"];
        
        return cell;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 68;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ListDetailViewController *ListDetailVC = (ListDetailViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"ListDetailViewController"];
    
    if (_isFlag == 0) {
        WaitListModel *userInfo = nil;
        if (tableView == self.tableView) {
            
            userInfo = _newDataArray[indexPath.row];
        }else{
            
            userInfo = _filterData[indexPath.row];
        }
        ListDetailVC.url = userInfo.url;
        SelectRow = [@(indexPath.row) intValue];
        NSLog(@"select--%d",SelectRow);
        
        selectcel = [NSString stringWithFormat:@"%d",SelectRow];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"selectCell"
                                                            object:self
                                                          userInfo:@{@"SelectRow":selectcel
                                                                     }];
    }else{
        CompleteListModel *userInfo = nil;
        if (tableView == self.tableView) {
            
            userInfo = _newDataArray[indexPath.row];
        }else{
            
            userInfo = _filterData[indexPath.row];
        }
        ListDetailVC.url = userInfo.url;
    }
    
    if (_isImage == 0) {
        ListDetailVC.tittles = @"待办流程";
    }else{
        ListDetailVC.tittles = @"已办流程";
    }
    
    ListDetailVC.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:ListDetailVC animated:YES];
    SelectRow = [@(indexPath.row) intValue];
    NSLog(@"select--%d",SelectRow);

}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (self.filterData!= nil) {
        [self.filterData removeAllObjects];
    }
    
    return YES;
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    [self endRefreshWithTableView:self.tableView];
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    if (_isFlag == 0) {
        [self getWaitSearchRequestList:searchBar];
    }else{
        [self getCompleteSearchRequestList:searchBar];
    }
    
}

//代办搜索
- (void)getWaitSearchRequestList:(UISearchBar *)searchBar{
    
    [[AFHttpModelTool shareAFHttpModelTool] getWaitWithUserToken:[CommonMethod getToken]
                                                            type:self.tittleType
                                                          tittle:searchBar.text
                                                        pageSize:99999999
                                                currentPageIndex:0
                                                      Completion:^(WaitModel *waitProgress) {
                                                          
                                                          if (self.filterData!= nil) {
                                                              [self.filterData removeAllObjects];
                                                          }
                                                          if (waitProgress) {
                    
                                                              if ([waitProgress.result count] != 0) {
                                                                  [self hiddenLoadingView];
        
                                                                  [_filterData addObjectsFromArray:waitProgress.result];
                                                                  [_searchDisplayController.searchResultsTableView reloadData];
                                                                  
                                                              }else{
                                                                  [self hiddenLoadingView];
                                                                  [self endRefreshWithTableView:self.tableView];
                                                                   [_searchDisplayController.searchResultsTableView reloadData];
                                                              }
                                                          }else{
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                               [_searchDisplayController.searchResultsTableView reloadData];
                                                          }
                                                      } failure:^(NSError *error) {
                                                          [self hiddenLoadingView];
                                                           [_searchDisplayController.searchResultsTableView reloadData];
                                                      }];

}
//已办搜索

- (void)getCompleteSearchRequestList:(UISearchBar *)searchBar{
    
    [[AFHttpModelTool shareAFHttpModelTool] getCompleteWithUserToken:[CommonMethod getToken]
                                                                type:self.tittleType
                                                              tittle:searchBar.text
                                                            pageSize:10
                                                    currentPageIndex:0
                                                          Completion:^(CompleteModel *completeProgress) {
                                                              
                                                              if (self.filterData!= nil) {
                                                                  [self.filterData removeAllObjects];
                                                              }

                                                              if (completeProgress) {
                                                                  
                                                                  if ([completeProgress.result count] != 0) {
                                                                      [self hiddenLoadingView];
                        
                                                                      [_filterData addObjectsFromArray:completeProgress.result];
                                                                      
                                                                      [_searchDisplayController.searchResultsTableView reloadData];
                                                                  }
                                                              }else{
                                                                  [self hiddenLoadingView];
                                                                  [self showOnlyTextAlertView:@"加载失败"];
                                                                  [_searchDisplayController.searchResultsTableView reloadData];
                                                              }
                                                          } failure:^(NSError *error) {
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                              [_searchDisplayController.searchResultsTableView reloadData];
                                                              
                                                          }];

}

//代办按钮处理
- (IBAction)waitProcessAction:(id)sender {
    _isImage = 0;
    UIButton *btn = (UIButton *)sender;
    [self viewBackgroundColor:btn.tag - BUTTON_WP_TAG];
    _isFlag = 0;
    _i = 0;
    [self removeAllObject];
    [self requestWaitDatapageSize:10 tittle:@"" Success:nil failure:nil];

}
//已办按钮处理
- (IBAction)completeProcessAction:(id)sender {
    _isImage = 1;

    UIButton *btn = (UIButton *)sender;
    [self viewBackgroundColor:btn.tag - BUTTON_WP_TAG];
    _isFlag = 1;
    _i = 0;
    [self removeAllObject];
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];

}

- (void)viewBackgroundColor:(BOOL)isflag{
    
    _BackBroderView.layer.cornerRadius = 5;
    _BackBroderView.layer.borderColor = [UIColor colorWithHexString:@"#4ab6d3"].CGColor;
    _BackBroderView.layer.borderWidth = 1.0;
    _BackBroderView.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
   
    //设置左边圆角
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_waitProcessBtn.bounds
                                                   byRoundingCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft
                                                         cornerRadii:CGSizeMake(5, 5)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = _waitProcessBtn.bounds;
    maskLayer.path = maskPath.CGPath;
    _waitProcessBtn.layer.mask = maskLayer;

    //设置右边圆角
    UIBezierPath *completePath = [UIBezierPath bezierPathWithRoundedRect:_waitProcessBtn.bounds
                                                       byRoundingCorners:UIRectCornerTopRight | UIRectCornerBottomRight
                                                             cornerRadii:CGSizeMake(5, 5)];
    CAShapeLayer *completeLayer = [[CAShapeLayer alloc]init];
    completeLayer.frame = _completeProcessBtn.bounds;
    completeLayer.path = completePath.CGPath;
    _completeProcessBtn.layer.mask = completeLayer;
    
    if (isflag == 0) {
        
        self.waitProcessBtn.backgroundColor = [UIColor colorWithHexString:@"#4ab6d3"];
        [self.waitProcessBtn setTitleColor:[UIColor colorWithHexString:@"#ffffff"]
                                  forState:UIControlStateNormal];
        
        self.completeProcessBtn.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
        [self.completeProcessBtn setTitleColor:[UIColor colorWithHexString:@"#4ab6d3"]
                                      forState:UIControlStateNormal];
    }else{
        self.completeProcessBtn.backgroundColor = [UIColor colorWithHexString:@"#4ab6d3"];
        [self.completeProcessBtn setTitleColor:[UIColor colorWithHexString:@"#ffffff"]
                                      forState:UIControlStateNormal];
        
        self.waitProcessBtn.backgroundColor = [UIColor colorWithHexString:@"#f0f9fc"];
        [self.waitProcessBtn setTitleColor:[UIColor colorWithHexString:@"#4ab6d3"]
                                  forState:UIControlStateNormal];

    }

}

#pragma mark - viewWillDisappear

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

//    [CommonMethod validateToken];
    [self endRefreshWithTableView:_tableView];
    [self hiddenLoadingView];
    

}


- (void)removeAllObject
{
    [_newDataArray removeAllObjects];
    [_filterData removeAllObjects];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
