//
//  CalendarViewController.m
//  OfficeSoftwore
//
//  Created by user on 16/5/30.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "CalendarViewController.h"
#import "calendarModel.h"
#import "CommonMethod.h"
#import "BaseService.h"

@interface CalendarViewController ()

@end

@implementation CalendarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的日程";
    [self initView];
    
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView = [[UIWebView alloc] init];
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.frame = CGRectMake(0, 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT);
    _webView.scalesPageToFit = NO;
    _webView.delegate = self;
    _webView.scrollView.bounces = NO;
    [self.view addSubview:_webView];
    [self webViewRequestData:_webView];

}
//日历
- (void)webViewRequestData:(UIWebView *)webView{
    [self showLoadingView:nil];
    //无返回值
    NSString *urlstr = [NSString stringWithFormat:@"%@%@?token=%@&action=openCalendarPage",DEV_FAKE_SERVER,CALENDAR_url,[CommonMethod getToken]];
    NSURL *url = [NSURL URLWithString:urlstr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];

}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

#pragma  mark- UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:@"正在加载..."];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [self hiddenLoadingView];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    [self hiddenLoadingView];

    
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [CommonMethod validateToken];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;
    
}


-(void)dealloc
{
    _webView = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
