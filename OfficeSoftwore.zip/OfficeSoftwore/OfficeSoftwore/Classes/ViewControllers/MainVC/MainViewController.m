//
//  MainViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/13.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "MainViewController.h"
#import "ListViewController.h"
#import "NoticeAndMeetingViewController.h"
#import "EScrollerView.h"
#import "DSCarouselView.h"
#import "NoticeViewController.h"
#import "MeetingDetailViewController.h"
#import "MeetingViewController.h"
#import "CalendarViewController.h"

#import "AppDelegate.h"
#import "WaitViewController.h"
#import "WaitDetailViewController.h"
#import "UIImageView+AFNetworking.h"
#import "AdScrollModel.h"
#import "SignModel.h"
#import "SignListModel.h"
#import "SignStatusModel.h"
#import "calendarModel.h"
#import "PersonListModel.h"
#import "PersonModel.h"
#import "ContractModel.h"
#import "ContracListModel.h"
#import "ChatDemoHelper.h"
#import "NickNameModel.h"
#import "NickListModel.h"
#import "KLoacationModel.h"


@interface MainViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIAlertViewDelegate>
{
    CycleScrollView         *_topAdView;
    NSTimer                 *timeNow;
    UIButton                *Leftbutton;
    UIButton                *rightButton;
    bool                    isGeoSearch;
    NSArray                 *adimageArr;
    NSString                *latitude_P;
    NSString                *longitude_p;
    UIImage                 *photoImage;
    NSDateFormatter         *formatter_n;
    
    bool                    sign_btn;
    BOOL                    signBtn_click;
    
    NSString                *easePassWord;
    NSString                *easeName;
    
    NickListModel           *_nicklistModel;
    NickNameModel           *_nicknameModel;
}

@property (nonatomic, assign) BOOL wrap;
@property (weak, nonatomic) IBOutlet UILabel *changeLocationLabel;

@property (strong, nonatomic) KLoacationModel *locaModel;

@end

@implementation MainViewController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CommonMethod validateToken];
    [self prejudgeSignStatus];//判断签到按钮状态
    [self BMK_delegate];
    signBtn_click = NO;
}

//调用delegate
- (void)BMK_delegate {
    [mapView viewWillAppear];
    mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
    _locService.delegate = self;
    _geocodesearch.delegate = self;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [mapView viewWillDisappear];
    mapView.delegate = nil;
    _locService.delegate = nil;
    _geocodesearch.delegate = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getnickName_List];//nick
    
    [self forceToUpdate];
    [self prejudgeSignStatus];//判断按钮签到签退状态
    easeName = [CommonMethod getUserName];//获取用户名
    
    [_button_meeting setImage:[UIImage imageNamed:@"meeting"] forState:UIControlStateNormal];
    [_button_notice setImage:[UIImage imageNamed:@"notice"] forState:UIControlStateNormal];
    [_button_rili setImage:[UIImage imageNamed:@"schedule"] forState:UIControlStateNormal];
    
    [self getAdScrollNumber];//广告
    adimageArr = [NSArray new];
    
#pragma mark 百度地图
    mapView = [[BMKMapView alloc]initWithFrame:CGRectMake(0, 0, _Map_View.frame.size.width, _Map_View.frame.size.height)];
    //    mapView.scrollEnabled = NO;//设定地图View能否支持用户移动地图
    [_Map_View addSubview:mapView];
    
    _locService = [[BMKLocationService alloc] init];
    _locService.delegate = self;
    
    //设置距离过滤参数
    _locService.distanceFilter  = kCLDistanceFilterNone;
    //设置预期精度参数
    _locService.desiredAccuracy = kCLLocationAccuracyBest;
    
    
    
    //适配ios7
    if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0))
    {
        self.navigationController.navigationBar.translucent = NO;
    }
    _geocodesearch = [[BMKGeoCodeSearch alloc]init];
    [mapView setZoomLevel:16];
    [self startLocation];

    _wrap = YES;
    //跳转推送对应页面
    [[NSNotificationCenter defaultCenter]  addObserver:self
                                              selector:@selector(networkDidReceiveMessage:)
                                                  name:@"push"
                                                object:nil];
    
//    self.navigationController.navigationBar.translucent = NO;
    
    [self WeekAndMonthAndYear];
    [self getCurrentTime];
    
    //暂停/开始广告滚动
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didEnterBackgroundMethod)
                                                 name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didBecomeActiveMethod)
                                                 name:UIApplicationDidBecomeActiveNotification object:nil];
    
    
#pragma mark 广告按钮
    Leftbutton = [[UIButton alloc]initWithFrame:CGRectMake(14, APP_SCREEN_WIDTH*134/320/2-7*3, 8*3, 14*3)];
    [Leftbutton setImage:[UIImage imageNamed:@"left"] forState:UIControlStateNormal];
    [Leftbutton addTarget:self action:@selector(scrollViewButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    Leftbutton.tag = 1191;
    
    rightButton = [[UIButton alloc]initWithFrame:CGRectMake(APP_SCREEN_WIDTH-14-8*3,  APP_SCREEN_WIDTH*134/320/2-7*3, 8*3, 14*3)];
    [rightButton setImage:[UIImage imageNamed:@"right"] forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(scrollViewButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    rightButton.tag = 1192;
    
#pragma mark 签到按钮
    [_qiandaoButton setTitle:@"签到" forState:UIControlStateNormal];
    _qiandaoButton.backgroundColor = [UIColor colorWithHexString:@"#e37d4d"];
    [_qiandaoButton setTintColor:[UIColor colorWithHexString:@"#ffffff"]];
    [_qiandaoButton setCornerRadiuss:CGRectGetWidth([_qiandaoButton bounds])/2];
    [_qiandaoButton addTarget:self action:@selector(signbuttonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    _icarouserl = [[iCarousel alloc] init];
    _icarouserl.dataSource = self;
    _icarouserl.delegate = self;
    if (IS_IPHONE_6) {
        _icarouserl.frame = CGRectMake(0, 0, APP_SCREEN_WIDTH, 216.7-20);
    }else if (IS_IPHONE_6P || IS_IPHONE_PX){
        _icarouserl.frame = CGRectMake(0, 0, APP_SCREEN_WIDTH, 269.4-20);
    }
    else{
        _icarouserl.frame =CGRectMake(0, 0,  APP_SCREEN_WIDTH,  203-80);
        
    }
    [_view_IcarouselBG addSubview:_icarouserl];
    _icarouserl.clipsToBounds = NO;
    self.icarouserl.type = 1;
    
}

#pragma mark Icarouseldatesoure and delegate

- (NSInteger)numberOfItemsInCarousel:(__unused iCarousel *)carousel {
    return 10;
}

- (UIView *)carousel:(__unused iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view {
    
    UIImageView *kimageview = nil;
    
    //create new view if no view is available for recycling
    if (view == nil)
    {
        if (IS_IPHONE_6) {
            view = [[UIView alloc]initWithFrame:CGRectMake(0, 10, APP_SCREEN_WIDTH*0.33, 216-40)];
        }else if (IS_IPHONE_6P){
            view = [[UIView alloc]initWithFrame:CGRectMake(0, 10, APP_SCREEN_WIDTH*0.28, 269-40)];
        }else{
            view = [[UIView alloc] initWithFrame:CGRectMake(0, 10, APP_SCREEN_WIDTH*0.3, 203-80)];
        }
        
        view.backgroundColor = [UIColor clearColor];
        view.contentMode = UIViewContentModeCenter;
        
        kimageview = [[UIImageView alloc]initWithFrame:view.bounds];
        kimageview.frame = view.frame;
        kimageview.backgroundColor = [UIColor clearColor];
        kimageview.layer.cornerRadius = 5;
        kimageview.tag = 100;
        
        kimageview.layer.shadowOffset = CGSizeMake(0, -3);
        kimageview.layer.shadowOpacity = 1;
        kimageview.layer.shadowColor = [UIColor lightGrayColor].CGColor;
        kimageview.layer.shadowRadius = 4;
        
        view.layer.magnificationFilter = kCAFilterNearest;
        kimageview.layer.contentsScale = [UIScreen mainScreen].scale;
        
        [view addSubview:kimageview];
    }
    else
    {
        //get a reference to the label in the recycled view
        
        kimageview = (UIImageView *)[view viewWithTag:100];
    }
    NSArray *imageArray = @[@"vacation",@"reimbursement",@"purchase",@"contract1",@"purchasepay",@"businesstrip",@"expense",@"payment",@"business",@"seal"];
    
    kimageview.contentMode = UIViewContentModeScaleAspectFill;
    UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"%@",imageArray[index]]];
    kimageview.image = img;
    
    return view;
}

- (CGFloat)carousel:(__unused iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    //customize carousel display
    switch (option)
    {
        case iCarouselOptionWrap:
        {
            //normally you would hard-code this to YES or NO
            return self.wrap;
        }
        case iCarouselOptionSpacing:
        {
            //add a bit of spacing between the item views
            return value * 1.05f;
        }
        case iCarouselOptionFadeMax:
        {
            if (self.icarouserl.type == iCarouselTypeCustom)
            {
                //set opacity based on distance from camera
                return 0.0f;
            }
            return value;
        }
        case iCarouselOptionShowBackfaces:
        case iCarouselOptionRadius:
        case iCarouselOptionAngle:
        case iCarouselOptionArc:
        case iCarouselOptionTilt:
        case iCarouselOptionCount:
        case iCarouselOptionFadeMin:
        case iCarouselOptionFadeMinAlpha:
        case iCarouselOptionFadeRange:
        case iCarouselOptionOffsetMultiplier:
        case iCarouselOptionVisibleItems:
        {
            return value;
        }
    }
}
//EmployeeLeave
#pragma mark iCarousel taps
- (void)carousel:(__unused iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {
    NSArray *arrayTittle = @[@"员工请假",@"员工报销",@"采购申请",@"采购订单/合同评审",@"采购支款",@"公务出差/结算申请",@"差旅超标准",@"人事财政/税费支款",@"业务招待",@"公司印章/执照使用"];
    
    NSArray *arrayTittleType = [CommonMethod getTitttleType];
    
    ListViewController *listViewController = (ListViewController *)
    [CommonMethod mainStoryBoardViewController:@"ListViewController"];
    
    listViewController.title = arrayTittle[index];
    listViewController.tittleType = arrayTittleType [index];
    [self.navigationController pushViewController:listViewController animated:YES];
    
}

- (void)carouselCurrentItemIndexDidChange:(__unused iCarousel *)carousel {
    NSLog(@"Index: %@", @(self.icarouserl.currentItemIndex));
}

#pragma mark 处理 week time adress 事件
//年月日星期显示
- (void)WeekAndMonthAndYear {
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSArray *weekdayAry = [NSArray arrayWithObjects:@"星期日",@"星期一",@"星期二",@"星期三",@"星期四",@"星期五",@"星期六", nil];
    [dateFormat  setShortWeekdaySymbols:weekdayAry];
    [dateFormat setDateFormat:@"eee：YYYY.MM.dd"];
    NSDate *date = [NSDate date];
    _lable_week.text = [dateFormat stringFromDate:date];
    
}

//当前时间
- (void)getCurrentTime {
    
    formatter_n = [[NSDateFormatter alloc] init];
    if (IS_IPHONE_5||IS_IPHONE_4S) {
        [formatter_n setDateFormat:@"时间:HH:mm:ss"];
    }else{
        [formatter_n setDateFormat:@"当前时间：HH:mm:ss"];
    }
    timeNow = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timerFunc) userInfo:nil repeats:YES];
}

- (void)timerFunc {
    [_lable_now setText:[formatter_n stringFromDate:[NSDate date]]];
    
}

//推送信息滑动跳转
- (void)networkDidReceiveMessage:(NSNotification *)info {
    
    [OA_AppDelegate notLogin];
    
}
#pragma mark 判断签到签退状态
- (void)prejudgeSignStatus {
    __weak typeof (self)weakSelf = self;
    [[AFHttpModelTool shareAFHttpModelTool] PostSignStatusToken:[CommonMethod getToken]
                                                     Completion:^(SignStatusModel *signStatusModel) {
                                                         NSLog(@"%@",signStatusModel);
                                                         
                                                         [weakSelf setSignButtonStatus:signStatusModel.result];//设置按钮签到签退状态
                                                         
                                                     } failure:^(NSError *error) {
                                                         NSLog(@"------error");
                                                     }];
}

#pragma mark 签到 & 签退 & 已签退
//设置按钮标题状态
- (void)setSignButtonStatus:(NSString *)result {


    if ([result isEqualToString:@"0"]) {
        [_qiandaoButton setTitle:@"签到" forState:UIControlStateNormal];
        _qiandaoButton.backgroundColor = [UIColor colorWithHexString:@"#e37d4d"];
        
    }else if ([result isEqualToString:@"1"]) {
        [_qiandaoButton setTitle:@"签退" forState:UIControlStateNormal];
        _qiandaoButton.backgroundColor = [UIColor brownColor];
        
    }else if ([result isEqualToString:@"2"]) {
        [_qiandaoButton setTitle:@"已签退" forState:UIControlStateNormal];
        _qiandaoButton.backgroundColor = [UIColor grayColor];
    }
    
}

//设置button不同状态下的事件
- (void)signbuttonClick:(UIButton *)sender {
    [CommonMethod validateToken];
    //签到签退之前重置坐标
    latitude_P = nil;
    longitude_p = nil;
    
    
//    if (![CLLocationManager locationServicesEnabled]) {//判断定位是否开启
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {//判断定位是否开启

        [self pushLocation_Services];
    }else {
        if ([sender.titleLabel.text isEqualToString:@"签到"]) {
            sign_btn = YES;
            signBtn_click = YES;
            [self startLocation];
            
        }else if ([sender.titleLabel.text isEqualToString:@"签退"]) {
            sign_btn = NO;
            signBtn_click = YES;
            [self startLocation];
            
        }else if ([sender.titleLabel.text isEqualToString:@"已签退"]){
            signBtn_click = NO;
            [self startLocation];
        }
    }
}
//提示开启定位服务
-(void)pushLocation_Services{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"定位服务已关闭\n请前往>- 设置>- 隐私>- 打开定位服务" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *SureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSURL *url = [NSURL URLWithString:@"prefs:root=LOCATION_SERVICES"];
        [[UIApplication sharedApplication] openURL:url];
    }];
    [alertController addAction:SureAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

- (KLoacationModel*)locationModelInfo{
    
    NSArray *arr = @[
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529097" latitudeP:@"31.272421" labeldetailadress:@"上海市杨浦区昆明路1171号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.528930" latitudeP:@"31.272432" labeldetailadress:@"上海市杨浦区昆明路1167号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529180" latitudeP:@"31.272420" labeldetailadress:@"上海市杨浦区昆明路1217号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529180" latitudeP:@"31.272430" labeldetailadress:@"上海市杨浦区昆明路1217号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529180" latitudeP:@"31.272440" labeldetailadress:@"上海市杨浦区昆明路1217号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529393" latitudeP:@"31.272812" labeldetailadress:@"上海市杨浦区昆明路1173号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529446" latitudeP:@"31.272826" labeldetailadress:@"上海市杨浦区昆明路1177号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529393" latitudeP:@"31.272867" labeldetailadress:@"上海市杨浦区昆明路1175号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529408" latitudeP:@"31.272888" labeldetailadress:@"上海市杨浦区昆明路1175号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529415" latitudeP:@"31.272841" labeldetailadress:@"上海市杨浦区昆明路1177号"],
                     [[KLoacationModel alloc]initWithLongitudeP:@"121.529393" latitudeP:@"31.272781" labeldetailadress:@"上海市杨浦区昆明路1173号"]];
    int aRedValue = arc4random() % arr.count;
    NSLog(@"aRedValue %d", aRedValue);
    KLoacationModel *locaModel = arr[aRedValue];
    return  locaModel;
    
}

//签到
- (void)signButton_in {
    
    __weak typeof (self)weakSelf = self;
    NSData *dataPic = UIImageJPEGRepresentation(photoImage, 1.0);
    longitude_p = self.locaModel.longitudeP;
    latitude_P = self.locaModel.latitudeP;
    _lable_detailadress.text = self.locaModel.labeldetailadress;
    [[AFHttpModelTool shareAFHttpModelTool] PostSignWithUserToken:[CommonMethod getToken]
                                                          picture:dataPic
                                                        longitude:longitude_p
                                                        lantitude:latitude_P
                                                     locationName:_lable_detailadress.text
                                                       Completion:^(SignModel *signModel) {
                                                           if ([signModel.status isEqualToString:@"success"]) {
                                                               ShowMassage(@"签到成功");
                                                               [weakSelf prejudgeSignStatus];//判断签到签退状态

                                                           }else if ([signModel.status isEqualToString:@"error"]) {
                                                               ShowMassage(@"已经签到");
                                                               [weakSelf prejudgeSignStatus];
                                                           }

                                                       } failure:^(NSError *error) {
                                                           NSLog(@"--------error");
                                                           ShowMassage(@"签到失败,请重试");
                                                           [weakSelf prejudgeSignStatus];

                                                       }];
}

//签退
- (void)signButton_off {
    __weak typeof (self)weakSelf = self;
    NSData *dataPic = UIImageJPEGRepresentation(photoImage, 1.0);
    longitude_p = self.locaModel.longitudeP;
    latitude_P = self.locaModel.latitudeP;
    _lable_detailadress.text = self.locaModel.labeldetailadress;
    [[AFHttpModelTool shareAFHttpModelTool] PostSignoutWithUserToken:[CommonMethod getToken]
                                                             picture:dataPic
                                                           longitude:longitude_p
                                                           lantitude:latitude_P
                                                        locationName:_lable_detailadress.text
                                                          Completion:^(SignListModel *signlistModel) {
                                                              if ([signlistModel.status isEqualToString:@"success"]) {
                                                                  ShowMassage(@"签退成功");
                                                                  [weakSelf prejudgeSignStatus];//判断签到签退状态

                                                              }else if ([signlistModel.status isEqualToString:@"error"]){
                                                                  ShowMassage(@"已经签退");
                                                                  [weakSelf prejudgeSignStatus];
                                                              }

                                                          } failure:^(NSError *error) {
                                                              NSLog(@"---------error");
                                                              ShowMassage(@"签退失败,请重试");
                                                              [weakSelf prejudgeSignStatus];

                                                          }];
}

//相机起调
- (void)callThePhoneCamera {
    UIAlertController *alertcontrol = [UIAlertController alertControllerWithTitle:@"请拍摄一张照片"
                                                                          message:nil
                                                                   preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消"
                                                           style:UIAlertActionStyleCancel
                                                         handler:nil];
    
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"拍照"
                                                         style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *action) {
                                                           if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                                                               UIImagePickerController *imagePicker =
                                                               [[UIImagePickerController alloc] init];
                                                               
                                                               imagePicker.delegate = self;
                                                               imagePicker.allowsEditing = YES;
                                                               imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                                               //直接调前摄像头
                                                               imagePicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
                                                               [self presentViewController:imagePicker animated:YES completion:nil];
                                                               
                                                           }else{
                                                               ShowMassage(@"相机不可用");
                                                           }
                                                       }];
    UIAlertAction *picAction = [UIAlertAction actionWithTitle:@"相册"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                          UIImagePickerController *imagePicker =
                                                          [[UIImagePickerController alloc] init];
                                                          
                                                          imagePicker.delegate = self;
                                                          imagePicker.allowsEditing = YES;
                                                          imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                                          [self presentViewController:imagePicker animated:YES completion:nil];
                                                      }];

    [alertcontrol addAction:cancleAction];
    [alertcontrol addAction:sureAction];
    /////////[alertcontrol addAction:picAction];
    [self presentViewController:alertcontrol animated:YES completion:nil];
    
}
//取图片
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *img = [info objectForKey:UIImagePickerControllerEditedImage];
    [self performSelector:@selector(saveImage:) withObject:img afterDelay:0.5];
    //    photoImagePath = [CommonMethod saveImage:photoImage withName:@"picture_in"];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

//相机取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    [self BMK_delegate];
    signBtn_click = NO;
}

//保存&修改图片
- (void)saveImage:(UIImage *)image {
    
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *imageFilePath = [documentsDirectory stringByAppendingPathComponent:@"picture.jpg"];
    NSLog(@"imageFile->>%@",imageFilePath);
    success = [fileManager fileExistsAtPath:imageFilePath];
    if(success) {
        success = [fileManager removeItemAtPath:imageFilePath error:&error];
    }
    UIImage *smallImage=[self scaleFromImage:image toSize:CGSizeMake(100.0f, 100.0f)];//改变图片尺寸
    [UIImageJPEGRepresentation(smallImage, 1.0f) writeToFile:imageFilePath atomically:YES];//写入文件
    UIImage *selfPhoto = [UIImage imageWithContentsOfFile:imageFilePath];//读取图片文件
    photoImage = selfPhoto;
    
    if (sign_btn == YES) {
        [self signButton_in];
    }else {
        [self signButton_off];
    }
    
}
// 改变图像的尺寸
- (UIImage *)scaleFromImage:(UIImage *)image toSize:(CGSize)size {
    
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark   广告按钮事件
- (void)scrollViewButtonClick:(UIButton *)button
{
    [_topAdView pauseMethod];
    
    if (button.tag == 1191) {
        [_topAdView clickLeft];
    }else{
        [_topAdView clickRight];
        
    }
    [_topAdView resumeMethod];
}

#pragma mark  广告ScrollView
//获取广告页图片
- (void)getAdScrollNumber
{
    __weak typeof (self)weakSelf = self;
    [weakSelf showLoadingView:nil];
    [[AFHttpModelTool shareAFHttpModelTool] getAdScrollWithToken:[CommonMethod getToken]
                                                      Completion:^(AdScrollModel *adscrollModel) {
                                                          adimageArr = adscrollModel.result;
                                                          NSLog(@"%@",adimageArr);
                                                          [weakSelf dealDiscoverMenuAndAD];
                                                          [weakSelf hiddenLoadingView];
                                                          
                                                      } failure:^(NSError *error) {
                                                          [weakSelf hiddenLoadingView];
                                                      }];
}

//处理首页的广告和菜单
- (void)dealDiscoverMenuAndAD
{
    NSMutableArray *allAdView = [[NSMutableArray alloc] init];
    for (int i = 0; i < adimageArr.count; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH,(APP_SCREEN_WIDTH/320)*134)];
        
        [imageView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",adimageArr[i]]] placeholderImage:[UIImage imageNamed:@"banner1.png"]];
        
        [allAdView addObject:imageView];
        
    }
    _topAdView = [[CycleScrollView alloc] initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH,(APP_SCREEN_WIDTH/320)*134) animationDuration:5];
    _topAdView.userInteractionEnabled = YES;
    _topAdView.fetchContentViewAtIndex = ^UIImageView *(NSInteger pageIndex) {
        return allAdView[pageIndex];
    };
    _topAdView.totalPagesCount = ^NSInteger(void) {
        return [allAdView count];
    };
    [_scView addSubview:_topAdView];
    [_scView addSubview:Leftbutton];
    [_scView addSubview:rightButton];
}


#pragma mark - AppBecomeActive
- (void)didEnterBackgroundMethod
{
    //暂停广告滚动
    [_topAdView pauseMethod];
}

- (void)didBecomeActiveMethod
{
    //开始广告滚动
    [_topAdView resumeMethod];
}
#pragma mark 会议通知&公司公告&日历
//会议通知
- (IBAction)MeetingNotice:(id)sender {
    AppDelegate *appdelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    MeetingViewController *MeetingView = (MeetingViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"MeetingViewController"];
    MeetingView.url = appdelegate.url;
    MeetingView.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:MeetingView animated:YES];
    
}
//公司公告
- (IBAction)NoticeInformation:(id)sender {
    AppDelegate *appdelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NoticeViewController *NoticeVC = (NoticeViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"NoticeViewController"];
    NoticeVC.url = appdelegate.url;
    NoticeVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:NoticeVC animated:YES];
    
}
//我的日程
- (IBAction)calendar:(id)sender {
    CalendarViewController *calendarVC = [[CalendarViewController alloc] init];
    calendarVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:calendarVC animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData  *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

#pragma mark  百度地图
//开始定位
-(void)startLocation
{
    [mapView setZoomLevel:16];
    [_locService startUserLocationService];
    mapView.showsUserLocation = NO;//先关闭显示的定位图层
    mapView.userTrackingMode = BMKUserTrackingModeNone;//设置定位的状态
    mapView.showsUserLocation = YES;//显示定位图层
    
}
//停止定位
-(void)stopLocation
{
    [_locService stopUserLocationService];
    mapView.showsUserLocation = NO;
}

//跟随态
-(void)startFollowing
{
    NSLog(@"进入跟随态");
    
//    mapView.showsUserLocation = YES;
    mapView.userTrackingMode = BMKUserTrackingModeFollow;
    mapView.showsUserLocation = YES;
}

/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
//- (void)willStartLocatingUser
//{
//    NSLog(@"start locate--开始定位");
//}

/**
 *用户位置更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    NSLog(@"纬度 %f,经度 %f",userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude);
    latitude_P = [NSString stringWithFormat:@"%f",userLocation.location.coordinate.latitude];
    longitude_p = [NSString stringWithFormat:@"%f",userLocation.location.coordinate.longitude];
    [mapView updateLocationData:userLocation];
    [self stopLocation];//定位成功后停止定位以节省电量
    [self startFollowing];
    [self BMReverseGeocodeWithCLLocation:userLocation];
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
    ShowMassage(@"定位失败，请检查设置");
}

#pragma mark   百度地图反编码
- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    self.locaModel = [self locationModelInfo];
    self.changeLocationLabel.text = [NSString stringWithFormat:@"纬度 %@,经度 %@, 地址: %@",self.locaModel.latitudeP, self.locaModel.longitudeP,self.locaModel.labeldetailadress];

    NSArray* array = [NSArray arrayWithArray:mapView.annotations];
    [mapView removeAnnotations:array];
    array = [NSArray arrayWithArray:mapView.overlays];
    //    userLocation.location.coordinate.latitude
    
    [mapView removeOverlays:array];
    if (error == 0) {
        BMKPointAnnotation* item = [[BMKPointAnnotation alloc]init];
        item.coordinate = result.location;
        item.title = result.address;
        [mapView addAnnotation:item];
        mapView.centerCoordinate = result.location;
        
        NSArray *arry = result.poiList;
        BMKPoiInfo *info = [[BMKPoiInfo alloc]init];
        
        //判断附近有无收录的标识建筑
        if (arry.count == 0) {
            [mapView setZoomLevel:10];
            if (IS_IPHONE_5||IS_IPHONE_4S) {
                _lable_Adress.text = @"无标识建筑";
            }else{
                _lable_Adress.text = @"附近无标识建筑";
            }
        }else{
            
            info = arry[0];
            NSLog(@"当前位置---%@",info.name);
            _lable_Adress.text = info.name;
        }
        _lable_detailadress.text = item.title;
    }
    
    if (signBtn_click == YES) {
        [self callThePhoneCamera];
    }
}
- (void)BMReverseGeocodeWithCLLocation:(BMKUserLocation *)userLocation
{
    isGeoSearch = false;
    CLLocationCoordinate2D pt = (CLLocationCoordinate2D){0, 0};
    pt = (CLLocationCoordinate2D){userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude};
    
    BMKReverseGeoCodeOption *reverseGeocodeSearchOption = [[BMKReverseGeoCodeOption alloc]init];
    reverseGeocodeSearchOption.reverseGeoPoint = pt;
    BOOL flag = [_geocodesearch reverseGeoCode:reverseGeocodeSearchOption];
    if(flag)
    {
        NSLog(@"反geo检索发送成功");
    }
    else
    {
        NSLog(@"反geo检索发送失败");
    }
}

//强制更新
- (void)forceToUpdate{
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];//获取当前版本
    
    [[AFHttpModelTool shareAFHttpModelTool] getloginUserInforToken:[CommonMethod getToken]
                                                        clientType:@"IOS"
                                                     clientVersion:app_Version
                                                        Completion:^(PersonModel *person) {
                                                            if ([person.status isEqualToString:@"success"]) {
                                                                //存部门名称
                                                                [CommonMethod setUnitName:person.result.UnitName];
                                                                //存环信密码
                                                                [CommonMethod setEasePassWord:person.result.EasemobPassword];
                                                                
                                                                [self loginEaseMob];
                                                                //获取环信登录密码
                                                                easePassWord = person.result.EasemobPassword;
                                                                NSLog(@"%@",person);
                                                                NSString *forceUpdate = person.result.NewClientUrl;
                                                                
                                                                if ([forceUpdate isEqualToString:@"1"]) {
                                                                    [self creatAlertController];
                                                                }
                                                            }else {
                                                                ShowMassage(@"请求数据失败");
                                                            }
                                                            
                                                        } failure:^(NSError *error) {
                                                            NSLog(@"------error");
                                                            
                                                        }];
    
}

//登录环信
- (void)loginEaseMob {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //判断是否已经登录
        [OA_AppDelegate setEaseMobMainViewController];
        BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;
        if (!isAutoLogin) {
            EMError *error = [[EMClient sharedClient] loginWithUsername:easeName password:easePassWord];
            [[EMClient sharedClient] dataMigrationTo3];
            dispatch_async(dispatch_get_main_queue(), ^{
                [[ChatDemoHelper shareHelper] asyncGroupFromServer];
                [[ChatDemoHelper shareHelper] asyncConversationFromDB];
                [[ChatDemoHelper shareHelper] asyncPushOptions];
            });
            if (!error)
            {
                [[EMClient sharedClient].options setIsAutoLogin:YES];
                NSLog(@"----123");
            }
        }
    });
}

//应用AppStore地址
- (void)creatAlertController {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"发现新版本" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"去更新" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:@"https://itunes.apple.com/cn/app/id1124891755"]];
        [OA_AppDelegate needUpdate];

    }];
    
    [alertController addAction:sureAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

//获取聊天好友信息
- (void)getnickName_List {
    [[AFHttpModelTool shareAFHttpModelTool] getAllEaseMobNicknameToken:[CommonMethod getToken]
                                                            Completion:^(NickNameModel *nick_Name) {
                                                                
                                                                if ([nick_Name.status isEqualToString:@"success"]) {
                                                                    NSArray *temparray = nick_Name.result;
                                                                    [CommonMethod setNickName:temparray];
                                                                }else {
                                                                    ShowMassage(@"获取好友失败");
                                                                }
                                                                
                                                            } failure:^(NSError *error) {
                                                                NSLog(@"%@",error);
                                                            }];
    
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
