//
//  MainViewController.h
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/13.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "BaseViewController.h"
#import "iCarousel.h"

@interface MainViewController : BaseViewController<iCarouselDataSource,iCarouselDelegate,CLLocationManagerDelegate,MKMapViewDelegate,BMKMapViewDelegate,BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>
{
    BMKMapView             *mapView;
    BMKLocationService     *_locService;
    BMKGeoCodeSearch       *_geocodesearch;

}

//@property (weak, nonatomic) IBOutlet UITableView    *tableView;


@property (weak, nonatomic) IBOutlet UIButton       *qiandaoButton;
@property (weak, nonatomic) IBOutlet UIView         *scView;

@property (weak, nonatomic) IBOutlet UIButton       *button_MS;

@property (weak, nonatomic) IBOutlet UILabel        *lable_week;
@property (weak, nonatomic) IBOutlet UILabel        *lable_now;
@property (weak, nonatomic) IBOutlet UILabel        *lable_Adress;
@property (weak, nonatomic) IBOutlet UILabel        *lable_detailadress;

@property (weak, nonatomic) IBOutlet UIView         *Map_View;
@property (weak, nonatomic) IBOutlet UIView         *view_IcarouselBG;

@property (nonatomic, strong) iCarousel             *icarouserl;
@property (nonatomic, strong) CLGeocoder            *geocoder;

@property (weak, nonatomic) IBOutlet UIButton       *button_logo_left;
//@property (weak, nonatomic) NSTimer                 *timer_sign;

@property (weak, nonatomic) IBOutlet UIButton *button_meeting;
@property (weak, nonatomic) IBOutlet UIButton *button_notice;
@property (weak, nonatomic) IBOutlet UIButton *button_rili;

@end
