//
//  ProcessViewController.h
//  OfficeSoftwore
//
//  Created by user on 16/8/11.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface ProcessViewController : BaseViewController<UIWebViewDelegate>

@property (nonatomic, strong)UIWebView *webView;
@property (nonatomic, strong)NSString *title_apply;//title
@property (nonatomic, strong)NSString *CarouselType;//type类型
@property WebViewJavascriptBridge *bridge;

typedef void(^finishBlock)(NSObject *model);
//提供一个函数
- (instancetype)initWithBlock:(finishBlock)block;

@end
