//
//  NoticeAndMeetingViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/10/26.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "NoticeAndMeetingViewController.h"

@interface NoticeAndMeetingViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

@end

@implementation NoticeAndMeetingViewController
-(void)viewWillAppear:(BOOL)animated {
    [CommonMethod validateToken];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

    _data = [[NSMutableArray alloc] init];
    _filterData = [[NSMutableArray alloc] init];
    
    [self initView];
    [self initTableViewAndSearchDisplyerController];
//    [self initWithData];
    [self createRefreshViewMethod];
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];    
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}

- (void)initWithData
{
    
}

- (void)initTableViewAndSearchDisplyerController
{
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    searchBar.placeholder = @"搜索";
    searchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    self.tableView.tableHeaderView = searchBar;
    
    _tableView.emptyDataSetSource = self;// 实现empty代理、数据源
    _tableView.emptyDataSetDelegate = self;

    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    
    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
                                                                       
}

- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView
{
    
    return [UIImage imageNamed:@"blank_undo"];
}

#pragma mark - MJRefreshDelegate

-(void)createRefreshViewMethod
{
    [self showLoadingView:nil];
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self headerRefreshMethod];
    }];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self footerRefreshMethod];
    }];    
}

-(void)headerRefreshMethod
{
    [self showLoadingView:@"加载中..."];
}

-(void)footerRefreshMethod
{
    
}

#pragma mark - UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tableView) {
        
        //        return _data.count;
        return 5;
    }else{
        // 谓词搜索
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains [cd] %@",_searchDisplayController.searchBar.text];
        
        if (self.filterData!= nil) {
            [self.filterData removeAllObjects];
        }
        
        _filterData =  [[NSMutableArray alloc] initWithArray:[_data filteredArrayUsingPredicate:predicate]];
        //        return _filterData.count;
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"noticeAndMeeting"];
    //分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [cell addSubview:view];
    cell.backgroundColor = [UIColor clearColor];

    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];

    
    if (tableView == self.tableView) {
        //        cell.textLabel.text = _data[indexPath.row];
    }else{
        //        cell.textLabel.text = _filterData[indexPath.row];
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 68;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


#pragma mark - UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    [searchBar setShowsCancelButton:YES animated:YES];
    // 修改UISearchBar右侧的取消按钮文字颜色及背景图片
    for (UIView *searchbuttons in [searchBar subviews]){
        if ([searchbuttons isKindOfClass:[UIButton class]]) {
            UIButton *cancelButton = (UIButton*)searchbuttons;
            [cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
    }
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}

#pragma mark - viewWillDisappear

- (void)viewWillDisappear:(BOOL)animated
{
    [self endRefreshWithTableView:_tableView];
    [self hiddenLoadingView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
