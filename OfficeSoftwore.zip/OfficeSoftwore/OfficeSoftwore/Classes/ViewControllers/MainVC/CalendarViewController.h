//
//  CalendarViewController.h
//  OfficeSoftwore
//
//  Created by user on 16/5/30.
//  Copyright © 2016年 wangwang. All rights reserved.
//

#import "BaseViewController.h"

@interface CalendarViewController : BaseViewController<UIWebViewDelegate>
@property(nonatomic, strong)UIWebView *webView;

@end
