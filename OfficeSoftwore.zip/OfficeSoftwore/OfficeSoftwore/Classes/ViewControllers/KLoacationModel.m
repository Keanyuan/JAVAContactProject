//
//  KLoacationModel.m
//  OfficeSoftwore
//
//  Created by KeanQ on 2017/12/6.
//  Copyright © 2017年 wangwang. All rights reserved.
//

#import "KLoacationModel.h"

@implementation KLoacationModel
- (instancetype)initWithLongitudeP:(NSString *)longitudeP latitudeP:(NSString *)latitudeP labeldetailadress:(NSString *)labeldetailadress {
    self = [super init];
    if (self) {
        self.longitudeP = longitudeP;
        self.latitudeP = latitudeP;
        self.labeldetailadress = labeldetailadress;
    }
    return self;
}
@end
