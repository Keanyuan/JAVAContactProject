//
//  CompeleDetailViewController.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/4.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "CompeleDetailViewController.h"
#import "CommonWebVC.h"

@interface CompeleDetailViewController ()<UIWebViewDelegate>
{
    WebViewJavascriptBridge* _bridge;
}
@end

@implementation CompeleDetailViewController

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"已办流程";
    [self initView];
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _webView.scalesPageToFit = YES;
    _webView.delegate = self;
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.scrollView.bounces = NO;
    [self webViewRequestData:self.webView];
    
    
    if (_bridge) { return; }
    //注册
    [WebViewJavascriptBridge enableLogging];
    _bridge = [WebViewJavascriptBridge bridgeForWebView:_webView webViewDelegate:self handler:^(id data, WVJBResponseCallback responseCallback) {
        responseCallback(@"Response for message from ObjC");
    }];
    
    // js调oc方法
    [_bridge registerHandler:@"a" handler:^(id data, WVJBResponseCallback responseCallback) {
        NSDictionary *dic = (NSDictionary *)data;
        CommonWebVC *commonWebVC = (CommonWebVC *)[CommonMethod storyBoardViewController:@"Main"
                                                                identifer:@"CommonWebVC"];
        commonWebVC.url = dic[@"URL"];
        commonWebVC.title = dic[@"TITLE"];
        [self.navigationController pushViewController:commonWebVC animated:YES];
    }];
    
 
}

- (void)initView
{
    UIBarButtonItem *leftBackItem = [[UIBarButtonItem alloc] initWithCustomView:[self customBarItemButton:nil
                                                                                          backgroundImage:nil
                                                                                               foreground:@"backBtnImg"
                                                                                                      sel:@selector(back)]];
    
    UIBarButtonItem *leftNegativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
    if (MODEL_VERSION >=7.0) {
        
        leftNegativeSpacer.width = -15;
    }
    self.navigationItem.leftBarButtonItems = @[leftNegativeSpacer,leftBackItem];
    
    
}


- (void)webViewRequestData:(UIWebView *)webView{

    if (self.url) {
        
        [CommonMethod webViewRequest:webView
                                 url:self.url];

    }
    
}

#pragma  mark- UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showLoadingView:nil];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hiddenLoadingView];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hiddenLoadingView];
    
    NSString *errorDesc = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    if (errorDesc && ![errorDesc isEqualToString:@""]) {
        
        showMsg(errorDesc);
    }
    //    [self showOnlyTextAlertView:@"加载失败,请检查为网络"];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self hiddenLoadingView];

}


-(void)dealloc
{
    _webView = nil;
    _webView.delegate = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
