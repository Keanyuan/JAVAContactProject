//
//  CompleteLIstCell.m
//  OfficeSoftwore
//
//  Created by 温海旺 on 15/11/3.
//  Copyright © 2015年 wangwang. All rights reserved.
//

#import "CompleteLIstCell.h"

@implementation CompleteLIstCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
