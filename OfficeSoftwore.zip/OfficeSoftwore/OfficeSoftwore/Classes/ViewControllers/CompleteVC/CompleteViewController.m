  //
//  CompleteViewController.m
//  OfficeSoftwore
//
//  Created by 刘硕 on 15/9/25.
//  Copyright (c) 2015年 wangwang. All rights reserved.
//

#import "CompleteViewController.h"
#import "CompleteModel.h"
#import "CompleteListModel.h"
#import "CompleteLIstCell.h"
#import "CompeleDetailViewController.h"

@interface CompleteViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_newDataArray;
    NSInteger _i;
    NSInteger _totalPage;
    int SelectRow;
    NSString *select_cell;

}
@end

@implementation CompleteViewController

-(void)viewWillAppear:(BOOL)animated {
    [CommonMethod validateToken];
    
//    //(2016_07_22版本已取消tabbar已办流程项，故取消通知接收事件)
//    //listVC发来的通知
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(selectRow_cell:)
//                                                 name:@"List_Cell"
//                                               object:nil];
//    //waitVC发来的通知
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(selectRow_cell:)
//                                                 name:@"Refresh_com"
//                                               object:nil];
}

//waitVC & listVC执行删除行后调用
- (void)selectRow_cell:(NSNotification *)notification {
    select_cell = notification.userInfo[@"List_Row"];
    NSLog(@"%@",select_cell);
    if (select_cell != nil) {
        
         _i = 0;
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];

    }
    
    NSString *refresh_wait = notification.userInfo[@"refresh_com"];
    if (refresh_wait != nil) {
        _i = 0;
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];
    }
}


- (void)viewDidLoad {
    self.title = @"会话";
    [super viewDidLoad];
    _i = 0;
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

    
    _newDataArray = [[NSMutableArray alloc] init];
    _filterData = [[NSMutableArray alloc] init];
    
    [self initTableViewAndSearchDisplyerController];

    [self initRequestList];
    self.navigationController.navigationBar.barStyle = UIBaselineAdjustmentNone;

    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithHexString:@"#4ab6d3"],NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];

}


- (void)initTableViewAndSearchDisplyerController
{
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,44)];
    UIView *bgview = [[UIView alloc]init];
    bgview.frame = searchBar.frame;
    bgview.backgroundColor = Gcolor(@"#f0f9fc");
    //    Maincolor;
    UIImage *bgimage = [CommonMethod convertViewToImage:bgview];
    searchBar.placeholder = @"搜索";
    searchBar.delegate = self;
    searchBar.backgroundImage = bgimage;
    searchBar.tintColor = [UIColor colorWithHexString:@"#4ab6d3"];
    [self.view addSubview:searchBar];
//    self.tableView.tableHeaderView = searchBar;
    
    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;

    
    [self.tableView registerNib:[UINib nibWithNibName:@"CompleteLIstCell" bundle:nil] forCellReuseIdentifier:@"complete"];
    [_searchDisplayController.searchResultsTableView registerNib:[UINib nibWithNibName:@"CompleteLIstCell" bundle:nil] forCellReuseIdentifier:@"complete"];
    
    self.tableView.tableFooterView = [UIView new];
    _searchDisplayController.searchResultsTableView.tableFooterView = [UIView new];
    
}
//请求数据
- (void)requestDatapageSize:(NSInteger )pageSize tittle:(NSString *)tittle Success:(void (^)())success failure:(void (^)())failure
{
    [self showLoadingView:nil];
    
    [[AFHttpModelTool shareAFHttpModelTool] getCompleteWithUserToken:[CommonMethod getToken]
                                                                type:ALL
                                                              tittle:tittle
                                                            pageSize:pageSize
                                                    currentPageIndex:_i
                                                          Completion:^(CompleteModel *completeProgress) {
                                                              NSLog(@"%@",completeProgress.recordCount);
                                                              if (completeProgress) {
                                                                  
                                                                  _totalPage = ceil([completeProgress.recordCount integerValue]/10.0);
                                                                  
                                                                  if ([completeProgress.result count] != 0) {
                                                                      
                                                                      if (_i == 0) {
                                                                          [_newDataArray removeAllObjects];
                                                                      }

                                                                      [_newDataArray addObjectsFromArray:completeProgress.result];
                                                                      NSLog(@"%@",_newDataArray);
                                                                      
                                                                      success ? success() : nil;
                                                                      
                                                                      [self hiddenLoadingView];
                                                                      [self endRefreshWithTableView:self.tableView];
                                                                      
                                                                      [_tableView reloadData];
                                                                  }else{
                                                                      failure ? failure() : nil;

                                                                      [self hiddenLoadingView];
                                                                      [self endRefreshWithTableView:self.tableView];
                                                                      [_tableView reloadData];
                                                                  }
                                                              }else{
                                                                  failure ? failure() : nil;

                                                                  [self hiddenLoadingView];
                                                                  [self showOnlyTextAlertView:@"加载失败"];
                                                                  [_tableView reloadData];

                                                              }
                                                          } failure:^(NSError *error) {
                                                              failure ? failure() : nil;
                                                              [self endRefreshWithTableView:self.tableView];
                                                              [self hiddenLoadingView];
                                                              [_tableView reloadData];

                                                          }];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [self hiddenLoadingView];

    [super viewDidAppear:animated];
//     _i = 0;
//    [self requestDatapageSize:10 tittle:@"" Success:nil failure:nil];
}

-(void)initRequestList
{
    [self showLoadingView:nil];
    //MJ_refresh下拉刷新新方法
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self headerRefreshMethod];
    }];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self footerRefreshMethod];
    }];
}

#pragma mark - MJRefreshMethod
-(void)headerRefreshMethod
{
    NSInteger tempPage = _i;
    _i = 0;
    [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
        _i = tempPage;
    }];
}

-(void)footerRefreshMethod
{
    _i++;
    if (_i >= _totalPage) {
        [self endRefreshWithTableView:self.tableView];
    } else {
        [self requestDatapageSize:10 tittle:@"" Success:nil failure:^{
            _i--;
        }];
    }
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self hiddenLoadingView];
    [self endRefreshWithTableView:self.tableView];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tableView) {
        return _newDataArray.count;
    }else{
        return _filterData.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CompleteLIstCell *cell = [tableView dequeueReusableCellWithIdentifier:@"complete"];
    UIImageView *image = [[UIImageView alloc]initWithImage: [UIImage imageNamed:@"list_right"]];
    cell.accessoryView = image;
    //分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [cell addSubview:view];
    cell.backgroundColor = [UIColor clearColor];
    // 需要添加footview否则最下方没有分割线
    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, 0.5f)];
    view2.backgroundColor = [UIColor colorWithHexString:@"#dbd6d6"];
    [tableView setTableFooterView:view2];

//    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;// 短线左边不到头
    CompleteListModel *userInfo = nil;
    
    if (tableView == self.tableView) {
        
        userInfo = _newDataArray[indexPath.row];

    }else{
        
        userInfo = _filterData[indexPath.row];
    }
    
        cell.tittle.text  = userInfo.title;
        cell.approve.text = userInfo.stepName;
        cell.applay.text  = userInfo.processType;
        return cell;

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 68;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   [tableView deselectRowAtIndexPath:indexPath animated:YES];
    CompleteListModel *userInfo = nil;
    
    if (tableView == self.tableView) {
         userInfo = _newDataArray[indexPath.row];
        
    } else {
         userInfo = _filterData[indexPath.row];
        
    }
    
   CompeleDetailViewController *CompeleDetailVC = (CompeleDetailViewController *)[CommonMethod storyBoardViewController:@"Main" identifer:@"CompeleDetailViewController"];
    
    CompeleDetailVC.url = userInfo.url;
    CompeleDetailVC.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:CompeleDetailVC animated:YES];
    SelectRow = [@(indexPath.row) intValue];
    NSLog(@"%d",SelectRow);

}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (self.filterData!= nil) {
        [self.filterData removeAllObjects];
    }
    
    return YES;
}
//
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{

    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    [self endRefreshWithTableView:self.tableView];
}

//搜索请求
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
    [[AFHttpModelTool shareAFHttpModelTool] getCompleteWithUserToken:[CommonMethod getToken]
                                                                type:ALL
                                                              tittle:searchBar.text
                                                            pageSize:99999999
                                                    currentPageIndex:0
                                                          Completion:^(CompleteModel *completeProgress) {
                                                              
                                                              if (self.filterData!= nil) {
                                                                  [self.filterData removeAllObjects];
                                                              }

                                                              if (completeProgress) {

                                                                  if ([completeProgress.result count] != 0) {
                                                                      [self hiddenLoadingView];
                                                                     
                                                                      [_filterData addObjectsFromArray:completeProgress.result];
                                                                      [_searchDisplayController.searchResultsTableView reloadData];
                                                                  }else{
                                                                      [self hiddenLoadingView];
                                                                      [self endRefreshWithTableView:self.tableView];
                                                                      [_searchDisplayController.searchResultsTableView reloadData];
                                                                  }
                                                              }else{

                                                                  [self hiddenLoadingView];
                                                                  [self showOnlyTextAlertView:@"加载失败"];
                                                              }
                                                          } failure:^(NSError *error) {
                                        
                                                              [self hiddenLoadingView];
                                                              [self showOnlyTextAlertView:@"加载失败"];
                                                              [_searchDisplayController.searchResultsTableView reloadData];
                                                          }];

}

- (void)dealloc
{
//    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
/*- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    if ([[segue identifier] isEqualToString:@"CompeleDetailViewController"])
//    {
////        [self.tableView indexPathForSelectedRow].row]
//        CompeleDetailViewController *detailViewController = [segue destinationViewController];
//        CompleteLIstCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"complete"];
//        detailViewController.url = cell.url;
//    }
}*/


@end
